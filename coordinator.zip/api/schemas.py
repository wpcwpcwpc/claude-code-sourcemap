"""
QA Agent System — API Schemas

All Pydantic request/response models for the FastAPI service.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SessionStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    INTERRUPT_PENDING = "interrupt_pending"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentMode(str, Enum):
    NORMAL = "normal"
    COORDINATOR = "coordinator"


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class CreateSessionRequest(BaseModel):
    agent_name: str = Field(
        default="QAAutomationAgent",
        description="Name of the agent to use (from registry)",
    )
    mode: AgentMode = Field(
        default=AgentMode.NORMAL,
        description="Execution mode: normal or coordinator",
    )
    worker_agent_names: Optional[List[str]] = Field(
        default=None,
        description="Worker agent names for coordinator mode",
    )
    permission_mode: Optional[str] = Field(
        default=None,
        description="Permission mode override: default | plan | bypass",
    )
    game_version: str = Field(default="", description="H73 game version context")
    module: str = Field(default="", description="Game module context")


class SendMessageRequest(BaseModel):
    content: str = Field(..., description="Message content to send to the agent")
    stream: bool = Field(default=True, description="Whether to stream the response")


class ReviewRequest(BaseModel):
    action: str = Field(
        ...,
        description="Review action: confirm | cancel | modify | pass | fail | rerun | investigate",
    )
    modified_content: Optional[str] = Field(
        default=None,
        description="Modified content (used when action=modify)",
    )
    notes: Optional[str] = Field(
        default=None,
        description="Optional reviewer notes",
    )
    confirmed_by: Optional[str] = Field(
        default=None,
        description="Reviewer identifier (for audit trail)",
    )


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------

class CreateSessionResponse(BaseModel):
    session_id: str
    status: SessionStatus
    agent_name: str
    mode: str


class SendMessageResponse(BaseModel):
    message_id: str
    session_id: str
    status: str = "accepted"


class InterruptPayload(BaseModel):
    interrupt_id: str
    interrupt_type: str
    payload: Dict[str, Any]
    created_at: float
    age_seconds: float
    actions: List[str]


class SessionStatusResponse(BaseModel):
    session_id: str
    status: SessionStatus
    agent_name: str
    mode: str
    turn_count: int
    game_version: str
    module: str
    interrupt_payload: Optional[InterruptPayload] = None
    error: Optional[str] = None


class ReviewResponse(BaseModel):
    session_id: str
    action: str
    resolved: bool


class HealthResponse(BaseModel):
    status: str  # "ok" | "degraded"
    milvus: str  # "connected" | "disconnected"
    storage: str  # "ok" | "error"
    version: str = "0.1.0"


class ConfigResponse(BaseModel):
    llm_model: str
    llm_base_url: str
    storage_backend: str
    milvus_enabled: bool
    milvus_host: str
    default_max_turns: int
    default_permission_mode: str
    project_skills_dir: str
    mcp_config_path: str


class SkillInfo(BaseModel):
    name: str
    tool_name: str
    description: str
    when_to_use: str
    tools: List[str]
    args: List[str]
    effort: int
    agent: Optional[str] = None


class AgentInfo(BaseModel):
    name: str
    description: str
    when_to_use: str
    tools: List[str]
    permission_mode: str
    agent_type: str
    tags: List[str]
    inject_history: bool
