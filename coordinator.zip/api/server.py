"""
QA Agent System — FastAPI Server

Main application entry point combining:
- Custom REST endpoints (sessions, review, skills, agents, health)
- WebSocket streaming endpoint
- AgentOS integration
- Startup initialization (Milvus collections, skill loading)
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from api.schemas import (
    AgentInfo, AgentMode, ConfigResponse, CreateSessionRequest,
    CreateSessionResponse, HealthResponse, ReviewRequest, ReviewResponse,
    SendMessageRequest, SendMessageResponse, SessionStatus,
    SessionStatusResponse, SkillInfo,
)
from api.session_manager import session_manager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Application Lifespan (startup / shutdown)
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize system on startup, clean up on shutdown."""
    logger.info("QA Agent System starting up...")

    # 1. Connect Milvus + create collections
    try:
        from memory.milvus_client import get_milvus_client
        from memory.collections import ensure_collections

        client = get_milvus_client()
        connected = client.connect()
        if connected:
            ensure_collections()
            logger.info("✓ Milvus ready")
        else:
            logger.warning("⚠ Milvus unavailable — running without long-term memory")
    except Exception:
        logger.warning("⚠ Milvus initialization failed", exc_info=True)

    # 2. Load skills
    try:
        from core.config import settings
        from skills.loader import load_skills
        from skills.skill_tool import build_skill_tools
        from tools.registry import tool_registry
        from tools.base import readonly_meta

        skill_loader = load_skills(
            project_skills_dir=settings.project_skills_dir,
            user_skills_dir=settings.user_skills_dir,
        )
        skill_tools = build_skill_tools(skill_loader.all())
        for fn in skill_tools:
            name = getattr(fn, "name", str(fn))
            tool_registry.register(name, fn, readonly_meta(category="skill"))

        app.state.skill_loader = skill_loader
        logger.info("✓ Loaded %d skills", len(skill_loader.all()))
        if len(skill_loader.all()) == 0:
            logger.warning("⚠ No skills loaded — check PROJECT_SKILLS_DIR=%s", settings.project_skills_dir)
    except Exception as e:
        logger.error("❌ Skill loading failed: %s", e, exc_info=True)
        app.state.skill_loader = None

    # 3. Register builtin tools
    _register_builtin_tools()

    # 4. Register interrupt_manager WS push callback
    from hooks.interrupt_manager import interrupt_manager

    async def _ws_push_callback(session_id: str, event: dict) -> None:
        await session_manager.push_ws_event(session_id, event)
        await session_manager.set_interrupt_pending(session_id)

    interrupt_manager.set_ws_push(_ws_push_callback)

    # 5. Start cleanup background task
    cleanup_task = asyncio.create_task(_cleanup_loop())

    logger.info("✓ QA Agent System ready")
    yield

    # Shutdown
    cleanup_task.cancel()
    logger.info("QA Agent System shutting down")


def _register_builtin_tools() -> None:
    """Register all builtin tools in the tool registry."""
    from tools.registry import tool_registry
    from tools.base import readonly_meta, sideeffect_meta
    from tools.file_tools import file_read, file_edit, glob_search
    from tools.bash_tool import bash
    from tools.search_tools import grep
    from tools.agent_spawn_tool import agent_spawn
    from tools.hunter_execute_tool import hunter_execute

    tool_registry.register_batch([
        ("file_read",    file_read,    readonly_meta("Read file content", "file")),
        ("glob_search",  glob_search,  readonly_meta("Glob pattern file search", "file")),
        ("grep",         grep,         readonly_meta("Regex search in files", "search")),
        ("agent_spawn",  agent_spawn,  readonly_meta("Spawn a sub-agent", "orchestration")),
        ("file_edit",    file_edit,    sideeffect_meta("Write file content", "file")),
        ("bash",         bash,         sideeffect_meta("Execute shell command", "execution")),
        ("hunter_execute", hunter_execute, sideeffect_meta("Execute via Hunter2", "execution")),
    ], coordinator_visible=False)

    # agent_spawn is visible to coordinator
    tool_registry.register(
        "agent_spawn", agent_spawn,
        readonly_meta("Spawn a sub-agent", "orchestration"),
        coordinator_visible=True,
    )
    logger.info("✓ Registered %d builtin tools", len(tool_registry))


async def _cleanup_loop() -> None:
    """Background task: clean up expired interrupt sessions every 5 minutes."""
    while True:
        await asyncio.sleep(300)
        try:
            cleaned = await session_manager.cleanup_expired_interrupts()
            if cleaned > 0:
                logger.info("Cleaned up %d expired interrupt session(s)", cleaned)
        except Exception:
            logger.warning("Cleanup loop error", exc_info=True)


# ---------------------------------------------------------------------------
# FastAPI Application
# ---------------------------------------------------------------------------

app = FastAPI(
    title="QA Agent System",
    description="AI-powered QA automation API for H73 project",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Session endpoints
# ---------------------------------------------------------------------------

@app.post("/sessions", response_model=CreateSessionResponse, tags=["sessions"])
async def create_session(req: CreateSessionRequest):
    """Create a new agent session."""
    session_id = await session_manager.create_session(
        agent_name=req.agent_name,
        mode=req.mode.value,
        game_version=req.game_version,
        module=req.module,
    )

    # Build the agent/team (but don't run it yet)
    try:
        if req.mode == AgentMode.COORDINATOR:
            from coordinator.team_builder import create_coordinator_team
            agent = await create_coordinator_team(
                task="",
                worker_agent_names=req.worker_agent_names,
                session_id=session_id,
                game_version=req.game_version,
                module=req.module,
            )
        else:
            from agents.base import create_agent_from_definition
            from agents.registry import agent_registry

            definition = agent_registry.get(req.agent_name)
            if definition is None:
                raise HTTPException(status_code=404, detail=f"Agent '{req.agent_name}' not found")

            agent = await create_agent_from_definition(
                definition,
                session_id=session_id,
                game_version=req.game_version,
                module=req.module,
            )

        await session_manager.attach_agent(session_id, agent)

    except HTTPException:
        raise
    except Exception as e:
        await session_manager.set_failed(session_id, str(e))
        raise HTTPException(status_code=500, detail=f"Failed to create agent: {e}")

    return CreateSessionResponse(
        session_id=session_id,
        status=SessionStatus.IDLE,
        agent_name=req.agent_name,
        mode=req.mode.value,
    )


@app.post("/sessions/{session_id}/messages", response_model=SendMessageResponse, tags=["sessions"])
async def send_message(session_id: str, req: SendMessageRequest):
    """Send a message to an agent session (starts async execution)."""
    record = session_manager.get(session_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Session not found")

    if record.status == SessionStatus.RUNNING:
        raise HTTPException(status_code=409, detail="Session is already running")

    agent = session_manager.get_agent(session_id)
    if agent is None:
        raise HTTPException(status_code=400, detail="No agent attached to session")

    message_id = str(uuid.uuid4())

    # Fire-and-forget: run agent in background
    asyncio.create_task(_run_agent_task(session_id, agent, req.content, message_id))

    return SendMessageResponse(
        message_id=message_id,
        session_id=session_id,
        status="accepted",
    )


async def _run_agent_task(session_id: str, agent: Any, message: str, message_id: str) -> None:
    """Background task: run agent and stream events to WebSocket queues."""
    await session_manager.set_running(session_id)

    try:
        from core.stream_adapter import stream_agent_events

        async for event in stream_agent_events(agent, message, session_id):
            await session_manager.push_ws_event(session_id, event)

            # ── Debug print: all event types ──
            _debug_print_event(event)

            # Track turn count from completion events
            if event.get("event_type") == "run_complete":
                await session_manager.increment_turn(session_id)

        await session_manager.set_completed(session_id)

    except Exception as e:
        logger.exception("Agent task failed (session=%s)", session_id)
        await session_manager.set_failed(session_id, str(e))
        await session_manager.push_ws_event(session_id, {
            "event_type": "run_error",
            "session_id": session_id,
            "error": str(e),
        })


@app.get("/sessions/{session_id}/status", response_model=SessionStatusResponse, tags=["sessions"])
async def get_session_status(session_id: str):
    """Get current session status and any pending interrupt payload."""
    record = session_manager.get(session_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Session not found")

    from hooks.interrupt_manager import interrupt_manager
    interrupt_payload = interrupt_manager.pending_payload(session_id)

    return SessionStatusResponse(**record.to_status_dict(interrupt_payload=interrupt_payload))


@app.post("/sessions/{session_id}/review", response_model=ReviewResponse, tags=["sessions"])
async def review_interrupt(session_id: str, req: ReviewRequest):
    """Submit human review decision for a pending interrupt."""
    record = session_manager.get(session_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Session not found")

    from hooks.interrupt_manager import interrupt_manager

    resolved = interrupt_manager.resolve_interrupt(
        session_id=session_id,
        action=req.action,
        modified_content=req.modified_content,
        notes=req.notes,
    )

    if not resolved:
        raise HTTPException(status_code=400, detail="No pending interrupt for this session")

    # Resume running state (hook will continue execution)
    await session_manager.set_running(session_id)

    return ReviewResponse(session_id=session_id, action=req.action, resolved=True)


@app.delete("/sessions/{session_id}", tags=["sessions"])
async def delete_session(session_id: str):
    """Close and remove a session."""
    deleted = await session_manager.delete_session(session_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"deleted": True, "session_id": session_id}


# ---------------------------------------------------------------------------
# WebSocket streaming endpoint
# ---------------------------------------------------------------------------

@app.websocket("/sessions/{session_id}/stream")
async def websocket_stream(websocket: WebSocket, session_id: str):
    """Stream agent execution events in real-time."""
    if session_manager.get(session_id) is None:
        await websocket.close(code=4004, reason="Session not found")
        return

    await websocket.accept()
    queue: asyncio.Queue = asyncio.Queue(maxsize=200)
    session_manager.add_ws_queue(session_id, queue)

    try:
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=30.0)
                await websocket.send_text(json.dumps(event, ensure_ascii=False))

                # Close WS after run_complete or run_error
                if event.get("event_type") in ("run_complete", "run_error"):
                    break
            except asyncio.TimeoutError:
                # Send heartbeat to keep connection alive
                await websocket.send_text(json.dumps({"event_type": "heartbeat"}))

    except WebSocketDisconnect:
        logger.debug("WebSocket disconnected (session=%s)", session_id)
    except Exception:
        logger.exception("WebSocket error (session=%s)", session_id)
    finally:
        session_manager.remove_ws_queue(session_id, queue)
        try:
            await websocket.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Skills, Agents, Health, Config endpoints
# ---------------------------------------------------------------------------

@app.get("/skills", response_model=list[SkillInfo], tags=["discovery"])
async def list_skills():
    """List all available skills."""
    skill_loader = getattr(app.state, "skill_loader", None)
    if skill_loader is None:
        return []
    return skill_loader.to_api_list()


@app.get("/agents", response_model=list[AgentInfo], tags=["discovery"])
async def list_agents():
    """List all available agents (builtin + custom)."""
    from agents.registry import agent_registry
    return agent_registry.to_api_list()


@app.get("/health", response_model=HealthResponse, tags=["system"])
async def health_check():
    """System health check."""
    from memory.milvus_client import get_milvus_client

    milvus_status = "connected" if get_milvus_client().is_available else "disconnected"

    overall = "ok" if milvus_status == "connected" else "degraded"
    return HealthResponse(
        status=overall,
        milvus=milvus_status,
        storage="ok",
    )


@app.get("/config", response_model=ConfigResponse, tags=["system"])
async def get_config():
    """Return current configuration (no sensitive values)."""
    from core.config import settings

    return ConfigResponse(
        llm_model=settings.llm_model,
        llm_base_url=settings.llm_base_url,
        storage_backend=settings.storage_backend.value,
        milvus_enabled=settings.milvus_enabled,
        milvus_host=settings.milvus_host,
        default_max_turns=settings.default_max_turns,
        default_permission_mode=settings.default_permission_mode.value,
        project_skills_dir=settings.project_skills_dir,
        mcp_config_path=settings.mcp_config_path,
    )


# ---------------------------------------------------------------------------
# Debug print helper (temporary — for terminal observation during dev)
# ---------------------------------------------------------------------------

def _debug_print_event(event: dict) -> None:
    """Pretty-print agent events to the terminal for debugging.

    Color coding (ANSI):
      token        — default (no prefix, streamed inline)
      tool_start   — 🔧 cyan
      tool_end     — ✅ green
      tool_error   — 💥 red
      run_started  — 🚀 blue
      run_complete — 🏁 bold green
      run_error    — ❌ red
      interrupt    — ⏸️ yellow
      other        — 🔹 dim
    """
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    RED = "\033[31m"
    BLUE = "\033[34m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"
    YELLOW = "\033[33m"
    MAGENTA = "\033[35m"

    etype = event.get("event_type", "")

    if etype == "token":
        # Stream tokens inline (same as your original print)
        content = event.get("content", "")
        if content:
            print(content, end="", flush=True)

    elif etype == "tool_start":
        tool_name = event.get("tool_name", "?")
        call_id = event.get("tool_call_id", "")
        inputs = event.get("inputs", {})
        inputs_str = json.dumps(inputs, ensure_ascii=False, indent=2) if inputs else "(no inputs)"
        # Truncate long inputs for readability
        if len(inputs_str) > 1000:
            inputs_str = inputs_str[:1000] + f"\n  ... ({len(inputs_str)} chars total)"
        print(f"\n{CYAN}{'='*60}{RESET}")
        print(f"{CYAN}🔧 TOOL CALL: {BOLD}{tool_name}{RESET}{DIM}  [{call_id[:8]}]{RESET}")
        print(f"{CYAN}   ┌─ Inputs:{RESET}")
        for line in inputs_str.split("\n"):
            print(f"{CYAN}   │ {line}{RESET}")
        print(f"{CYAN}   └─────────{RESET}", flush=True)

    elif etype == "tool_end":
        tool_name = event.get("tool_name", "?")
        call_id = event.get("tool_call_id", "")
        outputs = event.get("outputs")
        elapsed = event.get("elapsed_ms", 0)
        outputs_str = str(outputs) if outputs is not None else "(no output)"
        # Truncate long outputs
        if len(outputs_str) > 2000:
            outputs_str = outputs_str[:2000] + f"\n  ... ({len(outputs_str)} chars total)"
        print(f"\n{GREEN}✅ TOOL DONE: {BOLD}{tool_name}{RESET}{GREEN} ({elapsed:.0f}ms){RESET}{DIM}  [{call_id[:8]}]{RESET}")
        print(f"{GREEN}   ┌─ Output:{RESET}")
        for line in outputs_str.split("\n")[:30]:  # Max 30 lines
            print(f"{GREEN}   │ {line}{RESET}")
        if outputs_str.count("\n") > 30:
            print(f"{GREEN}   │ ... (output truncated, {outputs_str.count(chr(10))} lines total){RESET}")
        print(f"{GREEN}   └─────────{RESET}")
        print(f"{CYAN}{'='*60}{RESET}", flush=True)

    elif etype == "tool_error":
        tool_name = event.get("tool_name", "?")
        call_id = event.get("tool_call_id", "")
        error = event.get("error", "unknown")
        print(f"\n{RED}{'='*60}{RESET}")
        print(f"{RED}💥 TOOL ERROR: {BOLD}{tool_name}{RESET}{DIM}  [{call_id[:8]}]{RESET}")
        print(f"{RED}   Error: {error}{RESET}")
        print(f"{RED}{'='*60}{RESET}", flush=True)

    elif etype == "run_started":
        agent_name = event.get("agent_name", "")
        print(f"\n{BLUE}{BOLD}🚀 AGENT RUN STARTED: {agent_name}{RESET}", flush=True)

    elif etype == "run_complete":
        final = event.get("final_response", "")
        print(f"\n\n{GREEN}{BOLD}🏁 RUN COMPLETE{RESET}")
        print(f"{GREEN}   Response length: {len(final)} chars{RESET}", flush=True)

    elif etype == "run_error":
        error = event.get("error", "unknown")
        print(f"\n{RED}{BOLD}❌ RUN ERROR: {error}{RESET}", flush=True)

    elif etype == "interrupt_request":
        payload = event.get("payload", {})
        print(f"\n{YELLOW}{BOLD}⏸️  INTERRUPT REQUEST{RESET}")
        print(f"{YELLOW}   {json.dumps(payload, ensure_ascii=False)}{RESET}", flush=True)

    else:
        # Unknown/generic event — print for visibility during debugging
        content_preview = str(event.get("content", ""))[:200]
        print(f"\n{MAGENTA}🔹 EVENT [{etype}]{RESET}{DIM}: {content_preview}{RESET}", flush=True)
