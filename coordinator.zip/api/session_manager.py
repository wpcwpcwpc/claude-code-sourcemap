"""
QA Agent System — Session Manager

Manages agent session lifecycle:
  - session_id → (agent/team instance, status, metadata)
  - State machine: idle → running → interrupt_pending → running → completed/failed
  - Timeout cleanup for stale interrupt sessions
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from api.schemas import AgentMode, SessionStatus

logger = logging.getLogger(__name__)


@dataclass
class SessionRecord:
    """All state for a single agent session."""
    session_id: str
    agent_name: str
    mode: str
    status: SessionStatus
    game_version: str = ""
    module: str = ""
    turn_count: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    agent: Optional[Any] = None     # Agno Agent or Team instance
    error: Optional[str] = None
    _ws_queues: List[asyncio.Queue] = field(default_factory=list)

    def touch(self) -> None:
        self.updated_at = time.time()

    def to_status_dict(self, interrupt_payload: Optional[Dict] = None) -> Dict:
        return {
            "session_id": self.session_id,
            "status": self.status,
            "agent_name": self.agent_name,
            "mode": self.mode,
            "turn_count": self.turn_count,
            "game_version": self.game_version,
            "module": self.module,
            "interrupt_payload": interrupt_payload,
            "error": self.error,
        }


class SessionManager:
    """Thread-safe session lifecycle manager."""

    def __init__(self, interrupt_timeout_minutes: int = 30) -> None:
        self._sessions: Dict[str, SessionRecord] = {}
        self._timeout_seconds = interrupt_timeout_minutes * 60
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Create / Delete
    # ------------------------------------------------------------------

    async def create_session(
        self,
        agent_name: str,
        mode: str = "normal",
        game_version: str = "",
        module: str = "",
    ) -> str:
        """Create a new session record and return session_id."""
        session_id = str(uuid.uuid4())
        record = SessionRecord(
            session_id=session_id,
            agent_name=agent_name,
            mode=mode,
            status=SessionStatus.IDLE,
            game_version=game_version,
            module=module,
        )
        async with self._lock:
            self._sessions[session_id] = record

        logger.info("Session created: %s (agent=%s, mode=%s)", session_id, agent_name, mode)
        return session_id

    async def attach_agent(self, session_id: str, agent: Any) -> None:
        """Attach an Agent/Team instance to a session."""
        record = self._get(session_id)
        if record:
            record.agent = agent
            record.touch()

    async def delete_session(self, session_id: str) -> bool:
        """Remove a session record."""
        async with self._lock:
            if session_id in self._sessions:
                del self._sessions[session_id]
                logger.info("Session deleted: %s", session_id)
                return True
        return False

    # ------------------------------------------------------------------
    # Status transitions
    # ------------------------------------------------------------------

    async def set_running(self, session_id: str) -> None:
        record = self._get(session_id)
        if record:
            record.status = SessionStatus.RUNNING
            record.touch()

    async def set_interrupt_pending(self, session_id: str) -> None:
        record = self._get(session_id)
        if record:
            record.status = SessionStatus.INTERRUPT_PENDING
            record.touch()

    async def set_completed(self, session_id: str) -> None:
        record = self._get(session_id)
        if record:
            record.status = SessionStatus.COMPLETED
            record.touch()

    async def set_failed(self, session_id: str, error: str = "") -> None:
        record = self._get(session_id)
        if record:
            record.status = SessionStatus.FAILED
            record.error = error
            record.touch()

    async def increment_turn(self, session_id: str) -> None:
        record = self._get(session_id)
        if record:
            record.turn_count += 1
            record.touch()

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get(self, session_id: str) -> Optional[SessionRecord]:
        return self._sessions.get(session_id)

    def get_agent(self, session_id: str) -> Optional[Any]:
        record = self._sessions.get(session_id)
        return record.agent if record else None

    def get_status(self, session_id: str) -> Optional[SessionStatus]:
        record = self._sessions.get(session_id)
        return record.status if record else None

    def list_sessions(self) -> List[Dict]:
        return [r.to_status_dict() for r in self._sessions.values()]

    # ------------------------------------------------------------------
    # WebSocket queue management
    # ------------------------------------------------------------------

    def add_ws_queue(self, session_id: str, queue: asyncio.Queue) -> None:
        """Register a WebSocket event queue for a session."""
        record = self._sessions.get(session_id)
        if record:
            record._ws_queues.append(queue)

    def remove_ws_queue(self, session_id: str, queue: asyncio.Queue) -> None:
        """Unregister a WebSocket event queue."""
        record = self._sessions.get(session_id)
        if record and queue in record._ws_queues:
            record._ws_queues.remove(queue)

    async def push_ws_event(self, session_id: str, event: Dict) -> None:
        """Push an event to all WebSocket queues for a session."""
        record = self._sessions.get(session_id)
        if not record:
            return
        for queue in list(record._ws_queues):
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("WS queue full for session %s, dropping event", session_id)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    async def cleanup_expired_interrupts(self) -> int:
        """Mark sessions stuck in interrupt_pending past timeout as failed.

        Returns number of sessions cleaned up.
        """
        now = time.time()
        expired = []

        for sid, record in self._sessions.items():
            if record.status == SessionStatus.INTERRUPT_PENDING:
                age = now - record.updated_at
                if age > self._timeout_seconds:
                    expired.append(sid)

        for sid in expired:
            await self.set_failed(sid, error=f"Interrupt timed out after {self._timeout_seconds}s")
            logger.warning("Session %s timed out in interrupt_pending state", sid)

        return len(expired)

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    def _get(self, session_id: str) -> Optional[SessionRecord]:
        return self._sessions.get(session_id)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
session_manager = SessionManager()
