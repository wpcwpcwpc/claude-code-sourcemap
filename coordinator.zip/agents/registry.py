"""
QA Agent System — Agent Registry

Global registry for all available agent definitions.
Supports both builtin agents and hot-loaded AGENT.md custom agents.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from agents.base import AgentDefinition

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Singleton registry mapping agent names to their definitions."""

    def __init__(self) -> None:
        self._definitions: Dict[str, AgentDefinition] = {}

    def register(self, definition: AgentDefinition) -> None:
        """Register an agent definition."""
        if definition.name in self._definitions:
            logger.debug("Agent '%s' re-registered (overwrite)", definition.name)
        self._definitions[definition.name] = definition
        logger.debug("Registered agent: %s", definition.name)

    def register_all(self, definitions: List[AgentDefinition]) -> None:
        for d in definitions:
            self.register(d)

    def get(self, name: str) -> Optional[AgentDefinition]:
        """Return an AgentDefinition by name, or None."""
        return self._definitions.get(name)

    def all(self) -> List[AgentDefinition]:
        return list(self._definitions.values())

    def to_api_list(self) -> List[Dict]:
        """Return JSON-serializable list for GET /agents."""
        return [
            {
                "name": d.name,
                "description": d.description,
                "when_to_use": d.when_to_use,
                "tools": d.tool_names,
                "permission_mode": d.permission_mode,
                "agent_type": d.agent_type,
                "tags": d.tags,
                "inject_history": d.inject_history,
            }
            for d in self._definitions.values()
        ]

    def __contains__(self, name: str) -> bool:
        return name in self._definitions

    def __len__(self) -> int:
        return len(self._definitions)


# ---------------------------------------------------------------------------
# Module-level singleton, pre-populated with builtin agents
# ---------------------------------------------------------------------------
agent_registry = AgentRegistry()


def _register_builtins() -> None:
    """Register all builtin agent definitions."""
    from agents.builtin.qa_automation_agent import QAAutomationAgentDefinition
    from agents.builtin.config_analyzer_agent import ConfigAnalyzerAgentDefinition

    agent_registry.register_all([
        QAAutomationAgentDefinition,
        ConfigAnalyzerAgentDefinition,
    ])
    logger.info("Registered %d builtin agents", len(agent_registry))


# Auto-register builtins on import
_register_builtins()
