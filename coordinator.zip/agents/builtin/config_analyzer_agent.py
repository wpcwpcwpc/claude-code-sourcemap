"""
QA Agent System — Config Analyzer Agent (Builtin)

Read-only agent specialized in Excel configuration table analysis.
Uses Agno's native Skills system to load the excel-diff-analyzer skill pack.
"""

from __future__ import annotations

import os
from pathlib import Path

from agno.skills import Skills, LocalSkills

from agents.base import AgentDefinition

CONFIG_ANALYZER_INSTRUCTIONS = """\
你是 H73 项目的配置表分析专家。

## 技能使用
你已经加载了 excel-diff-analyzer 技能包。当需要分析 Excel 配置表时，你可以调用该skill进行分析：
"""

# Resolve the excel-diff-analyzer skill directory path
# Support both project-level and absolute paths
_SKILL_DIR = Path(__file__).resolve().parent.parent.parent / ".claude" / "skills"
if not _SKILL_DIR.exists():
    # Fallback: try from CWD
    _SKILL_DIR = Path(os.getcwd()) / ".claude" / "skills"

# Load ONLY the excel-diff-analyzer skill using Agno's native Skills system
_excel_diff_skills: Skills | None = None
_excel_diff_skill_dir = _SKILL_DIR / "excel-diff-analyzer"
if _excel_diff_skill_dir.exists():
    try:
        # Point LocalSkills directly at the skill subdirectory for precise loading
        _excel_diff_skills = Skills(loaders=[LocalSkills(str(_excel_diff_skill_dir))])
        print(f"✓ ConfigAnalyzerAgent: Loaded skills from {_excel_diff_skill_dir}")
        print(f"  Available skills: {_excel_diff_skills.get_skill_names()}")
    except Exception as e:
        print(f"⚠ ConfigAnalyzerAgent: Failed to load skills: {e}")
        _excel_diff_skills = None
else:
    print(f"⚠ ConfigAnalyzerAgent: Skill dir not found: {_excel_diff_skill_dir}")


ConfigAnalyzerAgentDefinition = AgentDefinition(
    name="ConfigAnalyzerAgent",
    description="配置表分析专家，用于 Excel 配置表版本 Diff 分析和业务影响评估",
    instructions=CONFIG_ANALYZER_INSTRUCTIONS,
    tool_names=["file_read", "glob_search", "grep", "bash", "file_write"],
    permission_mode="plan",
    agent_type="worker",
    max_turns=20,
    inject_history=False,
    when_to_use="当需要分析 Excel 配置表的版本变更、审查配置差异对游戏平衡的影响时使用",
    tags=["config", "excel", "analysis", "read-only"],
    skills=_excel_diff_skills,
)