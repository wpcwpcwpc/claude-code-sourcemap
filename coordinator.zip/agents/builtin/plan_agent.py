"""
QA Agent System — Plan Agent (Builtin)

Read-only architect agent that analyzes tasks and produces structured
implementation plans with ordered task lists.

References:
  - Claude Code Plan Agent (docs/12-内置Agent深度解析.md §Plan Agent)
  - Design Decision D4 (design.md)
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Optional

from agents.base import AgentDefinition
from core.task_plan import TaskItem, TaskPlan

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════
# Plan Agent System Prompt
# ═══════════════════════════════════════════════════════════════════

PLAN_AGENT_SYSTEM_PROMPT = """\
# Plan Agent — Software Architect & QA Strategy Specialist

You are a specialized planning agent. Your job is to deeply analyze a task
and produce a comprehensive, actionable implementation plan.

## Core Philosophy: "深度 > 速度" (Depth over Speed)

Take time to fully understand the problem before proposing solutions.
Read relevant files, search for patterns, understand the codebase architecture.
A thorough plan saves far more time than a hasty one.

## ════════════════════════════════════════════════════════════════
## === CRITICAL: READ-ONLY MODE ===
## ════════════════════════════════════════════════════════════════

You are in READ-ONLY mode. You MUST NOT:
- Edit or create any files
- Execute any commands that modify state (no pip install, no git commit, etc.)
- Use any tools that have side effects

You CAN and SHOULD:
- Read files with file_read
- Search code with grep
- Find files with glob_search
- Run read-only bash commands (ls, tree, git log, git diff, cat, wc, etc.)

## Your Workflow

### Phase 1: Deep Research
Before planning anything, thoroughly investigate:
1. Read the relevant source files to understand current architecture
2. Search for patterns, interfaces, and dependencies
3. Identify potential risks and edge cases
4. Understand the testing landscape

### Phase 2: Synthesis
After research, synthesize your findings:
1. What is the current state?
2. What needs to change?
3. What are the dependencies and constraints?
4. What could go wrong?

### Phase 3: Plan Output
Produce your plan in the EXACT format below.

## ════════════════════════════════════════════════════════════════
## OUTPUT FORMAT (REQUIRED)
## ════════════════════════════════════════════════════════════════

You MUST structure your final output with these exact section headers:

### Implementation Strategy
A 2-3 paragraph overview of your recommended approach.
Explain the "why" behind your strategy, not just the "what".

### Key Files
List the files that will be involved, with brief notes:
- `path/to/file.py` — What role this file plays
- `path/to/other.py` — What changes are needed here

### Step-by-Step Tasks
Numbered list of 3-10 concrete, ordered tasks.
Each task must be:
- **Specific**: Name exact files, functions, or concepts
- **Verifiable**: You know when it's done
- **Atomic**: One clear action per task

Format:
1. **Task title** — Description of what to do and expected outcome
2. **Task title** — Description of what to do and expected outcome
...

### Trade-offs
What alternatives did you consider? Why did you choose this approach?
- Option A vs Option B: why you chose A
- What you're sacrificing for this approach

### Risks
What could go wrong? How to mitigate?
- Risk 1 → Mitigation strategy
- Risk 2 → Mitigation strategy

## ════════════════════════════════════════════════════════════════
## TASK LIST RULES
## ════════════════════════════════════════════════════════════════

- Minimum 3 tasks, maximum 10 tasks
- Each task should take roughly 1-3 tool calls to complete
- Tasks must be in dependency order (what must be done first)
- Don't create trivial tasks like "read the file" — that's part of execution
- Focus on the actual work: implementation, testing, integration
- Include a verification/testing task at the end when appropriate

## Context-Specific Guidance

### For QA/Testing Tasks
- Include steps for reading config tables or game data
- Plan Hunter execution steps explicitly
- Include result analysis as a dedicated task
- End with a report generation task

### For Code Modification Tasks
- Start with understanding the current implementation
- Plan modifications in dependency order
- Include integration testing steps
- Consider rollback strategy

### For Analysis Tasks
- Plan data gathering steps first
- Structure analysis into logical segments
- Include comparison/validation steps
- End with structured output generation
"""

# ═══════════════════════════════════════════════════════════════════
# Agent Definition
# ═══════════════════════════════════════════════════════════════════

PlanAgentDefinition = AgentDefinition(
    name="PlanAgent",
    description=(
        "Software architect and planning specialist. "
        "Analyzes tasks deeply, researches the codebase, and produces "
        "structured implementation plans with ordered task lists."
    ),
    instructions=PLAN_AGENT_SYSTEM_PROMPT,
    tool_names=["file_read", "grep", "glob_search", "bash"],  # READ-ONLY subset
    permission_mode="default",
    agent_type="worker",
    max_turns=15,
    inject_history=True,
    when_to_use=(
        "需要为复杂任务做架构分析和实施规划时使用。"
        "适用于多步骤任务、代码修改规划、测试策略设计等场景。"
    ),
    tags=["planning", "architecture", "read-only"],
)


# ═══════════════════════════════════════════════════════════════════
# Plan Output Parser
# ═══════════════════════════════════════════════════════════════════


def parse_plan_output(response_text: str) -> Optional[TaskPlan]:
    """Parse PlanAgent's text output into a TaskPlan data structure.

    Uses heuristic parsing to extract:
    1. Goal from "Implementation Strategy" section
    2. Strategy summary
    3. Tasks from "Step-by-Step Tasks" section

    Args:
        response_text: The raw text output from PlanAgent.

    Returns:
        TaskPlan instance, or None if parsing fails.
    """
    if not response_text or not response_text.strip():
        logger.warning("parse_plan_output: empty response")
        return None

    try:
        goal = _extract_goal(response_text)
        strategy = _extract_strategy(response_text)
        tasks = _extract_tasks(response_text)

        if not tasks:
            logger.warning("parse_plan_output: no tasks found in output")
            return None

        task_items = [
            TaskItem(id=i, description=desc)
            for i, desc in enumerate(tasks, start=1)
        ]

        plan = TaskPlan(
            goal=goal,
            strategy=strategy,
            tasks=task_items,
            created_at=time.time(),
        )

        # Auto-activate first task
        if plan.tasks:
            plan.tasks[0].status = "active"
            plan.tasks[0].started_at = time.time()
            plan.current_task_id = plan.tasks[0].id

        logger.info(
            "parse_plan_output: parsed %d tasks, goal='%s'",
            len(task_items), goal[:60],
        )
        return plan

    except Exception as e:
        logger.warning("parse_plan_output: failed to parse: %s", e)
        return None


def _extract_goal(text: str) -> str:
    """Extract goal from Implementation Strategy section."""
    # Look for the Implementation Strategy header
    pattern = r"###?\s*Implementation Strategy\s*\n(.*?)(?=\n###?\s|\Z)"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    if match:
        # Take first sentence/paragraph as goal
        content = match.group(1).strip()
        # First line or first sentence
        first_line = content.split("\n")[0].strip()
        if len(first_line) > 20:
            return first_line[:200]
    # Fallback: first non-empty line
    for line in text.split("\n"):
        line = line.strip()
        if line and not line.startswith("#"):
            return line[:200]
    return "Task plan"


def _extract_strategy(text: str) -> str:
    """Extract strategy summary from Implementation Strategy section."""
    pattern = r"###?\s*Implementation Strategy\s*\n(.*?)(?=\n###?\s|\Z)"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    if match:
        content = match.group(1).strip()
        # Take up to 3 lines as strategy
        lines = [l.strip() for l in content.split("\n") if l.strip()]
        return " ".join(lines[:3])[:500]
    return ""


def _extract_tasks(text: str) -> list[str]:
    """Extract task list from Step-by-Step Tasks section.

    Supports formats:
    - "1. **Task title** — description"
    - "1. Task title — description"
    - "1. Task description"
    - "- Task description"
    """
    # Try to find the Step-by-Step Tasks section
    pattern = r"###?\s*Step-by-Step Tasks?\s*\n(.*?)(?=\n###?\s|\Z)"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)

    if match:
        section = match.group(1)
    else:
        # Fallback: look for any numbered list in the text
        section = text

    tasks = []

    # Pattern 1: Numbered items with optional bold title
    # Matches: "1. **Title** — Description" or "1. Title — Description" or "1. Description"
    numbered_pattern = r"^\s*\d+\.\s+(?:\*\*)?(.+?)(?:\*\*)?\s*$"
    for line in section.split("\n"):
        line = line.strip()
        m = re.match(numbered_pattern, line)
        if m:
            task_text = m.group(1).strip()
            # Clean up markdown formatting
            task_text = re.sub(r"\*\*", "", task_text)
            # Remove trailing dashes from title-only lines
            task_text = task_text.rstrip(" —-")
            if len(task_text) > 5:  # Skip trivially short items
                tasks.append(task_text)

    if not tasks:
        # Pattern 2: Bullet items
        bullet_pattern = r"^\s*[-*]\s+(.+)$"
        for line in section.split("\n"):
            m = re.match(bullet_pattern, line.strip())
            if m:
                task_text = m.group(1).strip()
                task_text = re.sub(r"\*\*", "", task_text)
                if len(task_text) > 5:
                    tasks.append(task_text)

    return tasks
