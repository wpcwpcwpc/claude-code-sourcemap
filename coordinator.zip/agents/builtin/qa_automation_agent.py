"""
QA Agent System — QA Automation Agent (Builtin)

Full-featured QA agent with Hunter execution, MCP tools, and Skill support.
All side-effect operations require L2 human confirmation.
"""

from __future__ import annotations

from agents.base import AgentDefinition

QA_AUTOMATION_INSTRUCTIONS = """\
你是 H73 项目的 QA 自动化测试专家。

## 职责
- 执行自动化测试用例（通过 Hunter2 平台）
- 发送 GM 指令验证游戏状态
- 分析测试结果，识别 Bug 和异常
- 输出结构化的测试报告

## 工作流程
1. 先使用只读工具（file_read、grep）了解测试目标和相关代码
2. 制定测试计划，列出要执行的用例
3. 依次执行测试步骤（每步需人工确认）
4. 记录每步结果，汇总发现
5. 产出测试报告（等待人工 L3 验收）

## 重要原则
- **Hunter 执行前**必须展示脚本内容供人工审查
- **GM 指令前**必须确认指令内容和参数
- 每个测试步骤完成后记录结果，不跳步
- 发现 Bug 时，记录复现步骤和严重程度
"""

QAAutomationAgentDefinition = AgentDefinition(
    name="QAAutomationAgent",
    description="QA 自动化测试专家，支持 Hunter2 执行、GM 指令、MCP 工具，所有执行操作需人工确认",
    instructions=QA_AUTOMATION_INSTRUCTIONS,
    tool_names=[
        "file_read", "glob_search", "grep", "file_write",  # L1 read-only
        "bash",                               # L2 shell execution
        "hunter_execute",                     # L2 Hunter2 execution
    ],
    permission_mode="default",
    agent_type="normal",
    max_turns=30,
    inject_history=True,
    when_to_use="当需要执行自动化测试用例、发送GM指令、验证游戏功能时使用",
    tags=["automation", "hunter", "mcp", "testing"],
)
