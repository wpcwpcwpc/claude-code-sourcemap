"""
QA Agent System — Agent Definition Base

Defines AgentDefinition dataclass and the create_agent_from_definition()
factory function that converts a definition into a fully configured Agno Agent.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class AgentDefinition:
    """Declarative definition of an Agent's capabilities and behavior.

    Used by both builtin agents and hot-loaded AGENT.md custom agents.
    """
    name: str
    description: str
    instructions: str

    # Tool configuration
    tool_names: List[str] = field(default_factory=list)   # from tool registry
    extra_tools: List[Any] = field(default_factory=list)  # direct callables

    # Behavior
    permission_mode: str = "default"   # "default" | "plan" | "bypass"
    agent_type: str = "normal"         # "normal" | "worker"
    max_turns: int = 25

    # Model configuration
    # "inherit" → use parent agent's model; None → use default from config
    model_id: Optional[str] = None

    # Metadata for API listing
    when_to_use: str = ""
    tags: List[str] = field(default_factory=list)

    # Memory injection
    inject_history: bool = True  # whether to inject Milvus historical context

    # Agno Skills (native skill system — provides get_skill_instructions etc.)
    skills: Optional[Any] = None  # agno.skills.Skills instance


async def create_agent_from_definition(
    definition: AgentDefinition,
    *,
    session_id: Optional[str] = None,
    task_description: str = "",
    game_version: str = "",
    module: str = "",
    config=None,
    parent_model: Optional[Any] = None,
) -> Any:
    """Create a fully configured Agno Agent from an AgentDefinition.

    Handles:
    - Tool assembly from registry + extra_tools
    - Milvus historical context injection (if inject_history=True)
    - Hook assembly (L2 permission, execution log, context threshold, result verify)
    - Session state initialization

    Args:
        definition: The agent definition to instantiate.
        session_id: Override session ID (auto-generated if None).
        task_description: Used for Milvus context injection search.
        game_version: H73 game version context.
        module: Game module context.
        config: Settings override.

    Returns:
        Configured Agno Agent instance.
    """
    from core.engine import create_normal_agent
    from tools.registry import tool_registry

    sid = session_id or str(uuid.uuid4())

    # Assemble tools from registry
    tools = tool_registry.get_tools_by_names(definition.tool_names)
    tools.extend(definition.extra_tools)

    # Build extra instructions (including historical context injection)
    extra_instructions = ""
    if definition.inject_history and task_description:
        try:
            from memory.injector import inject_historical_context
            historical_ctx = await inject_historical_context(
                task_description=task_description,
                game_version=game_version,
                module=module,
            )
            if historical_ctx:
                extra_instructions = historical_ctx
        except Exception:
            logger.warning("Failed to inject historical context for agent '%s'", definition.name)

    # Assemble run-level post_hooks
    from hooks.context_threshold_hook import context_threshold_post_hook
    from hooks.result_verify_hook import result_verify_post_hook

    async def combined_post_hook(agent: Any, run_output: Any) -> None:
        await context_threshold_post_hook(agent, run_output)
        await result_verify_post_hook(agent, run_output)

    # Resolve model: "inherit" uses parent's model, else use default from config
    resolved_model = None
    if definition.model_id == "inherit" and parent_model is not None:
        resolved_model = parent_model
        logger.info(
            "Agent '%s' inheriting model from parent: %s",
            definition.name, type(parent_model).__name__,
        )

    # Build the Agent via engine factory
    agent = create_normal_agent(
        config=config,
        tools=tools,
        extra_instructions=definition.instructions + (
            f"\n\n{extra_instructions}" if extra_instructions else ""
        ),
        session_id=sid,
        post_hook=combined_post_hook,
        agent_name=definition.name,
        permission_mode=definition.permission_mode,
        game_version=game_version,
        module=module,
        skills=definition.skills,
    )

    # Override model if resolved from inheritance
    if resolved_model is not None:
        agent.model = resolved_model

    # Override agent_type in session state
    if hasattr(agent, "session_state") and agent.session_state:
        agent.session_state.agent_type = definition.agent_type
        agent.session_state.max_turns = definition.max_turns

    logger.info(
        "Created agent '%s' (type=%s, tools=%d, session=%s)",
        definition.name, definition.agent_type, len(tools), sid,
    )
    return agent
