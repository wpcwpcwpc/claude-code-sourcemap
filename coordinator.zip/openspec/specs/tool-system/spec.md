## ADDED Requirements

### Requirement: 工具元数据定义
系统 SHALL 为每个 Agno `@tool` 定义的工具附加元数据字典（`permission_level`（L1-L4）、`is_read_only`、`is_concurrency_safe`、`is_destructive`），元数据通过工具注册表（`tools/registry.py`）维护，供 pre_hook/post_hook 消费。

#### Scenario: 工具属性标注
- **WHEN** 定义一个新的 `hunter_execute` 工具
- **THEN** 该工具 SHALL 在注册表中标注 `permission_level=2`、`is_read_only=False`、`is_concurrency_safe=False`

#### Scenario: 只读工具标注
- **WHEN** 定义 `file_read` 工具
- **THEN** 该工具 SHALL 标注 `permission_level=1`、`is_read_only=True`、`is_concurrency_safe=True`

---

### Requirement: 内置 QA 工具集
系统 SHALL 提供以下内置工具，均使用 Agno `@tool` 装饰器定义：`file_read`（L1）、`file_edit`（L2）、`bash`（L2）、`grep`（L1）、`glob`（L1）、`hunter_execute`（L2）、`agent_spawn`（L1）。

#### Scenario: file_read 执行
- **WHEN** Agent 调用 `file_read(path="qa_debug/Case001.py")`
- **THEN** 系统 SHALL 读取文件内容，返回结构化结果，超过 `max_result_size`（默认100KB）时截断并提示

#### Scenario: hunter_execute 权限拦截
- **WHEN** Agent 调用 `hunter_execute(script="...")` 且 `permission_mode` 非 `bypass`
- **THEN** Tool pre_hook SHALL 触发 asyncio.Event 暂停，展示脚本预览，等待人工确认后再执行

#### Scenario: bash 安全限制
- **WHEN** Agent 调用 `bash(command="rm -rf /")`
- **THEN** 系统 SHALL 拒绝执行（命令黑名单检查），返回错误信息

---

### Requirement: MCP 工具动态加载
系统 SHALL 通过 Agno `MCPTools` 连接配置的 MCP 服务器，将 MCP 工具动态加载并注入 Agent 工具集，支持 stdio 和 sse 传输协议。

#### Scenario: game_debug_mcp 接入
- **WHEN** 配置中包含 `game_debug_mcp` stdio 类型 MCP 服务器
- **THEN** 系统 SHALL 通过 Agno `MCPTools(transport=StdioServerParameters(...))` 连接该 MCP 服务器，将 `send_gm_cmd`、`repl_execute`、`list_gm_categories` 等工具加载为 Agent 可用工具

#### Scenario: MCP 工具权限标注
- **WHEN** MCP 工具的 `annotations.readOnlyHint` 为 false
- **THEN** 该工具 SHALL 在注册表中自动获得 L2 权限级别（通过 pre_hook 需要人工确认）

#### Scenario: MCP 服务器连接失败
- **WHEN** MCP 服务器启动失败
- **THEN** 系统 SHALL 记录 error 日志，跳过该服务器的工具，不影响其他工具和 Agent 执行

---

### Requirement: 工具注册表
系统 SHALL 维护全局工具注册表（`tools/registry.py`），支持按 `agent_type` 过滤工具集：`coordinator` Leader Agent 仅通过 Team 机制委派任务（无需手动工具过滤）；`normal` 类型返回全部工具（含 MCP 工具和 Skill 工具）。

#### Scenario: Normal 模式工具集
- **WHEN** `agent_type="normal"` 且配置了 `game_debug_mcp`
- **THEN** `get_tools(agent_type="normal")` SHALL 返回内置工具 + MCP 工具 + Skill 工具的合集

#### Scenario: Worker Agent 工具集
- **WHEN** Worker Agent 被 Coordinator Team 创建
- **THEN** 该 Worker 的工具集 SHALL 根据其 Agent 定义（来自注册表）自动配置，包含对应的内置工具和 MCP 工具

---

### Requirement: 工具并发安全控制
系统 SHALL 在工具执行时，根据工具注册表中的 `is_concurrency_safe` 属性决定工具的并发执行策略：并发安全的工具可并行执行，否则串行执行。

#### Scenario: 并发安全工具并行
- **WHEN** LLM 一次响应中调用多个 `is_concurrency_safe=True` 的工具（如 `file_read`、`grep`）
- **THEN** 系统 SHALL 使用 `asyncio.gather` 并发执行，提高效率

#### Scenario: 非并发安全工具串行
- **WHEN** LLM 一次响应中包含 `is_concurrency_safe=False` 的工具（如 `hunter_execute`）
- **THEN** 系统 SHALL 串行执行该工具，等待完成后再执行下一个

---

## MODIFIED Requirement: file_edit 工具改为搜索-替换模式

> Synced from: qa-agent-optimization / tool-validation

当前 `file_edit` 采用全文覆写模式（接收 `path` + `content`），这导致 LLM 经常生成错误内容（遗漏原文、格式丢失）。改为 Claude Code 的 search/replace 模式，仅传输变更部分。

### Scenario: 正常搜索-替换编辑
- **GIVEN** 文件 `config.py` 已被 `file_read` 读取过
- **WHEN** Agent 调用 `file_edit(file_path="config.py", old_string="timeout = 30", new_string="timeout = 60")`
- **THEN** 系统 SHALL 在文件中精确查找 `old_string`，替换为 `new_string`，保留文件其余内容不变

### Scenario: 创建新文件
- **GIVEN** 文件 `new_module.py` 不存在
- **WHEN** Agent 调用 `file_edit(file_path="new_module.py", old_string="", new_string="# new file content\n...")`
- **THEN** 系统 SHALL 创建文件并写入 `new_string` 内容（`old_string` 为空字符串表示创建）

### Scenario: 多重匹配拒绝
- **GIVEN** 文件中 `old_string` 出现了 3 次
- **WHEN** Agent 调用 `file_edit` 且未设置 `replace_all=True`
- **THEN** 系统 SHALL 返回引导性错误信息：`"Found 3 matches for old_string. Include more surrounding context to make it unique, or set replace_all=True."`

---

## ADDED Requirement: validateInput 验证层

> Synced from: qa-agent-optimization / tool-validation

每个工具 SHALL 在执行前运行 `validate_input()` 方法，执行业务约束检查。验证失败时返回**引导性错误信息**（而非 Python traceback），引导 LLM 自我纠正。

### Scenario: file_edit 先读后写强制
- **GIVEN** Agent 未对文件 `app.py` 调用过 `file_read`
- **WHEN** Agent 调用 `file_edit(file_path="app.py", old_string="...", new_string="...")`
- **THEN** validate_input SHALL 返回: `"You must read the file before editing it. Use file_read(path='app.py') first."`

### Scenario: file_edit 文件外部修改检测
- **GIVEN** Agent 在 T1 时刻读取了 `app.py`
- **AND** 外部进程在 T2 时刻修改了 `app.py`
- **WHEN** Agent 在 T3 时刻调用 `file_edit(file_path="app.py", ...)`
- **THEN** validate_input SHALL 检测到文件 mtime > 读取时间戳，返回: `"File has been modified since you last read it. Read it again with file_read before editing."`

### Scenario: file_edit old_string 不存在
- **GIVEN** 文件内容不包含 `old_string`
- **WHEN** Agent 调用 `file_edit(file_path="app.py", old_string="nonexistent code", new_string="...")`
- **THEN** validate_input SHALL 返回: `"The old_string was not found in the file. Make sure it matches exactly, including whitespace and indentation. Re-read the file to verify."`

### Scenario: file_edit 空操作检测
- **GIVEN** Agent 调用 `file_edit` 且 `old_string == new_string`
- **THEN** validate_input SHALL 返回: `"No changes to make: old_string and new_string are identical."`

### Scenario: bash 静默命令无输出
- **GIVEN** Agent 调用 `bash(command="mkdir -p /tmp/test")`
- **AND** 命令成功执行且无 stdout/stderr
- **THEN** 系统 SHALL 返回 `"(command completed successfully, no output)"` 而非空字符串

---

## ADDED Requirement: 读取状态跟踪器（ReadFileStateCache）

> Synced from: qa-agent-optimization / tool-validation

系统 SHALL 维护一个全局 `ReadFileStateCache`，记录每个文件的最近一次读取时间戳和内容摘要，供 `file_edit` 的 validate_input 使用。

### Scenario: 读取状态记录
- **WHEN** Agent 调用 `file_read(path="app.py")`
- **THEN** ReadFileStateCache SHALL 记录 `{"path": "app.py", "timestamp": <mtime>, "content_hash": <sha256>, "offset": 0, "limit": 500}`

### Scenario: 读取状态查询
- **WHEN** `file_edit` 的 validate_input 检查 `app.py`
- **THEN** 系统 SHALL 从 ReadFileStateCache 获取该文件的最近读取记录，与当前文件 mtime 比较

### Scenario: 部分读取标记
- **GIVEN** Agent 调用 `file_read(path="app.py", offset=100, limit=50)` 只读取了部分内容
- **WHEN** 随后调用 `file_edit` 修改该文件
- **THEN** validate_input SHALL 标记为 `is_partial_view=True`，并警告: `"You only read lines 101-150 of this file. Make sure old_string is within the range you have read."`

---

## ADDED Requirement: Semantic 参数解析

> Synced from: qa-agent-optimization / tool-validation

工具参数解析 SHALL 支持 LLM 常见的类型变体，自动规范化为正确类型，避免因类型不匹配导致的调用失败。

### Scenario: Boolean 语义解析
- **WHEN** LLM 传入 `run_in_background="true"` (字符串) 或 `"yes"` 或 `"1"`
- **THEN** 参数解析器 SHALL 将其规范化为 Python `True`

### Scenario: Number 语义解析
- **WHEN** LLM 传入 `timeout="30"` (字符串)
- **THEN** 参数解析器 SHALL 将其规范化为 Python `int(30)`

### Scenario: 未知参数拒绝
- **WHEN** LLM 传入工具未定义的额外参数（如 `file_read(path="a.py", verbose=True)`）
- **THEN** 参数解析器 SHALL 忽略未知参数并记录 warning 日志，不阻塞执行

---

## ADDED Requirement: System Prompt 工具使用指南

> Synced from: qa-agent-optimization / tool-validation

Agent 的 System Prompt SHALL 包含明确的工具使用指南，告诉 LLM 用哪个专用工具做哪件事，并列出常见错误的避免方式。

### Scenario: 工具优先级指导
- **WHEN** 构建 Agent System Prompt
- **THEN** SHALL 包含以下指导规则:
  - "使用 `file_read` 读取文件，不要用 `bash` 执行 `cat`/`head`/`tail`"
  - "使用 `file_edit` 编辑文件，不要用 `bash` 执行 `sed` 或 `awk`"
  - "使用 `grep` 搜索文件内容，不要用 `bash` 执行 `grep` 或 `rg`"
  - "使用 `glob_search` 查找文件，不要用 `bash` 执行 `find` 或 `ls`"
  - "仅在需要执行系统命令（安装依赖、运行测试、git 操作）时使用 `bash`"

### Scenario: 先读后写指导
- **WHEN** 构建 Agent System Prompt
- **THEN** SHALL 包含: "编辑文件前必须先读取 — 先理解，后修改（measure twice, cut once）"

### Scenario: 并行调用指导
- **WHEN** 构建 Agent System Prompt
- **THEN** SHALL 包含: "你可以在一次响应中调用多个工具。如果工具之间没有依赖关系，请并行调用以提高效率。"

---

## ADDED Requirement: 命令分类器（bash_classifier）

> Synced from: qa-agent-optimization / bash-intelligence

系统 SHALL 提供 `tools/bash_classifier.py` 模块，将任意 shell 命令分类为 6 个语义类别，用于并发安全判定、权限级别推断、UI 展示和超时策略。

### Scenario: SEARCH 命令分类
- **WHEN** 命令为 `grep -r "def test_" .` 或 `find . -name "*.py"` 或 `rg pattern`
- **THEN** classify_command SHALL 返回 `CommandCategory.SEARCH`

### Scenario: READ 命令分类
- **WHEN** 命令为 `cat config.py` 或 `head -20 log.txt` 或 `wc -l *.py` 或 `jq '.name' config.json`
- **THEN** classify_command SHALL 返回 `CommandCategory.READ`

### Scenario: LIST 命令分类
- **WHEN** 命令为 `ls -la` 或 `tree src/` 或 `du -sh *`
- **THEN** classify_command SHALL 返回 `CommandCategory.LIST`

### Scenario: NEUTRAL 命令分类
- **WHEN** 命令为 `echo "hello"` 或 `printf "%s" "$VAR"` 或 `true`
- **THEN** classify_command SHALL 返回 `CommandCategory.NEUTRAL`

### Scenario: SILENT 命令分类
- **WHEN** 命令为 `mkdir -p /tmp/test` 或 `cp a.txt b.txt` 或 `chmod 755 script.sh`
- **THEN** classify_command SHALL 返回 `CommandCategory.SILENT`

### Scenario: WRITE 命令分类（默认）
- **WHEN** 命令不属于以上任何类别（如 `python run.py` 或 `npm install` 或 `pip install requests`）
- **THEN** classify_command SHALL 返回 `CommandCategory.WRITE`（安全默认）

### 分类常量定义

系统 SHALL 维护以下命令集合常量：

| 集合名 | 包含命令 | 属性 |
|--------|---------|------|
| `SEARCH_COMMANDS` | find, grep, rg, ag, ack, locate, which, whereis | is_read_only=True |
| `READ_COMMANDS` | cat, head, tail, less, more, wc, stat, file, strings, jq, awk, cut, sort, uniq, tr | is_read_only=True |
| `LIST_COMMANDS` | ls, tree, du, dir | is_read_only=True |
| `NEUTRAL_COMMANDS` | echo, printf, true, false, : | 不改变管道语义 |
| `SILENT_COMMANDS` | mv, cp, rm, mkdir, rmdir, chmod, chown, chgrp, touch, ln, cd, export, unset, wait | 成功时无输出 |

---

## ADDED Requirement: 管道分析器（Pipeline Analyzer）

> Synced from: qa-agent-optimization / bash-intelligence

系统 SHALL 提供管道感知的命令分析能力，正确判断包含 `|`、`&&`、`||`、`;` 的复合命令的整体只读性。

### Scenario: 纯只读管道
- **WHEN** 命令为 `grep "pattern" file.txt | sort | head -5`
- **THEN** is_read_only_command SHALL 返回 `True`（所有段均为只读命令）

### Scenario: 混合管道判断为非只读
- **WHEN** 命令为 `grep "pattern" file.txt | xargs rm`
- **THEN** is_read_only_command SHALL 返回 `False`（`xargs rm` 不是只读命令）

### Scenario: 语义中性命令跳过
- **WHEN** 命令为 `echo "start" && grep -r "test" . && echo "done"`
- **THEN** is_read_only_command SHALL 返回 `True`（echo 是语义中性命令，不影响判定；grep 是只读）

### Scenario: 重定向感知
- **WHEN** 命令为 `grep "pattern" file.txt > output.txt`
- **THEN** is_read_only_command SHALL 返回 `False`（重定向到文件是写操作）

### Scenario: 管道拆分逻辑
- **WHEN** 分析器处理命令 `cmd_a | cmd_b && cmd_c || cmd_d ; cmd_e`
- **THEN** 系统 SHALL 正确拆分为 `[cmd_a, cmd_b, cmd_c, cmd_d, cmd_e]`，并忽略操作符符号本身

---

## ADDED Requirement: sed -i 拦截器

> Synced from: qa-agent-optimization / bash-intelligence

系统 SHALL 检测 LLM 生成的 `sed -i` 命令，自动转换为 `file_edit` 操作，走正规的编辑验证流程。

### Scenario: sed -i 替换拦截
- **WHEN** Agent 调用 `bash(command="sed -i 's/old/new/g' config.py")`
- **THEN** 系统 SHALL 拦截该命令，不执行 sed
- **AND** 返回引导性消息: `"Instead of sed -i, use the file_edit tool: file_edit(file_path='config.py', old_string='old', new_string='new', replace_all=True). This ensures proper validation and undo support."`

### Scenario: 非 -i sed 允许通过
- **WHEN** Agent 调用 `bash(command="sed 's/old/new/g' input.txt")` （无 -i 标志，只输出到 stdout）
- **THEN** 系统 SHALL 正常执行（这是只读的 sed 用法）

---

## ADDED Requirement: 后台任务管理器（BackgroundTaskManager）

> Synced from: qa-agent-optimization / bash-intelligence

系统 SHALL 提供 `tools/background_tasks.py` 模块，管理后台执行的长时间命令，支持任务启动、状态查询、结果获取和超时清理。

### Scenario: 启动后台任务
- **WHEN** Agent 调用 `bash(command="npm install", run_in_background=True)`
- **THEN** BackgroundTaskManager SHALL 在独立线程/进程中执行命令，立即返回 `task_id`

### Scenario: 查询任务状态
- **WHEN** Agent 调用 `bash(command="bg_status <task_id>")`
- **THEN** 系统 SHALL 返回任务状态: `running` / `completed` / `failed` / `timeout`，以及已运行时间和当前输出

### Scenario: 任务超时
- **GIVEN** 后台任务运行超过 `TIMEOUT_BACKGROUND`（120秒）
- **THEN** BackgroundTaskManager SHALL 终止任务进程，标记状态为 `timeout`，保留已获取的输出

### Scenario: 自动后台化
- **GIVEN** 一个同步执行的命令在 `BLOCKING_BUDGET_MS`（15秒）内未完成
- **AND** 该命令不在禁止自动后台化列表中（如 `sleep`）
- **THEN** 系统 SHALL 自动切换为后台执行，返回 `task_id` 并提示 Agent: `"Command auto-backgrounded after 15s. Task ID: <id>. Use bg_status <id> to check progress."`

### Scenario: sleep 命令禁止自动后台化
- **GIVEN** Agent 调用 `bash(command="sleep 30 && run_test.sh")`
- **AND** 命令运行超过 15 秒
- **THEN** 系统 SHALL **不** 自动后台化（sleep 是刻意等待），继续等待至显式超时

---

## MODIFIED Requirement: bash 工具超时策略增强

> Synced from: qa-agent-optimization / bash-intelligence

当前 bash 工具使用固定超时，改为基于命令分类的分级超时策略。

### Scenario: SILENT 命令短超时
- **WHEN** 命令分类为 SILENT（如 `mkdir -p dir`）
- **THEN** 默认超时 SHALL 为 2 秒

### Scenario: READ/SEARCH 命令中等超时
- **WHEN** 命令分类为 SEARCH 或 READ（如 `grep -r "pattern" .`）
- **THEN** 默认超时 SHALL 为 15 秒

### Scenario: WRITE 命令较长超时
- **WHEN** 命令分类为 WRITE（如 `python -m pytest tests/`）
- **THEN** 默认超时 SHALL 为 30 秒
- **AND** 超过 15 秒时应触发自动后台化检查

### Scenario: 用户显式超时优先
- **WHEN** Agent 显式传入 `timeout=120`
- **THEN** 系统 SHALL 使用用户指定的超时值，忽略分类默认值

---

## MODIFIED Requirement: bash 工具错误信息优化

> Synced from: qa-agent-optimization / bash-intelligence

bash 工具的错误输出 SHALL 提供引导性信息，帮助 LLM 理解问题并自我纠正。

### Scenario: 超时错误引导
- **WHEN** 命令超时
- **THEN** 返回信息 SHALL 包含:
  - 实际超时时长
  - 命令分类
  - 如果是可后台化命令: 建议 `"Consider re-running with run_in_background=True"`
  - 如果是只读命令超时: 建议 `"The search may be too broad. Try narrowing the pattern or path."`

### Scenario: 命令不存在引导
- **WHEN** 命令执行返回 `command not found`
- **THEN** 返回信息 SHALL 包含: `"Command not found. Check if the tool is installed. On this system, available shells are: <list>."`

### Scenario: 非零退出码信息
- **WHEN** 命令以非零退出码完成
- **AND** 退出码有已知语义（如 grep 返回 1 表示无匹配）
- **THEN** 返回信息 SHALL 包含解释: `"Exit code 1 for grep means no matches found (not an error)."`

### 已知退出码语义表

| 命令 | 退出码 | 含义 | 是否应报为错误 |
|------|--------|------|---------------|
| grep | 1 | 无匹配 | 否 |
| diff | 1 | 文件有差异 | 否 |
| test / [ | 1 | 条件为假 | 否 |
| timeout | 124 | 命令超时 | 是 |

---

## ADDED Requirement: bash description 字段强制

> Synced from: qa-agent-optimization / bash-intelligence

bash 工具 SHALL 包含 `description` 参数，LLM 在调用 bash 时应提供对命令意图的简短描述。

### Scenario: description 用于审核展示
- **GIVEN** permission_mode 为 `ask`（L2 需要人工确认）
- **WHEN** Agent 调用 `bash(command="pip install requests", description="Install HTTP library for API testing")`
- **THEN** HIL 审核界面 SHALL 展示 description 而非原始命令作为标题
- **AND** 原始命令作为详情展示

### Scenario: description 为空时的容错
- **WHEN** LLM 未提供 description（空字符串）
- **THEN** 系统 SHALL 不阻塞执行，使用命令前 80 字符作为 fallback description
