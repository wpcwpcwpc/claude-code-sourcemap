# Tasks: QA Agent P1 — Plan Agent + Task Management

## 1. TaskPlan 数据模型

- [x] 1.1 实现 `core/task_plan.py`：TaskItem dataclass（id, description, status, result_summary, tools_used, started_at, completed_at）；TaskPlan dataclass（goal, strategy, tasks, created_at, current_task_id）
- [x] 1.2 实现 TaskPlan 方法：`advance_to_next()` 自动推进下一个 pending→active；`mark_task(id, status, summary)` 更新任务状态；`is_complete` property 判断全部完成
- [x] 1.3 实现 `to_prompt_context()` 方法：生成可注入 System Prompt 的 Task Progress 文本（[x]/[>]/[ ] 格式 + 进度统计 + "← YOU ARE HERE" 标注）
- [x] 1.4 实现 `to_dict()` / `from_dict()` 序列化方法：支持 session_state JSON 持久化
- [x] 1.5 编写 `tests/test_task_plan.py`：覆盖状态流转、自动推进、完成判定、prompt 上下文生成、序列化/反序列化

## 2. Task 工具

- [x] 2.1 实现 `tools/task_tools.py`：`task_list()` 工具（L1 只读）——有计划时返回状态摘要，无计划时返回创建引导
- [x] 2.2 实现 `task_update(task_id, status, summary)` 工具（L1）——task_id=0+status="create" 时从 summary JSON 创建 TaskPlan；其他情况更新对应 task 状态并自动推进
- [x] 2.3 实现 task_update 验证逻辑：无效 task_id 引导性错误；创建时 JSON 解析失败引导；task 状态值校验
- [x] 2.4 编写 `tests/test_task_tools.py`：覆盖创建计划、标记完成/失败/跳过、自动推进、所有完成、无效 ID、JSON 解析失败

## 3. Session State 集成

- [x] 3.1 修改 `core/session_state.py`：QASessionState 添加 `task_plan: Optional[Dict] = None` 字段（存储 TaskPlan.to_dict() 的结果）
- [x] 3.2 修改 `tools/task_tools.py` 中的工具函数：从 agent.session_state 读写 task_plan（使用 TaskPlan.from_dict/to_dict）

## 4. System Prompt 集成

- [x] 4.1 修改 `core/prompts.py`：新增 `get_task_management_section()` 函数——生成 "## Task Management" 指导部分（调用 task_list 检查→创建计划→按 task 执行→标记完成）
- [x] 4.2 修改 `core/engine.py`：在 instructions 构建中追加 `get_task_management_section()` 输出；如果 session_state 中有 task_plan，追加 `TaskPlan.from_dict(task_plan).to_prompt_context()`
- [x] 4.3 编写 `tests/test_prompts.py` 增量测试：验证 get_task_management_section 包含关键关键字（task_list, task_update, create）

## 5. PlanAgent 定义

- [x] 5.1 创建 `agents/builtin/plan_agent.py`：PLAN_AGENT_SYSTEM_PROMPT 常量（300+ 行，包含身份定位、READ-ONLY 声明、输出格式模板、Task List 格式要求 3-10 步）
- [x] 5.2 定义 PlanAgentDefinition（AgentDefinition）：name="PlanAgent", tool_names=["file_read","grep","glob_search","bash"], model_id="inherit", agent_type="worker", max_turns=15, inject_history=True
- [x] 5.3 实现 `parse_plan_output(response_text)` 函数：正则/启发式解析 PlanAgent 输出→TaskPlan；解析失败返回 None + warning log
- [x] 5.4 编写 `tests/test_plan_agent.py`：覆盖 PlanAgentDefinition 字段校验、parse_plan_output 正常解析/容错/空输出

## 6. ExploreAgent 定义

- [ ] 6.1 创建 `agents/builtin/explore_agent.py`：EXPLORE_AGENT_SYSTEM_PROMPT 常量（快速搜索身份 + READ-ONLY 声明 + "快速>准确"哲学）
- [ ] 6.2 定义 ExploreAgentDefinition（AgentDefinition）：name="ExploreAgent", tool_names=["file_read","grep","glob_search","bash"], model_id=None, agent_type="worker", max_turns=10, inject_history=False

## 7. Agent 注册 + agent_spawn 更新

- [ ] 7.1 修改 `agents/registry.py`：在 _register_builtins() 中 import 并注册 PlanAgentDefinition 和 ExploreAgentDefinition
- [ ] 7.2 修改 `tools/agent_spawn_tool.py`：更新 description 字符串，在 Available agents 中添加 PlanAgent 和 ExploreAgent
- [ ] 7.3 修改 `api/server.py` 工具注册：将 task_list 和 task_update 注册到 tool_registry（L1，非 coordinator_visible）

## 8. Coordinator 集成

- [ ] 8.1 修改 `coordinator/team_builder.py`：在 create_coordinator_team() 中，Workers 创建前先 spawn PlanAgent 执行规划；调用 parse_plan_output 解析输出；成功时将 to_prompt_context() 追加到 COORDINATOR_SYSTEM_PROMPT
- [ ] 8.2 修改默认 Worker 列表：从 `["QAAutomationAgent", "ExploreAgent"]` 替代原硬编码值
- [ ] 8.3 实现 Plan 失败降级：parse_plan_output 返回 None 时 log warning 并继续无计划模式
