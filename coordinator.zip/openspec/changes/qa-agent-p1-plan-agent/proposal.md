## Why

Agent 执行复杂任务时缺乏全局规划能力——每轮工具调用是"想到哪做到哪"，没有 Task List 约束，导致执行逻辑不连贯、容易走偏或遗漏步骤。P0 解决了工具层面的可靠性（参数验证、Bash 智能化），P1 解决 Agent 层面的执行方向性问题：让 Agent 先规划再执行、按计划推进、每步可追踪。

## What Changes

- 新增 **TaskPlan / TaskItem 数据模型**：结构化的任务计划，支持 pending/active/done/failed/skipped 状态跟踪
- 新增 **task_list / task_update 专用工具**：Agent 通过工具创建和推进任务计划，确保计划状态可追踪
- 新增 **PlanAgent** builtin agent：READ-ONLY 架构师角色，inherit 主 Agent 模型，专门做前置规划
- 新增 **ExploreAgent** builtin agent：READ-ONLY 快速搜索角色，使用 cheap 模型，专门做代码库探索
- 修改 Normal 模式 System Prompt：注入 "先规划再执行" 约束 + 每轮 Task Context 注入
- 修改 Coordinator 模式：Phase 0 强制调用 PlanAgent 做前置规划，TaskPlan 传递给 Workers

## Capabilities

### New Capabilities
- `task-management`: 任务计划数据模型（TaskPlan/TaskItem）、task_list/task_update 工具、session_state 持久化、每轮 Task Context prompt 注入
- `plan-agent`: PlanAgent + ExploreAgent builtin agent 定义、READ-ONLY 工具集约束、结构化输出格式

### Modified Capabilities
- `agent-engine`: Normal Agent 的 System Prompt 注入 "先规划再执行" 约束，每轮开始注入 Task Context
- `coordinator-mode`: Coordinator Team Builder 增加 Phase 0 强制 Plan 步骤，TaskPlan 从 PlanAgent 传递给 Worker 分配

## Impact

- **新文件**: `core/task_plan.py`, `tools/task_tools.py`, `agents/builtin/plan_agent.py`, `agents/builtin/explore_agent.py`
- **修改文件**: `core/session_state.py`, `core/prompts.py`, `core/engine.py`, `agents/registry.py`, `coordinator/team_builder.py`, `tools/agent_spawn_tool.py`
- **依赖**: 无新外部依赖，全部基于现有 Agno 2.5.14 框架
- **兼容性**: 向后兼容——TaskPlan 为 Optional，现有 Agent 行为不受影响