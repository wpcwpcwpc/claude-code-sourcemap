# Delta Spec: coordinator-mode（Phase 0 Plan 步骤）

> 对应 main spec: `coordinator-mode`
> 变更类型: MODIFIED — Coordinator Team Builder 增加强制 Plan 前置步骤

---

## MODIFIED Requirements

### Requirement: Coordinator Team 创建流程

Coordinator Team 创建流程 SHALL 在组建 Worker Team 前执行 Phase 0: Plan。

#### Scenario: Phase 0 强制 Plan
- **WHEN** create_coordinator_team() 被调用
- **THEN** 系统 SHALL 先创建 PlanAgent 实例并执行规划任务
- **AND** 等待 PlanAgent 完成后，解析其输出为 TaskPlan
- **AND** 将 TaskPlan 的 to_prompt_context() 追加到 Coordinator System Prompt

#### Scenario: Plan 成功时注入 Task Context
- **GIVEN** PlanAgent 成功产出结构化规划
- **WHEN** TaskPlan 被解析为有效的 TaskPlan 实例
- **THEN** Coordinator Leader 的 instructions SHALL 包含完整的 Task Progress 上下文
- **AND** Leader SHALL 按 TaskPlan 中的 tasks 顺序分配工作给 Workers

#### Scenario: Plan 失败时降级
- **GIVEN** PlanAgent 执行失败或输出无法解析
- **WHEN** parse_plan_output 返回 None
- **THEN** 系统 SHALL 记录 warning 日志
- **AND** 继续创建 Coordinator Team（降级为无计划模式，行为等同当前实现）

#### Scenario: PlanAgent 使用 Leader 模型
- **WHEN** PlanAgent 被创建用于 Coordinator Phase 0
- **THEN** PlanAgent 的模型 SHALL 继承 Leader 的模型（model_id="inherit"）
- **AND** PlanAgent 的 session_id SHALL 为 coordinator session 的子 session

---

## ADDED Requirements

### Requirement: Coordinator 默认 Worker 列表更新

Coordinator Team 的默认 Worker 列表 SHALL 包含 ExploreAgent。

#### Scenario: 默认 Worker 列表
- **WHEN** create_coordinator_team() 被调用且未指定 worker_agent_names
- **THEN** 默认 Worker 列表 SHALL 为 ["QAAutomationAgent", "ExploreAgent"]（替代原来的硬编码列表）
