# Delta Spec: agent-engine（Task Context 注入）

> 对应 main spec: `agent-engine`
> 变更类型: MODIFIED — Agent System Prompt 增加 Task Management 约束和 Task Context 注入

---

## MODIFIED Requirements

### Requirement: Agent System Prompt 构建

系统 SHALL 在 Agent System Prompt 构建流程中注入 Task Management 指导和 Task Context。

#### Scenario: Task Management prompt 注入
- **WHEN** 构建 Normal Agent 的 System Prompt
- **THEN** SHALL 包含 "## Task Management" 部分
- **AND** SHALL 指导 Agent 第一步调用 task_list() 检查是否已有计划
- **AND** SHALL 指导 Agent 无计划时通过 task_update 创建计划
- **AND** SHALL 指导 Agent 完成每个 task 后调用 task_update 标记完成

#### Scenario: Task Context 动态注入
- **WHEN** session_state 中存在 TaskPlan
- **AND** Agent 进入新一轮 loop
- **THEN** System Prompt SHALL 包含当前 Task Progress 信息（goal、进度、任务列表、当前 active task）

#### Scenario: 无 TaskPlan 时不注入
- **WHEN** session_state 中不存在 TaskPlan
- **THEN** System Prompt SHALL 不包含 Task Progress 部分（仅包含 Task Management 指导）

---

## ADDED Requirements

### Requirement: Task 工具注册

系统 SHALL 将 task_list 和 task_update 工具注册到 ToolRegistry，作为所有 Agent 的默认工具。

#### Scenario: Normal Agent 工具集包含 Task 工具
- **WHEN** 创建 Normal Agent
- **THEN** 工具集 SHALL 包含 task_list 和 task_update

#### Scenario: Coordinator Agent 工具集不含 Task 工具
- **WHEN** 创建 Coordinator Leader
- **THEN** 工具集 SHALL 不包含 task_list 和 task_update（Coordinator 通过 PlanAgent 管理计划）

---

### Requirement: 新 Builtin Agents 注册

系统 SHALL 在 agents/registry.py 的 _register_builtins() 中注册 PlanAgent 和 ExploreAgent。

#### Scenario: Builtin Agent 自动注册
- **WHEN** agents.registry 模块被导入
- **THEN** AgentRegistry SHALL 包含 PlanAgent 和 ExploreAgent
- **AND** 它们 SHALL 出现在 agent_registry.to_api_list() 的返回结果中

#### Scenario: agent_spawn 工具描述更新
- **WHEN** agent_spawn 工具的 description 被构建
- **THEN** SHALL 包含 PlanAgent 和 ExploreAgent 在 Available agents 列表中
