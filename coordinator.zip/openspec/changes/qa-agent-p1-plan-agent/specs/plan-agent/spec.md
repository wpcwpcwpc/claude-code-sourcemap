# Delta Spec: plan-agent（PlanAgent + ExploreAgent）

> 变更类型: ADDED — 新增 PlanAgent 和 ExploreAgent builtin agent 定义

---

## ADDED Requirements

### Requirement: PlanAgent Builtin Definition

系统 SHALL 提供 `agents/builtin/plan_agent.py`，定义 PlanAgent 作为只读架构师角色的 builtin agent。

#### Scenario: PlanAgent 注册
- **WHEN** 系统启动并加载 builtin agents
- **THEN** AgentRegistry SHALL 包含 name="PlanAgent" 的 AgentDefinition
- **AND** 该定义的 agent_type SHALL 为 "worker"
- **AND** model_id SHALL 为 "inherit"

#### Scenario: PlanAgent 工具集限制
- **WHEN** PlanAgent 被创建
- **THEN** 其工具集 SHALL 仅包含只读工具：file_read, grep, glob_search, bash
- **AND** SHALL 不包含 file_edit, hunter_execute, agent_spawn

#### Scenario: PlanAgent 输出格式
- **WHEN** PlanAgent 完成分析
- **THEN** 其输出 SHALL 包含以下结构化部分：
  1. Implementation Strategy（高层方案）
  2. Key Files（关键文件列表）
  3. Step-by-Step Tasks（结构化任务列表，3-10 步）
  4. Trade-offs（方案权衡）
  5. Risks（风险和缓解措施）

#### Scenario: PlanAgent 只读强制
- **WHEN** PlanAgent System Prompt 被构建
- **THEN** SHALL 包含 READ-ONLY 模式严格声明
- **AND** SHALL 明确禁止任何文件修改或代码执行操作

---

### Requirement: PlanAgent System Prompt

系统 SHALL 为 PlanAgent 提供专用 System Prompt，引导 LLM 以架构师身份进行深度规划。

#### Scenario: 身份定位
- **WHEN** 构建 PlanAgent System Prompt
- **THEN** SHALL 包含 "software architect and planning specialist" 身份声明
- **AND** SHALL 强调 "深度 > 速度" 的工作哲学

#### Scenario: 输出结构约束
- **WHEN** 构建 PlanAgent System Prompt
- **THEN** SHALL 包含完整的输出格式模板
- **AND** SHALL 要求每个 Task 具备可验证的完成标准

#### Scenario: Task List 格式
- **WHEN** PlanAgent 输出 Step-by-Step Tasks 部分
- **THEN** 每个 task SHALL 包含编号、描述和预期产出
- **AND** tasks 总数 SHALL 在 3-10 之间

---

### Requirement: ExploreAgent Builtin Definition

系统 SHALL 提供 `agents/builtin/explore_agent.py`，定义 ExploreAgent 作为快速搜索角色的 builtin agent。

#### Scenario: ExploreAgent 注册
- **WHEN** 系统启动并加载 builtin agents
- **THEN** AgentRegistry SHALL 包含 name="ExploreAgent" 的 AgentDefinition
- **AND** 该定义的 agent_type SHALL 为 "worker"

#### Scenario: ExploreAgent 工具集
- **WHEN** ExploreAgent 被创建
- **THEN** 其工具集 SHALL 仅包含只读工具：file_read, grep, glob_search, bash

#### Scenario: ExploreAgent 快速导向
- **WHEN** ExploreAgent System Prompt 被构建
- **THEN** SHALL 强调 "快速 > 准确" 的工作哲学
- **AND** SHALL 引导 Agent 尽快找到相关文件并报告发现

#### Scenario: ExploreAgent 不注入历史
- **WHEN** ExploreAgent 被创建
- **THEN** inject_history SHALL 为 False（搜索不需要历史上下文）

---

### Requirement: PlanAgent 输出解析

系统 SHALL 提供 `parse_plan_output(response)` 函数，将 PlanAgent 的文本输出解析为 TaskPlan 数据结构。

#### Scenario: 正常解析
- **WHEN** PlanAgent 输出包含结构化 Step-by-Step Tasks 部分
- **THEN** parse_plan_output SHALL 提取 goal、strategy 和 tasks 列表，返回 TaskPlan 实例

#### Scenario: 解析容错
- **WHEN** PlanAgent 输出格式不完全符合预期模板
- **THEN** parse_plan_output SHALL 尽力提取信息（正则/启发式解析）
- **AND** 解析失败时 SHALL 返回 None 并记录 warning 日志

#### Scenario: 空输出处理
- **WHEN** PlanAgent 返回空内容
- **THEN** parse_plan_output SHALL 返回 None
