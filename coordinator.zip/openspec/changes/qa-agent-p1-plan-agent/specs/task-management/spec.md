# Delta Spec: task-management（任务计划管理）

> 变更类型: ADDED — 新增任务计划数据模型、工具和 prompt 注入

---

## ADDED Requirements

### Requirement: TaskPlan 数据模型

系统 SHALL 提供 `core/task_plan.py` 模块，定义结构化的任务计划数据模型。TaskPlan 由一个 goal（总目标）、strategy（策略概述）和有序的 TaskItem 列表组成。

#### Scenario: TaskItem 状态流转
- **WHEN** 创建一个 TaskItem
- **THEN** 初始状态 SHALL 为 `"pending"`
- **AND** 合法的状态流转 SHALL 为：pending → active → done/failed/skipped

#### Scenario: TaskPlan 创建
- **WHEN** Agent 通过 task_update 创建计划
- **THEN** TaskPlan SHALL 包含 goal（str）、strategy（str）、tasks（List[TaskItem]）、created_at（float）、current_task_id（int，初始为 0）

#### Scenario: TaskPlan 自动推进
- **WHEN** 当前 active task 被标记为 done
- **THEN** TaskPlan SHALL 自动将下一个 pending task 的状态设为 active
- **AND** 更新 current_task_id 为新 active task 的 id

#### Scenario: TaskPlan 完成判定
- **WHEN** 所有 tasks 状态均为 done/failed/skipped
- **THEN** TaskPlan.is_complete SHALL 返回 True

---

### Requirement: TaskPlan prompt 上下文生成

系统 SHALL 提供 `to_prompt_context()` 方法，将当前 TaskPlan 状态转换为可注入 Agent System Prompt 的文本。

#### Scenario: 有计划时生成 Task Context
- **WHEN** session_state 中存在 TaskPlan
- **THEN** to_prompt_context() SHALL 返回包含以下内容的字符串：
  - Goal 和 Strategy
  - Progress 概览（如 "3/7 tasks complete"）
  - 任务列表（用 [x]/[>]/[ ] 标记状态）
  - 当前 active task 用箭头标注 "← YOU ARE HERE"

#### Scenario: 无计划时返回空
- **WHEN** session_state 中无 TaskPlan
- **THEN** to_prompt_context() SHALL 返回空字符串

---

### Requirement: task_list 工具

系统 SHALL 提供 `task_list()` 只读工具（L1），返回当前 session 的 TaskPlan 状态摘要。

#### Scenario: 有计划时返回状态
- **WHEN** Agent 调用 task_list()
- **AND** session 中存在 TaskPlan
- **THEN** 返回 SHALL 包含 goal、strategy、所有 task 的 id/description/status、当前 active task 标识

#### Scenario: 无计划时返回引导
- **WHEN** Agent 调用 task_list()
- **AND** session 中无 TaskPlan
- **THEN** 返回 SHALL 为引导性文本：`"No task plan yet. Create one by calling task_update(task_id=0, status='create', summary='{\"goal\": \"...\", \"strategy\": \"...\", \"tasks\": [\"step 1\", \"step 2\", ...]}')"` 

---

### Requirement: task_update 工具

系统 SHALL 提供 `task_update(task_id, status, summary)` 工具（L1），用于创建计划和更新任务状态。

#### Scenario: 创建新计划
- **WHEN** Agent 调用 `task_update(task_id=0, status="create", summary='{"goal": "...", "strategy": "...", "tasks": ["step1", "step2"]}')`
- **THEN** 系统 SHALL 解析 summary JSON，创建 TaskPlan 并存入 session_state
- **AND** 第一个 task 的状态 SHALL 自动设为 active

#### Scenario: 标记任务完成
- **WHEN** Agent 调用 `task_update(task_id=3, status="done", summary="Found 5 config issues")`
- **THEN** 系统 SHALL 将 task 3 的状态更新为 done，记录 summary 和 completed_at
- **AND** 自动将 task 4（下一个 pending）设为 active

#### Scenario: 标记任务失败
- **WHEN** Agent 调用 `task_update(task_id=3, status="failed", summary="Hunter connection timeout")`
- **THEN** 系统 SHALL 将 task 3 状态更新为 failed，记录 summary
- **AND** 自动将 task 4 设为 active（失败不阻塞后续任务）

#### Scenario: 跳过任务
- **WHEN** Agent 调用 `task_update(task_id=3, status="skipped", summary="Not applicable")`
- **THEN** 系统 SHALL 将 task 3 状态更新为 skipped
- **AND** 自动将 task 4 设为 active

#### Scenario: 所有任务完成
- **WHEN** Agent 调用 task_update 导致所有 tasks 均为 done/failed/skipped
- **THEN** 返回信息 SHALL 包含 `"All tasks complete!"` 和各任务结果摘要

#### Scenario: 无效 task_id
- **WHEN** Agent 调用 task_update 使用不存在的 task_id
- **THEN** 系统 SHALL 返回引导性错误：`"Task ID N not found. Use task_list() to see available tasks."`

#### Scenario: 创建计划 JSON 解析失败
- **WHEN** Agent 调用 task_update(task_id=0, status="create") 但 summary 不是合法 JSON
- **THEN** 系统 SHALL 返回引导性错误，包含正确的 JSON 格式示例

---

### Requirement: session_state 持久化

TaskPlan SHALL 存储在 `QASessionState.task_plan` 字段中，随 session 持久化。

#### Scenario: TaskPlan 跨轮次保持
- **GIVEN** Agent 在 Turn 1 创建了 TaskPlan
- **WHEN** Agent 进入 Turn 5
- **THEN** session_state.task_plan SHALL 包含最新的 TaskPlan 状态（含所有已完成 task 的 summary）

#### Scenario: TaskPlan 字段可选
- **GIVEN** 现有 session 不包含 task_plan 字段
- **WHEN** 系统反序列化 session_state
- **THEN** task_plan SHALL 默认为 None，不影响正常工作
