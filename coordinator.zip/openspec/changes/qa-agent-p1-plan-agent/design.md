## Context

QA Agent System 基于 Agno 2.5.14 框架，当前有两种运行模式：Normal（单 Agent 直接执行）和 Coordinator（Team Leader + Workers 协作）。P0 优化已完成工具层面可靠性增强（search/replace file_edit、命令分类器、分级超时、auto-background）。

当前痛点：Agent 每轮 LLM 推理都是"自由发挥"，没有全局计划约束。在中等复杂度以上的任务中（5+ 步骤），Agent 容易在中途走偏、遗漏步骤或重复执行。

参考 Claude Code 的 Plan Agent 设计（docs/12-内置Agent深度解析.md），采用"分层强制"策略：Normal 模式用 prompt 约束内置规划；Coordinator 模式用独立 Plan Agent 做前置规划。

## Goals / Non-Goals

**Goals:**
- Agent 执行任何任务前先生成结构化 Task List
- Task 状态在整个 session 中可追踪（pending → active → done/failed/skipped）
- 每轮 Agent loop 都知道"当前在做哪个 task"
- Coordinator 模式强制前置 Plan 步骤
- 提供 PlanAgent（深度规划）和 ExploreAgent（快速搜索）两个只读 builtin agent

**Non-Goals:**
- 不做 Tool Scheduler 集成（Agno 不支持 tool executor 定制，已搁置）
- 不做 Task 动态重新规划（MVP 版本只做线性 Task List，不支持运行时重排/增删）
- 不修改 Agno 框架内部代码
- 不评估任务复杂度分流（所有请求统一走 Plan-first）

## Decisions

### D1: TaskPlan 数据模型

```python
@dataclass
class TaskItem:
    id: int
    description: str
    status: Literal["pending", "active", "done", "failed", "skipped"] = "pending"
    result_summary: str = ""
    tools_used: List[str] = field(default_factory=list)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None

@dataclass
class TaskPlan:
    goal: str
    strategy: str
    tasks: List[TaskItem]
    created_at: float
    current_task_id: int = 0  # 0=未开始
```

**存储位置**: `session_state.task_plan: Optional[TaskPlan]`（随 session 持久化）

**替代方案**: 用纯文本 markdown 记录 Task List → 拒绝，因为 LLM 生成 markdown 格式不稳定，状态解析容易出错。

### D2: Task 工具设计

提供两个专用工具：

| 工具 | 签名 | 权限 | 用途 |
|------|------|------|------|
| `task_list` | `task_list()` → str | L1 只读 | 查看当前 TaskPlan 和所有 task 状态 |
| `task_update` | `task_update(task_id, status, summary)` → str | L1 写入 | 标记 task 完成/失败/跳过，并推进到下一个 |

`task_update` 额外行为：
- 当 task 被标记 `done` 时，自动将下一个 `pending` task 设为 `active`
- 当所有 tasks 都是 `done`/`failed`/`skipped` 时，返回 "All tasks complete" 提示
- 创建计划时使用 `task_update(task_id=0, status="create", summary=JSON)` 特殊调用

**替代方案**: Agent 在 response 中输出 `[TASK_COMPLETE: N]` 标记由 hook 解析 → 拒绝，LLM 可能忘记输出标记，工具调用更可靠。

### D3: 分层强制策略

**Normal 模式**：通过 System Prompt 约束实现内置规划。在 `core/prompts.py` 中新增 `get_task_management_section()` 函数，注入以下约束：

```
## Task Management

Your first action for any task MUST be:
1. Call task_list() to check if a plan already exists
2. If no plan: analyze the request, then call task_update(task_id=0, status="create", summary=<JSON plan>)
3. If plan exists: continue from the current active task

After completing each task step:
- Call task_update(task_id=N, status="done", summary="<brief result>")
- The system will automatically advance to the next task

Current task context will be shown below.
```

每轮 Agent loop 开始时，从 `session_state.task_plan` 生成 Task Context 注入到 prompt：

```
## Current Task Progress
Goal: <goal>
Strategy: <strategy>
Progress: 3/7 tasks complete

[x] 1. Read combat config tables
[x] 2. Identify damage formula parameters
[>] 3. Write verification script      ← YOU ARE HERE
[ ] 4. Execute via Hunter
[ ] 5. Analyze results
```

**Coordinator 模式**：在 `coordinator/team_builder.py` 中，创建 Team 前先 spawn PlanAgent 做前置规划：

```python
# Phase 0: Plan
plan_agent = await create_agent_from_definition(PlanAgentDefinition, ...)
plan_response = await plan_agent.arun(task)
task_plan = parse_plan_output(plan_response)

# Phase 1-4: Normal Coordinator workflow with task_plan context
team = Team(
    instructions=COORDINATOR_SYSTEM_PROMPT + task_plan.to_prompt_context(),
    ...
)
```

### D4: PlanAgent 定义

```python
PlanAgentDefinition = AgentDefinition(
    name="PlanAgent",
    description="Software architect for designing implementation plans",
    instructions=PLAN_AGENT_SYSTEM_PROMPT,  # 300+ 行专用 prompt
    tool_names=["file_read", "grep", "glob_search", "bash"],  # READ-ONLY 子集
    permission_mode="default",
    agent_type="worker",
    model_id="inherit",  # 规划需要深度思考
    max_turns=15,
    inject_history=True,
    when_to_use="需要为复杂任务做架构分析和实施规划时使用",
    tags=["planning", "architecture", "read-only"],
)
```

PlanAgent System Prompt 核心要素：
- 身份："Software architect and planning specialist"
- 严格只读："=== CRITICAL: READ-ONLY MODE ==="
- 输出格式：Implementation Strategy → Key Files → Step-by-Step Tasks → Trade-offs → Risks
- 强调 trade-offs 和风险意识

### D5: ExploreAgent 定义

```python
ExploreAgentDefinition = AgentDefinition(
    name="ExploreAgent",
    description="Fast codebase search and exploration specialist",
    instructions=EXPLORE_AGENT_SYSTEM_PROMPT,
    tool_names=["file_read", "grep", "glob_search", "bash"],  # READ-ONLY 子集
    permission_mode="default",
    agent_type="worker",
    model_id=None,  # 使用默认模型（或未来支持 cheap 模型配置）
    max_turns=10,
    inject_history=False,  # 搜索不需要历史上下文
    when_to_use="快速搜索代码库、查找文件、定位模式时使用",
    tags=["search", "exploration", "read-only"],
)
```

### D6: 文件结构

```
qa-agent/
├── core/
│   ├── task_plan.py           # NEW: TaskPlan + TaskItem 数据模型
│   ├── session_state.py       # MODIFIED: 添加 task_plan 字段
│   ├── prompts.py             # MODIFIED: 添加 task management prompt section
│   └── engine.py              # MODIFIED: 注入 Task Context
├── tools/
│   └── task_tools.py          # NEW: task_list + task_update 工具
├── agents/
│   ├── builtin/
│   │   ├── plan_agent.py      # NEW: PlanAgent 定义
│   │   └── explore_agent.py   # NEW: ExploreAgent 定义
│   └── registry.py            # MODIFIED: 注册新 agents
├── coordinator/
│   └── team_builder.py        # MODIFIED: Phase 0 Plan 步骤
└── tests/
    ├── test_task_plan.py      # NEW
    ├── test_task_tools.py     # NEW
    └── test_plan_agent.py     # NEW
```

## Risks / Trade-offs

| Risk | Impact | Mitigation |
|------|--------|------------|
| LLM 不按 prompt 约束调用 task_update 创建计划 | 执行不受计划约束 | task_list 返回值包含"No plan yet"强提示；post_hook 检测 3 轮无计划时注入强制提醒 |
| task_update 创建的计划质量差（步骤过粗或过细） | 计划形同虚设 | PlanAgent System Prompt 强调 3-10 步骤，每步需可验证；Normal 模式 prompt 示例引导 |
| PlanAgent 耗时过长影响首次响应速度 | 用户体验差 | PlanAgent max_turns=15 限制；仅 Coordinator 模式强制使用，Normal 模式用 prompt 内置 |
| session_state 序列化 TaskPlan 增加 payload 大小 | 内存/存储开销 | TaskItem 结构紧凑，典型 10 个 task 约 2KB，远小于消息历史 |
| Coordinator 的 PlanAgent 输出格式不稳定 | 无法解析为 TaskPlan | parse_plan_output 做容错解析，解析失败时降级为无计划模式（log warning） |
