## 1. api_spec.md 更新

- [x] 1.1 替换 Diff API 的 curl 命令模板为 python -c 格式
- [x] 1.2 替换 /get_issue_revisions 的 curl 命令模板为 python -c 格式
- [x] 1.3 替换 /get_revision_xlsx_files 的 curl 命令模板为 python -c 格式

## 2. workflow.md 更新

- [x] 2.1 替换 Step 1.1 中 /get_issue_revisions 的 curl 调用为 python -c 格式
- [x] 2.2 替换 Step 1.2 策略 B 中 /get_revision_xlsx_files 的 curl 调用为 python -c 格式

## 3. semantic_lookup.md 更新

- [x] 3.1 替换普通掉落查询 (common_drop) 的 curl 模板为 python -c 格式
- [x] 3.2 替换稀有掉落查询 (rare_drop) 的 curl 模板为 python -c 格式
- [x] 3.3 替换物品名称查询 (item) 的 curl 模板为 python -c 格式
- [x] 3.4 移除 bash 批量查询循环示例，添加说明由 LLM 多次执行单条命令

## 4. chunked_processing.md 更新

- [x] 4.1 替换 Step 2.2 中 API 调用的 curl 命令为 python -c 格式（保存到文件）
- [x] 4.2 移除 Windows CMD / Linux macOS 双版本 curl 模板，统一为 python -c

## 5. SKILL.md 更新

- [x] 5.1 更新 compatibility 字段：移除 curl 依赖，改为 Python 3 + requests 库
- [x] 5.2 在 Phase 2 说明中更新命令模板引用
