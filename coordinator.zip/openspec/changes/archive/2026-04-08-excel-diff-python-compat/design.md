## Context

Excel Diff Analyzer 技能包依赖系统命令执行 HTTP 请求。当前文档中的 curl 命令模板采用 Linux bash 语法：
- 使用 `\` 作为多行续行符（Windows CMD 使用 `^`）
- 使用单引号包裹 JSON 字符串（Windows CMD 不支持单引号）
- 批量查询使用 bash `for...do...done` 循环语法

这导致 Windows 用户无法直接复制使用这些命令。

**已测试验证**：以下 `python -c` 命令模板在 Windows CMD 环境下均可正常工作：

```
✓ get_issue_revisions     - 获取 issue 关联的修订号
✓ get_revision_xlsx_files - 获取修订号对应的配置表文件
✓ get_gift_by_item        - 物品语义查询
✓ get_common_drop         - 普通掉落语义查询
✓ get_rare_drop           - 稀有掉落语义查询
✓ 文件输出（json.dumps + open().write）
```

## Goals / Non-Goals

**Goals:**
- 所有 HTTP API 调用命令在 Windows/Linux/macOS 上均可直接运行
- 保持命令的简洁性和可读性
- 利用已有的 Python 依赖（技能本身就依赖 Python 3）

**Non-Goals:**
- 不创建额外的 Python 脚本文件（如 api_client.py）
- 不支持 PowerShell 特定语法（CMD 兼容即可）
- 不改变 API 的功能或响应格式

## Decisions

### Decision 1: 使用 `python -c` 内联脚本替代 curl

**选择**: `python -c "import requests; ..."` 单行内联脚本

**理由**:
- Python 3 已是技能的必需依赖，无需额外安装
- `requests` 库语法简洁，比 `urllib` 更易读
- 单行 `-c` 方式无需维护额外脚本文件
- 天然跨平台，无需为不同 OS 提供不同命令

**替代方案（已否决）**:
- 创建 `api_client.py` 独立脚本 → 增加维护负担
- 为每个 curl 命令提供 Windows/Linux 双版本 → 文档冗余
- 使用标准库 `urllib.request` → 代码复杂度高

### Decision 2: 批量查询由 LLM 多次执行单条命令

**选择**: 不提供循环语法，由 LLM 智能组织多次调用

**理由**:
- 单条命令简单可靠，易于调试
- 避免 bash/CMD 循环语法差异
- LLM 可根据实际情况灵活组织查询顺序

### Decision 3: 文件输出使用 Python open() + json.dumps

**选择**: 
```python
open('output.json','w',encoding='utf-8').write(json.dumps(r.json(),ensure_ascii=False,indent=2))
```

**理由**:
- 跨平台统一
- 自动处理 UTF-8 编码和中文字符
- 格式化输出便于阅读

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| `requests` 库未安装 | 在 SKILL.md 明确说明依赖，首次使用时 LLM 可检测并提示安装 |
| 命令长度增加（相比 curl） | 可接受，换取跨平台兼容性 |
| Python 版本差异 | 要求 Python 3.6+，与技能其他脚本保持一致 |

## 命令模板汇总

### Issue/Revision 相关 API

**获取 Issue 修订号**:
```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_issue_revisions',json={'issue_id':'{ISSUE_ID}'}).text)"
```

**获取修订号对应的文件列表**:
```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_revision_xlsx_files',json={'revisions':['{REV1}','{REV2}'],'branch':'{BRANCH}'}).text)"
```

### Excel Diff API

**获取 Excel Diff（保存到文件）**:
```bash
python -c "import requests,json;r=requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_excel_batch_diff',json={'tasks':[{'file_url':'{FILE_PATH}','revisions':[{REV1},{REV2}]}]});open('{OUTPUT_FILE}','w',encoding='utf-8').write(json.dumps(r.json(),ensure_ascii=False,indent=2))"
```

### 语义查询 API

**物品名称查询**:
```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_gift_by_item',data={'item_id':'{ID}','env':'trunk'}).text)"
```

**普通掉落查询**:
```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_common_drop',data={'common_drop_id':'{ID}','env':'trunk'}).text)"
```

**稀有掉落查询**:
```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_rare_drop',data={'rare_drop_id':'{ID}','env':'trunk'}).text)"
```
