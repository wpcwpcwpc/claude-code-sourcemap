# Specs - excel-diff-python-compat

此变更是纯文档改进，不涉及功能性规格变更。

## 变更性质说明

- **类型**: 文档兼容性改进
- **范围**: 技能包内的 HTTP API 调用命令模板
- **影响**: 仅影响 LLM 执行命令的方式，不改变 API 的功能或行为

## 不需要 Spec 的原因

1. **无新功能引入**: 不添加任何新的业务能力
2. **无行为变更**: API 的功能、请求/响应格式完全不变
3. **纯实现细节**: 从 curl 改为 python -c 是实现层面的选择，不影响用户可见行为

## 受影响的文档

以下文档中的命令模板将被替换：

| 文档 | 影响的命令 |
|------|-----------|
| `api_spec.md` | Excel Diff API、Issue/Revision API 的 curl 模板 |
| `workflow.md` | Step 1.1/1.2 中的 API 调用命令 |
| `semantic_lookup.md` | 物品/掉落语义查询的 curl 模板 |
| `chunked_processing.md` | Step 2.2 中的 curl 调用命令 |
| `SKILL.md` | compatibility 字段说明 |
