## Why

Excel Diff Analyzer 技能包中的 API 调用文档（`api_spec.md`、`workflow.md`、`semantic_lookup.md`、`chunked_processing.md`）目前使用 curl 命令作为 HTTP 请求示例，这些命令采用 Linux bash 语法（单引号包裹 JSON、反斜杠续行符、bash for 循环），在 Windows CMD 环境下无法直接运行。需要统一改用 `python -c` 内联脚本方式，实现跨平台兼容。

## What Changes

- **替换所有 curl 命令模板**：将 `api_spec.md`、`workflow.md`、`semantic_lookup.md`、`chunked_processing.md` 中的 curl 命令替换为 `python -c "import requests; ..."` 内联脚本
- **移除 curl 依赖**：技能不再需要系统安装 curl 命令
- **新增 requests 依赖**：明确 Python requests 库为必需依赖
- **更新 SKILL.md 的 compatibility 字段**：移除 curl 要求，改为 Python 3 + requests

## Capabilities

### New Capabilities

无（此变更不引入新功能，仅改进现有文档的跨平台兼容性）

### Modified Capabilities

无（这是纯文档改进，不涉及 spec 层面的行为变更）

## Impact

- **受影响文件**：
  - `.claude/skills/excel-diff-analyzer/references/api_spec.md`
  - `.claude/skills/excel-diff-analyzer/references/workflow.md`
  - `.claude/skills/excel-diff-analyzer/references/semantic_lookup.md`
  - `.claude/skills/excel-diff-analyzer/references/chunked_processing.md`
  - `.claude/skills/excel-diff-analyzer/SKILL.md`
- **依赖变更**：新增 `requests` 库依赖（pip install requests）
- **移除依赖**：curl 命令不再是必需
- **用户影响**：Windows 用户可直接使用技能，无需安装或配置 curl
