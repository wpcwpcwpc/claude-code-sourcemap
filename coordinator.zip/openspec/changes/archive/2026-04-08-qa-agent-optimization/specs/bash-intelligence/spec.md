# Delta Spec: bash-intelligence（Bash 命令分类 + 超时智能化）

> 对应 main spec: `tool-system`
> 变更类型: ADDED — 新增命令分类器、管道分析器、后台任务管理器、sed 拦截器

---

## ADDED Requirement: 命令分类器（bash_classifier）

系统 SHALL 提供 `tools/bash_classifier.py` 模块，将任意 shell 命令分类为 6 个语义类别，用于并发安全判定、权限级别推断、UI 展示和超时策略。

### Scenario: SEARCH 命令分类
- **WHEN** 命令为 `grep -r "def test_" .` 或 `find . -name "*.py"` 或 `rg pattern`
- **THEN** classify_command SHALL 返回 `CommandCategory.SEARCH`

### Scenario: READ 命令分类
- **WHEN** 命令为 `cat config.py` 或 `head -20 log.txt` 或 `wc -l *.py` 或 `jq '.name' config.json`
- **THEN** classify_command SHALL 返回 `CommandCategory.READ`

### Scenario: LIST 命令分类
- **WHEN** 命令为 `ls -la` 或 `tree src/` 或 `du -sh *`
- **THEN** classify_command SHALL 返回 `CommandCategory.LIST`

### Scenario: NEUTRAL 命令分类
- **WHEN** 命令为 `echo "hello"` 或 `printf "%s" "$VAR"` 或 `true`
- **THEN** classify_command SHALL 返回 `CommandCategory.NEUTRAL`

### Scenario: SILENT 命令分类
- **WHEN** 命令为 `mkdir -p /tmp/test` 或 `cp a.txt b.txt` 或 `chmod 755 script.sh`
- **THEN** classify_command SHALL 返回 `CommandCategory.SILENT`

### Scenario: WRITE 命令分类（默认）
- **WHEN** 命令不属于以上任何类别（如 `python run.py` 或 `npm install` 或 `pip install requests`）
- **THEN** classify_command SHALL 返回 `CommandCategory.WRITE`（安全默认）

### 分类常量定义

系统 SHALL 维护以下命令集合常量：

| 集合名 | 包含命令 | 属性 |
|--------|---------|------|
| `SEARCH_COMMANDS` | find, grep, rg, ag, ack, locate, which, whereis | is_read_only=True |
| `READ_COMMANDS` | cat, head, tail, less, more, wc, stat, file, strings, jq, awk, cut, sort, uniq, tr | is_read_only=True |
| `LIST_COMMANDS` | ls, tree, du, dir | is_read_only=True |
| `NEUTRAL_COMMANDS` | echo, printf, true, false, : | 不改变管道语义 |
| `SILENT_COMMANDS` | mv, cp, rm, mkdir, rmdir, chmod, chown, chgrp, touch, ln, cd, export, unset, wait | 成功时无输出 |

---

## ADDED Requirement: 管道分析器（Pipeline Analyzer）

系统 SHALL 提供管道感知的命令分析能力，正确判断包含 `|`、`&&`、`||`、`;` 的复合命令的整体只读性。

### Scenario: 纯只读管道
- **WHEN** 命令为 `grep "pattern" file.txt | sort | head -5`
- **THEN** is_read_only_command SHALL 返回 `True`（所有段均为只读命令）

### Scenario: 混合管道判断为非只读
- **WHEN** 命令为 `grep "pattern" file.txt | xargs rm`
- **THEN** is_read_only_command SHALL 返回 `False`（`xargs rm` 不是只读命令）

### Scenario: 语义中性命令跳过
- **WHEN** 命令为 `echo "start" && grep -r "test" . && echo "done"`
- **THEN** is_read_only_command SHALL 返回 `True`（echo 是语义中性命令，不影响判定；grep 是只读）

### Scenario: 重定向感知
- **WHEN** 命令为 `grep "pattern" file.txt > output.txt`
- **THEN** is_read_only_command SHALL 返回 `False`（重定向到文件是写操作）

### Scenario: 管道拆分逻辑
- **WHEN** 分析器处理命令 `cmd_a | cmd_b && cmd_c || cmd_d ; cmd_e`
- **THEN** 系统 SHALL 正确拆分为 `[cmd_a, cmd_b, cmd_c, cmd_d, cmd_e]`，并忽略操作符符号本身

---

## ADDED Requirement: sed -i 拦截器

系统 SHALL 检测 LLM 生成的 `sed -i` 命令，自动转换为 `file_edit` 操作，走正规的编辑验证流程。

### Scenario: sed -i 替换拦截
- **WHEN** Agent 调用 `bash(command="sed -i 's/old/new/g' config.py")`
- **THEN** 系统 SHALL 拦截该命令，不执行 sed
- **AND** 返回引导性消息: `"Instead of sed -i, use the file_edit tool: file_edit(file_path='config.py', old_string='old', new_string='new', replace_all=True). This ensures proper validation and undo support."`

### Scenario: 非 -i sed 允许通过
- **WHEN** Agent 调用 `bash(command="sed 's/old/new/g' input.txt")` （无 -i 标志，只输出到 stdout）
- **THEN** 系统 SHALL 正常执行（这是只读的 sed 用法）

---

## ADDED Requirement: 后台任务管理器（BackgroundTaskManager）

系统 SHALL 提供 `tools/background_tasks.py` 模块，管理后台执行的长时间命令，支持任务启动、状态查询、结果获取和超时清理。

### Scenario: 启动后台任务
- **WHEN** Agent 调用 `bash(command="npm install", run_in_background=True)`
- **THEN** BackgroundTaskManager SHALL 在独立线程/进程中执行命令，立即返回 `task_id`

### Scenario: 查询任务状态
- **WHEN** Agent 调用 `bash(command="bg_status <task_id>")`
- **THEN** 系统 SHALL 返回任务状态: `running` / `completed` / `failed` / `timeout`，以及已运行时间和当前输出

### Scenario: 任务超时
- **GIVEN** 后台任务运行超过 `TIMEOUT_BACKGROUND`（120秒）
- **THEN** BackgroundTaskManager SHALL 终止任务进程，标记状态为 `timeout`，保留已获取的输出

### Scenario: 自动后台化
- **GIVEN** 一个同步执行的命令在 `BLOCKING_BUDGET_MS`（15秒）内未完成
- **AND** 该命令不在禁止自动后台化列表中（如 `sleep`）
- **THEN** 系统 SHALL 自动切换为后台执行，返回 `task_id` 并提示 Agent: `"Command auto-backgrounded after 15s. Task ID: <id>. Use bg_status <id> to check progress."`

### Scenario: sleep 命令禁止自动后台化
- **GIVEN** Agent 调用 `bash(command="sleep 30 && run_test.sh")`
- **AND** 命令运行超过 15 秒
- **THEN** 系统 SHALL **不** 自动后台化（sleep 是刻意等待），继续等待至显式超时

---

## MODIFIED Requirement: bash 工具超时策略增强

当前 bash 工具使用固定超时，改为基于命令分类的分级超时策略。

### Scenario: SILENT 命令短超时
- **WHEN** 命令分类为 SILENT（如 `mkdir -p dir`）
- **THEN** 默认超时 SHALL 为 2 秒

### Scenario: READ/SEARCH 命令中等超时
- **WHEN** 命令分类为 SEARCH 或 READ（如 `grep -r "pattern" .`）
- **THEN** 默认超时 SHALL 为 15 秒

### Scenario: WRITE 命令较长超时
- **WHEN** 命令分类为 WRITE（如 `python -m pytest tests/`）
- **THEN** 默认超时 SHALL 为 30 秒
- **AND** 超过 15 秒时应触发自动后台化检查

### Scenario: 用户显式超时优先
- **WHEN** Agent 显式传入 `timeout=120`
- **THEN** 系统 SHALL 使用用户指定的超时值，忽略分类默认值

---

## MODIFIED Requirement: bash 工具错误信息优化

bash 工具的错误输出 SHALL 提供引导性信息，帮助 LLM 理解问题并自我纠正。

### Scenario: 超时错误引导
- **WHEN** 命令超时
- **THEN** 返回信息 SHALL 包含:
  - 实际超时时长
  - 命令分类
  - 如果是可后台化命令: 建议 `"Consider re-running with run_in_background=True"`
  - 如果是只读命令超时: 建议 `"The search may be too broad. Try narrowing the pattern or path."`

### Scenario: 命令不存在引导
- **WHEN** 命令执行返回 `command not found`
- **THEN** 返回信息 SHALL 包含: `"Command not found. Check if the tool is installed. On this system, available shells are: <list>."`

### Scenario: 非零退出码信息
- **WHEN** 命令以非零退出码完成
- **AND** 退出码有已知语义（如 grep 返回 1 表示无匹配）
- **THEN** 返回信息 SHALL 包含解释: `"Exit code 1 for grep means no matches found (not an error)."`

### 已知退出码语义表

| 命令 | 退出码 | 含义 | 是否应报为错误 |
|------|--------|------|---------------|
| grep | 1 | 无匹配 | 否 |
| diff | 1 | 文件有差异 | 否 |
| test / [ | 1 | 条件为假 | 否 |
| timeout | 124 | 命令超时 | 是 |

---

## ADDED Requirement: bash description 字段强制

bash 工具 SHALL 包含 `description` 参数，LLM 在调用 bash 时应提供对命令意图的简短描述。

### Scenario: description 用于审核展示
- **GIVEN** permission_mode 为 `ask`（L2 需要人工确认）
- **WHEN** Agent 调用 `bash(command="pip install requests", description="Install HTTP library for API testing")`
- **THEN** HIL 审核界面 SHALL 展示 description 而非原始命令作为标题
- **AND** 原始命令作为详情展示

### Scenario: description 为空时的容错
- **WHEN** LLM 未提供 description（空字符串）
- **THEN** 系统 SHALL 不阻塞执行，使用命令前 80 字符作为 fallback description
