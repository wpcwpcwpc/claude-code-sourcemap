# Delta Spec: tool-validation（工具参数验证增强）

> 对应 main spec: `tool-system`
> 变更类型: MODIFIED — 对现有工具增加验证层；ADDED — 新增验证框架

---

## MODIFIED Requirement: file_edit 工具改为搜索-替换模式

当前 `file_edit` 采用全文覆写模式（接收 `path` + `content`），这导致 LLM 经常生成错误内容（遗漏原文、格式丢失）。改为 Claude Code 的 search/replace 模式，仅传输变更部分。

### Scenario: 正常搜索-替换编辑
- **GIVEN** 文件 `config.py` 已被 `file_read` 读取过
- **WHEN** Agent 调用 `file_edit(file_path="config.py", old_string="timeout = 30", new_string="timeout = 60")`
- **THEN** 系统 SHALL 在文件中精确查找 `old_string`，替换为 `new_string`，保留文件其余内容不变

### Scenario: 创建新文件
- **GIVEN** 文件 `new_module.py` 不存在
- **WHEN** Agent 调用 `file_edit(file_path="new_module.py", old_string="", new_string="# new file content\n...")`
- **THEN** 系统 SHALL 创建文件并写入 `new_string` 内容（`old_string` 为空字符串表示创建）

### Scenario: 多重匹配拒绝
- **GIVEN** 文件中 `old_string` 出现了 3 次
- **WHEN** Agent 调用 `file_edit` 且未设置 `replace_all=True`
- **THEN** 系统 SHALL 返回引导性错误信息：`"Found 3 matches for old_string. Include more surrounding context to make it unique, or set replace_all=True."`

---

## ADDED Requirement: validateInput 验证层

每个工具 SHALL 在执行前运行 `validate_input()` 方法，执行业务约束检查。验证失败时返回**引导性错误信息**（而非 Python traceback），引导 LLM 自我纠正。

### Scenario: file_edit 先读后写强制
- **GIVEN** Agent 未对文件 `app.py` 调用过 `file_read`
- **WHEN** Agent 调用 `file_edit(file_path="app.py", old_string="...", new_string="...")`
- **THEN** validate_input SHALL 返回: `"You must read the file before editing it. Use file_read(path='app.py') first."`

### Scenario: file_edit 文件外部修改检测
- **GIVEN** Agent 在 T1 时刻读取了 `app.py`
- **AND** 外部进程在 T2 时刻修改了 `app.py`
- **WHEN** Agent 在 T3 时刻调用 `file_edit(file_path="app.py", ...)`
- **THEN** validate_input SHALL 检测到文件 mtime > 读取时间戳，返回: `"File has been modified since you last read it. Read it again with file_read before editing."`

### Scenario: file_edit old_string 不存在
- **GIVEN** 文件内容不包含 `old_string`
- **WHEN** Agent 调用 `file_edit(file_path="app.py", old_string="nonexistent code", new_string="...")`
- **THEN** validate_input SHALL 返回: `"The old_string was not found in the file. Make sure it matches exactly, including whitespace and indentation. Re-read the file to verify."`

### Scenario: file_edit 空操作检测
- **GIVEN** Agent 调用 `file_edit` 且 `old_string == new_string`
- **THEN** validate_input SHALL 返回: `"No changes to make: old_string and new_string are identical."`

### Scenario: bash 静默命令无输出
- **GIVEN** Agent 调用 `bash(command="mkdir -p /tmp/test")`
- **AND** 命令成功执行且无 stdout/stderr
- **THEN** 系统 SHALL 返回 `"(command completed successfully, no output)"` 而非空字符串

---

## ADDED Requirement: 读取状态跟踪器（ReadFileStateCache）

系统 SHALL 维护一个全局 `ReadFileStateCache`，记录每个文件的最近一次读取时间戳和内容摘要，供 `file_edit` 的 validate_input 使用。

### Scenario: 读取状态记录
- **WHEN** Agent 调用 `file_read(path="app.py")`
- **THEN** ReadFileStateCache SHALL 记录 `{"path": "app.py", "timestamp": <mtime>, "content_hash": <sha256>, "offset": 0, "limit": 500}`

### Scenario: 读取状态查询
- **WHEN** `file_edit` 的 validate_input 检查 `app.py`
- **THEN** 系统 SHALL 从 ReadFileStateCache 获取该文件的最近读取记录，与当前文件 mtime 比较

### Scenario: 部分读取标记
- **GIVEN** Agent 调用 `file_read(path="app.py", offset=100, limit=50)` 只读取了部分内容
- **WHEN** 随后调用 `file_edit` 修改该文件
- **THEN** validate_input SHALL 标记为 `is_partial_view=True`，并警告: `"You only read lines 101-150 of this file. Make sure old_string is within the range you have read."`

---

## ADDED Requirement: Semantic 参数解析

工具参数解析 SHALL 支持 LLM 常见的类型变体，自动规范化为正确类型，避免因类型不匹配导致的调用失败。

### Scenario: Boolean 语义解析
- **WHEN** LLM 传入 `run_in_background="true"` (字符串) 或 `"yes"` 或 `"1"`
- **THEN** 参数解析器 SHALL 将其规范化为 Python `True`

### Scenario: Number 语义解析
- **WHEN** LLM 传入 `timeout="30"` (字符串)
- **THEN** 参数解析器 SHALL 将其规范化为 Python `int(30)`

### Scenario: 未知参数拒绝
- **WHEN** LLM 传入工具未定义的额外参数（如 `file_read(path="a.py", verbose=True)`）
- **THEN** 参数解析器 SHALL 忽略未知参数并记录 warning 日志，不阻塞执行

---

## ADDED Requirement: System Prompt 工具使用指南

Agent 的 System Prompt SHALL 包含明确的工具使用指南，告诉 LLM 用哪个专用工具做哪件事，并列出常见错误的避免方式。

### Scenario: 工具优先级指导
- **WHEN** 构建 Agent System Prompt
- **THEN** SHALL 包含以下指导规则:
  - "使用 `file_read` 读取文件，不要用 `bash` 执行 `cat`/`head`/`tail`"
  - "使用 `file_edit` 编辑文件，不要用 `bash` 执行 `sed` 或 `awk`"
  - "使用 `grep` 搜索文件内容，不要用 `bash` 执行 `grep` 或 `rg`"
  - "使用 `glob_search` 查找文件，不要用 `bash` 执行 `find` 或 `ls`"
  - "仅在需要执行系统命令（安装依赖、运行测试、git 操作）时使用 `bash`"

### Scenario: 先读后写指导
- **WHEN** 构建 Agent System Prompt
- **THEN** SHALL 包含: "编辑文件前必须先读取 — 先理解，后修改（measure twice, cut once）"

### Scenario: 并行调用指导
- **WHEN** 构建 Agent System Prompt
- **THEN** SHALL 包含: "你可以在一次响应中调用多个工具。如果工具之间没有依赖关系，请并行调用以提高效率。"
