# Tasks: QA Agent System P0 优化

## Phase 1: 基础设施（Semantic 参数解析 + 读取状态跟踪）

- [x] 1.1 实现 `tools/semantic_params.py`：semantic_bool() 解析 "true"/"yes"/"1"/True → bool；semantic_int() 解析 "30"/30 → int；strip_unknown_params() 过滤未定义参数并 warning 日志
- [x] 1.2 实现 `tools/file_state_cache.py`：FileReadRecord dataclass（path, mtime, content_hash, offset, limit, is_partial）；ReadFileStateCache 单例类，提供 record_read()、get_record()、is_stale() 方法
- [x] 1.3 编写 `tests/test_semantic_params.py`：覆盖 bool/int 的各种变体输入 + 未知参数过滤
- [x] 1.4 编写 `tests/test_file_state_cache.py`：覆盖记录读取、过期检测、部分读取标记

## Phase 2: file_edit 重构为 search/replace 模式

- [x] 2.1 重写 `tools/file_tools.py` 中的 `file_edit`：新签名 file_edit(file_path, old_string, new_string, replace_all=False)；old_string 为空时创建新文件；非空时精确搜索替换
- [x] 2.2 在 `file_edit` 中集成 validateInput 验证链：(a) old_string==new_string 空操作检测 (b) 文件不存在且 old_string 非空 → 报错 (c) ReadFileStateCache 先读后写检查 (d) mtime 外部修改检测 (e) old_string 未找到 → 引导性错误 (f) 多重匹配 → 引导增加上下文或 replace_all
- [x] 2.3 修改 `file_read` 在返回结果前调用 `ReadFileStateCache.record_read()` 记录读取状态
- [x] 2.4 编写 `tests/test_file_edit_validation.py`：覆盖所有 validateInput 场景（先读后写、外部修改、未找到、多重匹配、空操作、新建文件）

## Phase 3: 命令分类器 + 管道分析器

- [x] 3.1 实现 `tools/bash_classifier.py`：CommandCategory 枚举（SEARCH/READ/LIST/NEUTRAL/SILENT/WRITE）；6 个命令集合常量（SEARCH_COMMANDS, READ_COMMANDS, LIST_COMMANDS, NEUTRAL_COMMANDS, SILENT_COMMANDS）
- [x] 3.2 实现 `split_pipeline(command)` 函数：正确拆分 | && || ; 管道操作符，返回命令段列表；处理引号内的特殊字符（不拆分引号内的 |）
- [x] 3.3 实现 `classify_command(command)` 函数：取管道最后一个非中性段的分类作为整体分类；无非中性段时返回 NEUTRAL
- [x] 3.4 实现 `is_read_only_command(command)` 函数：管道感知——所有段均为 SEARCH/READ/LIST/NEUTRAL → True；任何段为 WRITE/SILENT → False；检测重定向符号 > >> → False
- [x] 3.5 实现 `detect_sed_inplace(command)` 函数：检测 `sed -i` / `sed --in-place` 模式，返回 (file_path, pattern, replacement) 或 None
- [x] 3.6 编写 `tests/test_bash_classifier.py`：覆盖所有 6 类命令分类、管道分析（纯只读/混合/重定向）、sed -i 检测

## Phase 4: 后台任务管理器

- [x] 4.1 实现 `tools/background_tasks.py`：BackgroundTask dataclass（task_id, command, status, start_time, output, process）；BackgroundTaskManager 类——start_task() 在线程中执行 subprocess、get_status() 返回当前状态和输出、cleanup_expired() 清理超时任务
- [x] 4.2 实现 auto-background 机制：在 bash_tool 同步执行路径中，使用 asyncio.wait_for 包裹执行，15s 后检查是否可自动后台化（排除 sleep 开头的命令），超时则切换到 BackgroundTaskManager
- [x] 4.3 编写 `tests/test_background_tasks.py`：覆盖启动任务、状态查询、超时清理、auto-background 触发

## Phase 5: Bash 工具重构

- [x] 5.1 重写 `tools/bash_tool.py`：集成 bash_classifier（分类 + 只读判定）；集成 BackgroundTaskManager（显式后台 + auto-background）；集成 sed -i 拦截（detect_sed_inplace → 引导使用 file_edit）
- [x] 5.2 实现分级超时策略：SILENT→2s, SEARCH/READ/LIST→15s, WRITE→30s；用户显式 timeout 优先
- [x] 5.3 实现引导性错误信息：超时 → 含分类和后台化建议；command not found → 提示检查安装；已知退出码语义（grep:1=无匹配, diff:1=有差异）→ 不报为错误；静默命令无输出 → "(command completed successfully, no output)"
- [x] 5.4 编写 `tests/test_bash_tool.py`：覆盖分类超时、sed 拦截、后台化、错误信息引导、静默命令

## Phase 6: System Prompt 工具使用指南

- [x] 6.1 创建 `core/prompts.py`：实现 `get_tool_usage_section(enabled_tools)` 函数，生成 "# Using your tools" prompt section，包含工具优先级引导（file_read 代替 cat、file_edit 代替 sed、grep 代替 bash grep）、先读后写原则、并行调用指导
- [x] 6.2 将 `get_tool_usage_section` 集成到 Agent System Prompt 构建流程中（修改 core/engine.py 或 agents/base.py，在构建 Agent instructions 时追加工具使用指南）
- [x] 6.3 编写 `tests/test_prompts.py`：验证生成的 prompt 包含关键规则关键字
