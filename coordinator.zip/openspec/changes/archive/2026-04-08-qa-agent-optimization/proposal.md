# Proposal: QA Agent System P0 优化

## 概述

针对 qa-agent-system 在实际测试中暴露的两个核心问题进行优化：

1. **工具参数验证薄弱**：LLM 构造的工具参数频繁出错（类型不匹配、缺乏业务约束检查），错误以 Python traceback 形式返回，LLM 无法从中学习纠正
2. **Bash 工具执行效果差**：固定超时导致长命令失败、缺乏命令分类和管道分析、静默命令误判、sed -i 绕过编辑验证

## 优化范围

### P0-A: 工具参数验证增强（tool-validation）
- file_edit 从全文覆写改为 search/replace 模式
- 引入 validateInput 验证层（先读后写、外部修改检测、空操作检测等）
- ReadFileStateCache 读取状态跟踪
- Semantic 参数解析（字符串 "true" → bool True）
- System Prompt 工具使用指南注入

### P0-B: Bash 命令分类 + 超时智能化（bash-intelligence）
- 6 类命令分类器 + 管道分析器
- sed -i 拦截转 file_edit
- BackgroundTaskManager 后台任务管理
- 分级超时策略（2s/15s/30s）+ 自动后台化
- 引导性错误信息（错误信息即重试 prompt）

## 参考

基于 Claude Code 源码（docs/07-核心工具实现.md, docs/05-Prompt工程实践.md）中的工具防御链设计。
