# Design: QA Agent System P0 优化

## 架构决策

### D1: 工具防御链（4 层）

所有工具执行均经过 4 层防御链：

```
Schema 验证 → validateInput → Prompt 指导 → 错误反馈
```

- **Layer 1 (Schema)**: Pydantic model + semantic 解析器（tools/semantic_params.py）
- **Layer 2 (validateInput)**: 每个工具的 `_validate()` 函数（业务约束检查）
- **Layer 3 (Prompt)**: System Prompt 的 `# Using your tools` section（core/prompts.py）
- **Layer 4 (Error)**: 引导性错误消息（错误信息本身就是重试 prompt）

### D2: file_edit 改为 search/replace

- 新签名: `file_edit(file_path, old_string, new_string, replace_all=False)`
- 依赖 ReadFileStateCache 做先读后写验证
- 空 old_string 表示创建新文件

### D3: ReadFileStateCache

- 单例 `_file_state_cache: Dict[str, FileReadRecord]`
- file_read 执行后写入 cache
- file_edit validateInput 时读取 cache 做时间戳比对
- 存储: path → {content_hash, mtime, offset, limit, is_partial}

### D4: 命令分类器 + 管道分析器

- `tools/bash_classifier.py`: CommandCategory enum + 6 个命令集合常量
- `split_pipeline(command)`: 拆分 | && || ; 管道为独立段
- `is_read_only_command(command)`: 管道感知的只读判定
- `detect_sed_inplace(command)`: sed -i 检测

### D5: BackgroundTaskManager

- `tools/background_tasks.py`: 线程池执行 + 状态字典
- 同步执行路径增加 15s auto-background 检查
- bg_status 子命令查询任务状态

### D6: 文件结构

```
qa-agent/tools/
  semantic_params.py      # NEW: Semantic 参数解析器
  file_state_cache.py     # NEW: 读取状态跟踪器
  bash_classifier.py      # NEW: 命令分类器 + 管道分析器
  background_tasks.py     # NEW: 后台任务管理器
  file_tools.py           # MODIFIED: file_edit → search/replace + validateInput
  bash_tool.py            # MODIFIED: 集成分类器/后台化/错误引导
  search_tools.py         # MINOR: 添加 validateInput

qa-agent/core/
  prompts.py              # NEW: System Prompt 工具使用指南
```
