## 1. 项目初始化与基础设施

- [x] 1.1 创建项目目录结构（`core/`、`tools/`、`agents/`、`skills/`、`mcp/`、`coordinator/`、`memory/`、`api/`、`hooks/`）
- [x] 1.2 创建 `requirements.txt`（agno、pymilvus、fastapi、uvicorn、pydantic、python-frontmatter、tiktoken）
- [x] 1.3 创建 `pyproject.toml` 配置项目元信息
- [x] 1.4 创建 `docker-compose.yml`（Milvus、Etcd、MinIO、PostgreSQL 服务）
- [x] 1.5 创建 `.env.example` 包含所有必要环境变量（LLM_BASE_URL、LLM_API_KEY、LLM_MODEL、MILVUS_HOST、STORAGE_DSN 等）
- [x] 1.6 创建 `README.md` 说明项目结构、快速启动步骤和 Skill 开发指南

## 2. 核心配置与状态管理

- [x] 2.1 实现 `core/config.py`：使用 pydantic Settings 从环境变量加载配置，支持 `.env` 文件（LLM配置、Milvus配置、Storage配置、阈值配置）
- [x] 2.2 实现 `core/session_state.py`：定义 `QASessionState` 数据类，包含 `turn_count`、`current_context_tokens`、`max_context_tokens`、`permission_mode`、`agent_type` 等自定义运行时状态，挂载到 `RunContext.session_state`
- [x] 2.3 编写配置和状态单元测试：验证环境变量加载、默认值、session_state 初始化

## 3. 工具系统基础

- [x] 3.1 实现 `tools/base.py`：定义工具元数据字典结构（`permission_level`、`is_read_only`、`is_concurrency_safe`），用于 Agno `@tool` 装饰器的 pre_hook/post_hook 消费
- [x] 3.2 实现 `tools/registry.py`：工具注册表，维护工具名到元数据的映射，支持 `get_tools(agent_type)` 按模式过滤（coordinator 仅返回编排工具）
- [x] 3.3 实现 `tools/file_tools.py`：使用 Agno `@tool` 装饰器定义 `file_read`（L1）、`file_edit`（L2）、`glob_search`（L1）
- [x] 3.4 实现 `tools/bash_tool.py`：`bash`（L2），含命令黑名单检查和超时控制，挂载 L2 pre_hook
- [x] 3.5 实现 `tools/search_tools.py`：`grep`（L1），支持正则搜索和路径过滤
- [x] 3.6 编写工具单元测试：验证权限元数据、工具注册和过滤逻辑

## 4. Agent 引擎核心（Phase 1 MVP）

- [x] 4.1 实现 `core/engine.py`：`create_normal_agent(config)` 工厂函数，返回配置好的 Agno `Agent` 实例（model、tools、storage、memory、instructions）
- [x] 4.2 实现 `core/models.py`：LLM 模型配置，使用 Agno `OpenAIChat` 或 `OpenAIResponses`，从 config 读取 base_url/api_key/model
- [x] 4.3 实现 `core/storage.py`：`get_storage()` 工厂函数，根据配置返回 `SqliteStorage` 或 `PgStorage`
- [x] 4.4 实现 `core/memory_setup.py`：配置 Agno `Memory`（chat_history + user_memory），关联 storage db
- [x] 4.5 实现 Normal 模式 instructions（含 QA 宗旨、工具能力说明、权限行为说明）
- [x] 4.6 实现 `agent.arun(message, stream=True)` 流式执行封装，将 `RunResponse` 事件转为统一的 WebSocket 事件格式
- [x] 4.7 编写 Agent 引擎集成测试：使用 mock model 验证工具调用循环、正常结束

## 5. Hook 系统（权限 + 记忆 + 阈值）

- [x] 5.1 实现 `hooks/permission_hook.py`：Tool pre_hook，根据工具 `permission_level` 和 `permission_mode` 决定是否暂停等待人工（asyncio.Event），发出 `interrupt_request` WebSocket 事件
- [x] 5.2 实现 `hooks/execution_log_hook.py`：Tool post_hook，每次工具执行完成后异步写入 Milvus `qa_execution_log`
- [x] 5.3 实现 `hooks/context_threshold_hook.py`：Run post_hook，检查 `session_state.current_context_tokens`，触发软/硬压缩并写入 Milvus `qa_knowledge`
- [x] 5.4 实现 `hooks/result_verify_hook.py`：Run post_hook，当 Agent 执行完成且 `agent_type != "coordinator"` 时，触发 L3 结果验收暂停
- [x] 5.5 实现 `hooks/interrupt_manager.py`：统一管理 interrupt 状态（asyncio.Event 池），桥接 WebSocket 推送和 HTTP review 响应
- [x] 5.6 编写 Hook 系统单元测试：验证 L2 暂停/恢复/取消、阈值触发、记忆写入时机

## 6. Skill 系统

- [x] 6.1 实现 `skills/loader.py`：扫描 `.claude/skills/` 目录，读取 `SKILL.md`，用 `python-frontmatter` 解析 Frontmatter
- [x] 6.2 实现 `skills/expander.py`：Prompt 展开逻辑（`$ARGUMENTS`、`$named_arg`、`${CLAUDE_SKILL_DIR}` 变量替换）
- [x] 6.3 实现 Shell 命令内嵌执行（`` !`cmd` `` 语法），限时5秒，在 Skill 目录执行
- [x] 6.4 实现 `skills/skill_tool.py`：使用 Agno `@tool` 装饰器定义 `SkillTool`，调用时展开 Prompt 并注入 Agent 对话流
- [x] 6.5 实现用户级（`~/.qa-agent/skills/`）和项目级（`.claude/skills/`）两级 Skill 目录合并加载
- [x] 6.6 创建 3 个示例 Skill（`.claude/skills/`）：`qa-debug-automation`、`excel-diff-analyzer`、`hunter-runner`
- [x] 6.7 编写 Skill 加载单元测试：验证 Frontmatter 解析、变量替换、内嵌命令执行

## 7. 记忆系统（Milvus）

- [x] 7.1 实现 `memory/milvus_client.py`：连接 Milvus，提供 `insert()`、`search()`、`get_client()` 方法，含降级处理（连接失败时返回空结果）
- [x] 7.2 实现 `memory/collections.py`：定义并自动创建三个 Collection（`qa_execution_log`、`qa_knowledge`、`qa_conclusions`），含字段定义和索引配置
- [x] 7.3 实现 `memory/distiller.py`：上下文阈值蒸馏逻辑（调用 LLM 提炼摘要，提取 `pending_steps`），供 `context_threshold_hook` 调用
- [x] 7.4 实现 `memory/writer.py`：`write_execution_log()` 异步非阻塞写入，使用 `asyncio.create_task`
- [x] 7.5 实现 `memory/injector.py`：Worker 启动时 `inject_historical_context(task_desc)` → 语义检索 Top-5 相关记忆 → 返回格式化的 instructions 附加文本
- [x] 7.6 实现 `memory/conclusion_writer.py`：`write_conclusion()`，强制要求 `human_confirmed=True` 才写入
- [x] 7.7 实现 `memory/embedder.py`：文本嵌入封装，支持 OpenAI embedding API（`text-embedding-3-small`）
- [x] 7.8 编写记忆系统单元测试：验证三种写入触发时机、降级模式、结论写入前置条件检查

## 8. Agent 定义系统

- [x] 8.1 实现 `agents/base.py`：`create_agent_from_definition(definition)` 工厂函数，接收 Agent 定义配置，返回 Agno `Agent` 实例
- [x] 8.2 实现 `agents/builtin/explore_agent.py`：`ExploreAgent` 配置（只读工具、简短 instructions、无 memory 注入）
- [x] 8.3 实现 `agents/builtin/qa_automation_agent.py`：`QAAutomationAgent` 配置（含 Hunter/GM/MCP 工具、`permission_mode="ask"`）
- [x] 8.4 实现 `agents/builtin/config_analyzer_agent.py`：`ConfigAnalyzerAgent` 配置（Excel Diff 工具、只读）
- [x] 8.5 实现 `agents/registry.py`：Agent 注册表，支持按名称查找 Agent 定义，返回 Agent 工厂函数
- [x] 8.6 实现 `agents/agent_loader.py`：从 `.claude/agents/` 目录热加载 `AGENT.md` 自定义 Agent（Frontmatter → Agent 配置 + 正文 → instructions）
- [x] 8.7 实现 `AgentSpawnTool`（L1）：使用 Agno `@tool` 装饰器，根据 Agent 名称和任务描述创建子 Agent 实例并调用 `agent.arun()`

## 9. Coordinator 模式（Agno Team）

- [x] 9.1 实现 `coordinator/team_builder.py`：`create_coordinator_team(task, worker_agents)` 工厂函数，返回 Agno `Team(mode=TeamMode.coordinate)` 实例
- [x] 9.2 实现 Leader Agent instructions（含"委派任务给成员""综合各成员结果""并行是核心能力"等 Coordinator 指令）
- [x] 9.3 实现 Worker Agent 动态创建：根据任务类型从 Agent 注册表获取定义，注入 Milvus 历史上下文到 instructions
- [x] 9.4 实现 Team post_hook：Leader 汇总完成后触发 L3 人工验收暂停，展示综合报告
- [x] 9.5 实现 Team post_hook：人工确认后强制写入 Milvus `qa_conclusions`（含 `human_confirmed: true`）
- [x] 9.6 编写 Coordinator 集成测试：验证 Team 创建、Worker 委派、结果汇总、L3 验收流程

## 10. MCP 集成

- [x] 10.1 实现 `mcp/loader.py`：使用 Agno `MCPTools` 连接 MCP 服务器，支持 stdio/sse 传输
- [x] 10.2 实现 MCP 工具权限标注：扫描加载的 MCP 工具，根据工具名或 annotations 自动挂载 L1/L2 pre_hook
- [x] 10.3 实现 MCP 服务器配置：支持从 `.claude/mcp.json` 或环境变量配置 MCP 服务器列表
- [x] 10.4 接入 `game_debug_mcp`：配置 stdio 类型连接，验证 `send_gm_cmd`、`repl_execute` 工具可用
- [x] 10.5 实现 MCP 连接失败降级：连接失败时跳过该服务器工具，不影响 Agent 启动
- [x] 10.6 编写 MCP 集成测试：使用 mock MCP 服务验证工具加载、调用、失败降级

## 11. Hunter 工具集成

- [x] 11.1 实现 `tools/hunter_execute_tool.py`：使用 Agno `@tool(pre_hook=l2_permission_hook)` 定义 `hunter_execute`（L2），封装 Hunter2 Python SDK
- [x] 11.2 实现异步执行支持：若 Hunter2 SDK 不支持 async，使用 `asyncio.run_in_executor` 包装
- [x] 11.3 验证 L2 pre_hook 触发（展示脚本内容预览，等待人工确认）
- [x] 11.4 编写 Hunter 工具单元测试（mock Hunter2 SDK）：验证 L2 暂停、成功执行、失败处理

## 12. FastAPI + AgentOS 服务

- [x] 12.1 实现 `api/server.py`：创建自定义 FastAPI 应用，注册自定义路由，通过 `AgentOS(agents=[], base_app=app)` 集成 Agno
- [x] 12.2 实现 `api/schemas.py`：所有请求/响应的 Pydantic 模型（`CreateSessionRequest`、`SendMessageRequest`、`ReviewRequest`、`SessionStatusResponse` 等）
- [x] 12.3 实现 `api/session_manager.py`：`SessionManager` 类，管理 session_id → Agent 实例映射、状态机（idle/running/interrupt_pending/completed/failed）、interrupt 状态
- [x] 12.4 实现 REST 端点：`POST /sessions`、`POST /sessions/{id}/messages`、`GET /sessions/{id}/status`、`POST /sessions/{id}/review`、`DELETE /sessions/{id}`
- [x] 12.5 实现 `WS /sessions/{id}/stream` WebSocket 端点：接收 Agent `arun(stream=True)` 事件并推送到客户端
- [x] 12.6 实现 interrupt 与 WebSocket 协调：使用 `asyncio.Event` 桥接 Tool pre_hook 暂停和 HTTP review 端点恢复
- [x] 12.7 实现 `GET /skills`、`GET /agents`、`GET /health`、`GET /config` 端点
- [x] 12.8 编写 API 集成测试（FastAPI TestClient）：验证会话创建、消息发送、interrupt 流程、WebSocket 连接

## 13. 项目打包与部署

- [x] 13.1 编写 `Dockerfile`（多阶段构建，基于 `python:3.11-slim`）
- [x] 13.2 更新 `docker-compose.yml` 加入应用服务，配置依赖健康检查
- [x] 13.3 编写部署文档：环境变量说明、Milvus Collection 初始化步骤、Skill 开发指南
- [x] 13.4 实现系统启动检查：应用启动时验证 Milvus/Storage 连接，打印降级警告
