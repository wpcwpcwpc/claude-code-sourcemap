## Context

H73项目QA团队当前通过手动编写Python脚本、人工传递测试上下文和经验来完成自动化测试工作。随着版本迭代加快，测试脚本复用率低、测试经验难以积累传承，且Hunter执行、GM指令等操作的协调成本高。

本系统基于对 Claude Code 源码的深度逆向分析（`restored-src/`），复现其核心 Agent 架构思想，以 Python + Agno 作为实现栈，面向QA工作场景进行专项裁剪。系统对外仅暴露 API（无 CLI/UI），渐进式开发，每个里程碑均可独立使用。Agno 框架选型与团队现有平台保持一致，便于对接和能力复用。

**核心宗旨**：AI辅助人工，人工永远兜底测试结果。

## Goals / Non-Goals

**Goals:**
- 实现可独立部署的 QA Agent API 服务（AgentOS + FastAPI + WebSocket）
- 实现 Agno Agent 驱动的 Normal 模式和 Agno Team(coordinate) 驱动的 Coordinator 模式
- 实现 Markdown-based Skill 系统，QA 工程师可自行编写 SKILL.md 定义专项能力
- 实现三层记忆架构（Agent.memory + Agent.storage + Milvus）及渐进式记忆蒸馏
- 实现四级人工权限体系，关键操作均需人工确认（Tool pre_hook + asyncio.Event）
- 集成现有 `game_debug_mcp`、Hunter2 SDK 等已有基础设施
- 支持 Agno MCPTools 原生加载 MCP 工具

**Non-Goals:**
- 不开发 Terminal UI 或 Web 前端（API-only）
- 不复现 Claude Code 的语音、Vim 模式等 UI 功能
- 不实现 Agent 的 AI 自动生成（手动代码定义即可）
- 不支持多租户/权限隔离（面向内部QA团队）
- 不实现 Claude Code 的 `worktree` / `remote` 隔离模式
- 暂不实现 LLM 供应商抽象层（Phase 1-6 用 OpenAI 兼容接口，最后阶段再抽象）

## Decisions

### D1: Agent 引擎 — Agno Agent

**选择**：使用 Agno `Agent` 声明式定义 + `pre_hooks`/`post_hooks` 实现 Agent 循环及扩展逻辑。

**理由**：
- 与团队现有 Agno 平台保持技术栈一致，便于对接和能力复用
- `Agent()` 声明式配置内置工具调用循环，无需手动构建 Graph 节点
- `AgentOS(base_app=FastAPI)` 原生集成 FastAPI，简化 API 层开发
- `pre_hooks`/`post_hooks` 提供 run 级别和 tool 级别的回调，满足上下文监测和权限拦截需求
- `Agent.storage` 和 `Agent.memory` 提供会话持久化和跨 session 记忆
- `MCPTools` 原生支持 MCP 工具加载，无需额外适配层

**Agent 执行模型**：
```
Agent(model, tools, storage, memory, instructions, pre_hooks, post_hooks)
  └─ agent.arun(message, stream=True)
       └─ 内置循环: LLM → tool_calls → [tool pre_hook: 权限检查] → 执行 → [tool post_hook: 记忆写入]
                                       → [run post_hook: 阈值检查/蒸馏]
                   → LLM继续 → ... → 任务完成
```

**扩展点**：
- `tool pre_hook`：L2 权限拦截，暂停等待人工确认（asyncio.Event）
- `tool post_hook`：每轮执行记录异步写入 Milvus
- `run post_hook`：上下文阈值检查，触发渐进式蒸馏
- `RunContext.session_state`：存储自定义运行时状态（turn_count、current_context_tokens 等）

**放弃**：LangGraph StateGraph（与团队技术栈不一致）、手写 while 循环（缺乏状态管理）。

---

### D2: Skill 执行方式 — Markdown Prompt 注入

**选择**：Skill = `SKILL.md`（Markdown + YAML Frontmatter + 可选辅助脚本），执行时展开为 Prompt 注入对话流。

**理由**：QA 工程师会写 Markdown 和 Python，不需要了解 Agno 内部；Skill 热更新，修改文件即生效。

**Skill 目录约定**：
```
.claude/skills/<skill-name>/
├── SKILL.md        # 必须（Frontmatter + 提示词正文）
└── *.py / *.sh     # 可选辅助脚本，通过 !`...` 内嵌调用
```

**Frontmatter 字段**：`description`, `tools`, `agent`, `paths`, `args`, `effort`, `when_to_use`

**执行流程**：读取 SKILL.md → 执行内嵌 `!`cmd`` → 替换 `$ARGUMENTS`/`${CLAUDE_SKILL_DIR}` → 展开为 HumanMessage 注入对话流

---

### D3: 记忆架构 — 三层渐进式蒸馏

**选择**：短期（Agent.memory.chat_history）+ 中期（Agent.storage + Agent.memory.user_memory）+ 长期（Milvus）三层架构。

**蒸馏触发规则**：
1. **每轮执行结束** → `tool post_hook` 异步写 `qa_execution_log`（事实性，TTL 30天）
2. **上下文超过 70% 阈值** → `run post_hook` 检测触发，LLM提炼综合总结写 `qa_knowledge`，裁剪 chat_history 保留摘要+最近20轮（软压缩）；超过 85% 触发硬压缩（保留最近10轮）
3. **Coordinator 汇总，人工确认后** → 强制写 `qa_conclusions`（含 `human_confirmed: true`，永久保留）

**Agent.storage vs Milvus 职责边界**：
- Agent.storage（Sqlite/Pg）：**抗崩溃/中断**，持久化会话状态（`session_id` 精确恢复）
- Agent.memory.user_memory：**跨会话用户偏好**，Agno 内置的结构化记忆（自动模式）
- Milvus：**信息连贯性**，跨会话语义检索历史经验，新 Worker 启动时注入相关知识（含 `pending_steps` 任务续接）

**Milvus Collections**：

| Collection | 内容 | TTL |
|---|---|---|
| `qa_execution_log` | 每步执行记录（事实性） | 30天 |
| `qa_knowledge` | 阈值触发的综合总结（含 pending_steps） | 永久 |
| `qa_conclusions` | Coordinator 最终结论（含人工确认） | 永久 |

---

### D4: 权限体系 — 四级人工介入

| 级别 | 操作类型 | 介入方式 |
|---|---|---|
| L1 自动执行 | 只读操作（文件读、搜索、查询配置） | 无需人工 |
| L2 执行前确认 | 有副作用操作（Hunter执行、GM指令、写文件） | `tool pre_hook` 暂停(asyncio.Event) → 人确认才执行 |
| L3 结果验收 | 测试结论产出（测试步骤完成、Worker 结束） | `run post_hook` 暂停 → 展示结果 → 人判断 Pass/Fail |
| L4 人工操作 | Bug提交、报告发布、生产配置修改 | AI仅提供建议，操作由人完成 |

---

### D5: Coordinator 模式 — Agno Team(coordinate)

**选择**：使用 Agno `Team(mode=TeamMode.coordinate)` 实现 Coordinator-Worker 模式。Leader Agent 自动委派任务给成员 Agent 并综合结果。

**Team 组成**：
- Leader（Coordinator）：拥有全局视角，负责任务分解、分配和结果综合
- Members（Workers）：每个 Worker 是独立的 `Agent` 实例，拥有各自的工具集和 storage

**Worker 上下文注入**：新 Worker 启动时从 Milvus 语义检索相关历史（含 `pending_steps`）注入 instructions。

**Worker 生命周期**：启动 → 执行 → [tool pre_hook 等待人工] → 继续 → 完成 → post_hook 写 Milvus → 结果返回给 Leader。

---

### D6: Agent 定义 — Python 代码（内置）+ AGENT.md（自定义）

**内置 Agent**（Python 代码，类型安全）：
- `ExploreAgent`：只读探索，`omit_context_docs: true`，`max_turns: 8`
- `QAAutomationAgent`：QA 自动化执行，绑定 Hunter/GM 工具，`permission_mode: "ask"`
- `ConfigAnalyzerAgent`：配置表分析，绑定 Excel Diff，`omit_context_docs: true`

**自定义 Agent**（`.claude/agents/<name>/AGENT.md`，QA 可热更新）。

---

### D7: API 设计 — REST + WebSocket

**端点设计**：
```
POST   /sessions                    # 创建会话
POST   /sessions/{id}/messages      # 发送消息（同步等待完成）
WS     /sessions/{id}/stream        # 流式事件推送
POST   /sessions/{id}/review        # 响应 interrupt（人工审核结果）
GET    /sessions/{id}/status        # 查询会话状态
DELETE /sessions/{id}               # 关闭会话
GET    /skills                      # 列出可用 Skill
GET    /agents                      # 列出可用 Agent
```

**Session 状态机**：`idle → running → interrupt_pending → running → completed/failed`

## Risks / Trade-offs

**[风险] Milvus 冷启动问题** → 初期数据少，语义检索质量差。缓解：提供历史测试记录批量导入工具；无数据时降级为无记忆模式（不影响功能）。

**[风险] Tool Hook 阻塞与 WebSocket 协调复杂度** → L2 Tool pre_hook 中暂停等待人工确认期间，Agent 执行线程被阻塞。缓解：SessionManager 统一管理 interrupt 状态，WebSocket 事件明确区分 `interrupt_request` 和 `interrupt_response`；使用 asyncio.Event 异步等待，不阻塞事件循环。

**[风险] SKILL.md 内嵌 Shell 命令安全性** → QA 可能误写危险命令。缓解：Shell 命令仅在 Skill 加载阶段执行（非用户输入），设置 5秒超时，沙箱化工作目录。

**[风险] 上下文压缩信息丢失** → LLM 提炼时可能遗漏重要细节。缓解：压缩前先写入 `qa_execution_log` 保留原始记录；摘要中标注 `context_coverage` 覆盖范围。

**[取舍] Agent.storage 存储开销** → 完整会话状态快照较大。接受：QA 场景 Worker 数量有限，可靠性优先于存储成本。

## Migration Plan

1. **阶段性推进**：7个 Phase 渐进式开发，每个 Phase 结束均可独立使用
2. **现有 Skill 迁移**：将 `hunter-runner`、`qa-debug-automation`、`excel-diff-analyzer` 等从 CodeMaker Skill 格式适配为 `SKILL.md` 格式（格式相似，手动迁移）
3. **MCP 接入**：`game_debug_mcp` 通过 Agno `MCPTools` 原生接入，无需改造
4. **回滚策略**：各 Phase 独立，任何阶段中止均不影响前序功能

## Open Questions

- **Q1**: Milvus 部署形态？本地 Docker（开发）还是托管云服务（生产）？
- **Q2**: Agent.storage 存储：PostgreSQL（多实例）还是 SQLite（单机）？（Agno 两者均内置支持）
- **Q3**: Hunter2 SDK 是否支持 async/await？影响 HunterExecuteTool 实现方式
- **Q4**: Embedding 模型选择？推荐 `text-embedding-3-small`（1536维）或本地 `bge-m3`