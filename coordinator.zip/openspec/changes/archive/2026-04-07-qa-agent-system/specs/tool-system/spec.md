## ADDED Requirements

### Requirement: 工具元数据定义
系统 SHALL 为每个 Agno `@tool` 定义的工具附加元数据字典（`permission_level`（L1-L4）、`is_read_only`、`is_concurrency_safe`、`is_destructive`），元数据通过工具注册表（`tools/registry.py`）维护，供 pre_hook/post_hook 消费。

#### Scenario: 工具属性标注
- **WHEN** 定义一个新的 `hunter_execute` 工具
- **THEN** 该工具 SHALL 在注册表中标注 `permission_level=2`、`is_read_only=False`、`is_concurrency_safe=False`

#### Scenario: 只读工具标注
- **WHEN** 定义 `file_read` 工具
- **THEN** 该工具 SHALL 标注 `permission_level=1`、`is_read_only=True`、`is_concurrency_safe=True`

---

### Requirement: 内置 QA 工具集
系统 SHALL 提供以下内置工具，均使用 Agno `@tool` 装饰器定义：`file_read`（L1）、`file_edit`（L2）、`bash`（L2）、`grep`（L1）、`glob`（L1）、`hunter_execute`（L2）、`agent_spawn`（L1）。

#### Scenario: file_read 执行
- **WHEN** Agent 调用 `file_read(path="qa_debug/Case001.py")`
- **THEN** 系统 SHALL 读取文件内容，返回结构化结果，超过 `max_result_size`（默认100KB）时截断并提示

#### Scenario: hunter_execute 权限拦截
- **WHEN** Agent 调用 `hunter_execute(script="...")` 且 `permission_mode` 非 `bypass`
- **THEN** Tool pre_hook SHALL 触发 asyncio.Event 暂停，展示脚本预览，等待人工确认后再执行

#### Scenario: bash 安全限制
- **WHEN** Agent 调用 `bash(command="rm -rf /")`
- **THEN** 系统 SHALL 拒绝执行（命令黑名单检查），返回错误信息

---

### Requirement: MCP 工具动态加载
系统 SHALL 通过 Agno `MCPTools` 连接配置的 MCP 服务器，将 MCP 工具动态加载并注入 Agent 工具集，支持 stdio 和 sse 传输协议。

#### Scenario: game_debug_mcp 接入
- **WHEN** 配置中包含 `game_debug_mcp` stdio 类型 MCP 服务器
- **THEN** 系统 SHALL 通过 Agno `MCPTools(transport=StdioServerParameters(...))` 连接该 MCP 服务器，将 `send_gm_cmd`、`repl_execute`、`list_gm_categories` 等工具加载为 Agent 可用工具

#### Scenario: MCP 工具权限标注
- **WHEN** MCP 工具的 `annotations.readOnlyHint` 为 false
- **THEN** 该工具 SHALL 在注册表中自动获得 L2 权限级别（通过 pre_hook 需要人工确认）

#### Scenario: MCP 服务器连接失败
- **WHEN** MCP 服务器启动失败
- **THEN** 系统 SHALL 记录 error 日志，跳过该服务器的工具，不影响其他工具和 Agent 执行

---

### Requirement: 工具注册表
系统 SHALL 维护全局工具注册表（`tools/registry.py`），支持按 `agent_type` 过滤工具集：`coordinator` Leader Agent 仅通过 Team 机制委派任务（无需手动工具过滤）；`normal` 类型返回全部工具（含 MCP 工具和 Skill 工具）。

#### Scenario: Normal 模式工具集
- **WHEN** `agent_type="normal"` 且配置了 `game_debug_mcp`
- **THEN** `get_tools(agent_type="normal")` SHALL 返回内置工具 + MCP 工具 + Skill 工具的合集

#### Scenario: Worker Agent 工具集
- **WHEN** Worker Agent 被 Coordinator Team 创建
- **THEN** 该 Worker 的工具集 SHALL 根据其 Agent 定义（来自注册表）自动配置，包含对应的内置工具和 MCP 工具

---

### Requirement: 工具并发安全控制
系统 SHALL 在工具执行时，根据工具注册表中的 `is_concurrency_safe` 属性决定工具的并发执行策略：并发安全的工具可并行执行，否则串行执行。

#### Scenario: 并发安全工具并行
- **WHEN** LLM 一次响应中调用多个 `is_concurrency_safe=True` 的工具（如 `file_read`、`grep`）
- **THEN** 系统 SHALL 使用 `asyncio.gather` 并发执行，提高效率

#### Scenario: 非并发安全工具串行
- **WHEN** LLM 一次响应中包含 `is_concurrency_safe=False` 的工具（如 `hunter_execute`）
- **THEN** 系统 SHALL 串行执行该工具，等待完成后再执行下一个