## ADDED Requirements

### Requirement: 三层记忆架构
系统 SHALL 实现短期（Agno Memory chat_history）、中期（Agno Storage 持久化）、长期（Milvus 语义检索）三层记忆，各层独立运作且职责互补。

#### Scenario: 短期记忆（会话内）
- **WHEN** Agent 在一次会话内执行多轮工具调用
- **THEN** Agno `Memory` SHALL 自动保存完整的对话历史（chat_history），在 Agent 生命周期内全程可访问

#### Scenario: 中期记忆（Storage 持久化恢复）
- **WHEN** Agent 因暂停或服务重启后需要恢复
- **THEN** 通过 Agno `Storage`（SqliteStorage / PgStorage）按 `session_id` 精确恢复 Agent 状态到中断时刻，继续执行而不丢失上下文

#### Scenario: 长期记忆（Milvus 语义检索）
- **WHEN** 新 Agent 或 Worker 启动时提供任务描述
- **THEN** 系统 SHALL 从 Milvus 语义检索 Top-K 相关历史记忆，注入到 Agent instructions 的 `[Related Historical Knowledge]` 区域

---

### Requirement: 渐进式记忆蒸馏 — 执行记录写入
系统 SHALL 在每次工具执行完成后通过 Tool post_hook 异步写入执行记录到 Milvus `qa_execution_log` Collection，记录本轮的工具调用和结论摘要。

#### Scenario: 每轮自动写入
- **WHEN** 一次工具调用完成
- **THEN** post_hook SHALL 异步写入包含 `worker_id`、`session_id`、`step_no`、`tool_used`、`result_summary`、`game_version`、`module`、`timestamp` 的向量记录到 `qa_execution_log`

#### Scenario: 写入失败不阻塞执行
- **WHEN** Milvus 写入发生超时或连接错误
- **THEN** 系统 SHALL 记录 error 日志，不中断 Agent 主循环执行

---

### Requirement: 渐进式记忆蒸馏 — 上下文阈值压缩
系统 SHALL 在 Run post_hook 中监测当前上下文 token 使用量，超过软阈值（70%）时触发 LLM 提炼综合总结写入 Milvus，并压缩对话历史；超过硬阈值（85%）时触发强制硬压缩。

#### Scenario: 软压缩（70% 阈值）
- **WHEN** `session_state.current_context_tokens / session_state.max_context_tokens >= 0.70`
- **THEN** 系统 SHALL 调用 LLM 提炼历史对话为结构化摘要（含 `completed_steps`、`pending_steps`、`findings`、`context_coverage`），写入 Milvus `qa_knowledge`，并将对话历史压缩为 `[SystemMessage(摘要), 最近20轮消息]`

#### Scenario: 硬压缩（85% 阈值）
- **WHEN** `session_state.current_context_tokens / session_state.max_context_tokens >= 0.85`
- **THEN** 系统 SHALL 强制压缩，将对话历史替换为 `[SystemMessage(摘要), 最近10轮消息]`

#### Scenario: pending_steps 续接
- **WHEN** 压缩后 Worker 继续执行或新 Worker 接替
- **THEN** 系统 SHALL 从 Milvus 检索最近的 `qa_knowledge` 记录，读取 `pending_steps` 字段作为任务续接依据

---

### Requirement: 渐进式记忆蒸馏 — Coordinator 强制写入结论
系统 SHALL 在 Coordinator Team 完成所有 Worker 汇总且人工确认通过后，通过 Team post_hook 强制将测试结论写入 Milvus `qa_conclusions` Collection，且 `human_confirmed` 字段必须为 `true`。

#### Scenario: 人工确认后强制写入
- **WHEN** Coordinator 完成汇总，人工通过 `POST /sessions/{id}/review` 提交确认
- **THEN** 系统 SHALL 强制写入包含 `verdict`（pass/fail/pass_with_issues）、`human_confirmed: true`、`confirmed_by`、`key_findings`、`bugs_found`、`game_version`、`module` 的记录到 `qa_conclusions`

#### Scenario: 未经人工确认不写入结论
- **WHEN** 系统尝试写入 `qa_conclusions` 时 `human_confirmed` 为 `false`
- **THEN** 系统 SHALL 拒绝写入并抛出异常

---

### Requirement: Milvus Collection 设计
系统 SHALL 初始化三个 Milvus Collection，各 Collection 有明确的向量维度、必填字段和 TTL 策略。

#### Scenario: Collection 自动初始化
- **WHEN** 系统首次启动且 Milvus 中对应 Collection 不存在
- **THEN** 系统 SHALL 自动创建 `qa_execution_log`（TTL 30天）、`qa_knowledge`（永久）、`qa_conclusions`（永久）三个 Collection，向量维度为 1536

#### Scenario: Milvus 不可用时降级
- **WHEN** 系统启动时无法连接到 Milvus
- **THEN** 系统 SHALL 以"无长期记忆模式"启动（仅短期 Memory + 中期 Storage），记录 warning，不影响 Agent 基本功能

---

### Requirement: Agno Storage 持久化集成
系统 SHALL 使用 Agno 的 `Storage` 协议持久化 Agent 会话状态，支持 `SqliteStorage`（单机开发）和 `PgStorage`（多实例生产）两种后端。

#### Scenario: 状态自动保存
- **WHEN** Agent 每轮执行完成时
- **THEN** Agno Storage SHALL 自动将当前会话状态（含 chat_history、session_state）持久化到数据库，关联 `session_id`

#### Scenario: 暂停后精确恢复
- **WHEN** Agent 因 Hook 暂停后，人工提交审核结果
- **THEN** 系统 SHALL 通过 `session_id` 加载存储的会话状态，从暂停点继续执行，对话历史完整保留