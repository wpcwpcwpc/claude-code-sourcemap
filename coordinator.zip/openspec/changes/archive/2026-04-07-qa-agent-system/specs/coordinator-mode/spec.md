## ADDED Requirements

### Requirement: Agno Team Coordinator 模式
系统 SHALL 使用 Agno `Team(mode=TeamMode.coordinate)` 构建 Coordinator 模式，Leader Agent 自动协调多个 Worker Agent，支持并行任务委派和结果汇总。

#### Scenario: Team 创建
- **WHEN** 用户请求以 Coordinator 模式执行复杂任务
- **THEN** 系统 SHALL 通过 `create_coordinator_team(task, worker_agents)` 工厂函数创建 `Team` 实例，Leader 的 instructions 包含任务编排和并行调度指令

---

### Requirement: Worker Agent 动态成员注册
系统 SHALL 根据任务需求从 Agent 注册表中选取合适的 Agent 定义，创建 Worker Agent 实例并注册为 Team 的 `members`。

#### Scenario: 任务分解与成员选取
- **WHEN** 用户输入"测试H73 v2.4战斗系统"
- **THEN** Leader Agent SHALL 将任务分解为子任务（如："伤害计算测试"、"技能CD测试"），并委派给具有对应能力的 Worker Agent 成员

#### Scenario: Worker 隔离
- **WHEN** Worker A 执行失败
- **THEN** Worker B 和 C 的执行 SHALL 不受影响，Leader 收到 Worker A 的错误结果后继续处理其他结果

#### Scenario: Worker 上下文注入
- **WHEN** Worker 启动时
- **THEN** 系统 SHALL 从 Milvus 检索与任务描述相关的历史知识（含 `pending_steps`）注入为 Worker 的 instructions 附加部分

---

### Requirement: Leader 任务委派
Leader Agent SHALL 通过 Agno Team 的内置协调机制将子任务委派给成员 Agent，支持并行委派。

#### Scenario: 并行启动多个 Worker
- **WHEN** Leader 决定同时执行任务 A、B、C
- **THEN** Team 框架 SHALL 并发调度三个 Worker Agent 实例执行，互不阻塞

#### Scenario: 动态调整
- **WHEN** Leader 根据前序 Worker 结果判断需追加新任务
- **THEN** Leader SHALL 可动态委派新的子任务给可用的 Worker 成员

---

### Requirement: 结果汇总
Leader Agent SHALL 在所有 Worker 执行完成后，综合各成员结果生成综合测试报告，并触发 L3 人工结果验收。

#### Scenario: 综合报告生成
- **WHEN** 所有 Worker 执行完成（含成功和失败）
- **THEN** Leader SHALL 基于所有 Worker 结果生成包含"测试覆盖"、"发现问题"、"整体结论"的综合报告

#### Scenario: L3 人工验收触发
- **WHEN** 综合报告生成完毕
- **THEN** 系统 SHALL 通过 Team post_hook 触发暂停（asyncio.Event），将报告展示给人工确认，人工选择 `pass`/`fail`/`pass_with_issues` 后恢复执行

#### Scenario: 强制写入结论
- **WHEN** 人工完成 L3 验收确认
- **THEN** 系统 SHALL 强制将验收结论写入 Milvus `qa_conclusions`（含 `human_confirmed: true`）