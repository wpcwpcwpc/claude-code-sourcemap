## ADDED Requirements

### Requirement: 四级权限体系定义
系统 SHALL 定义四级权限级别，每级对应明确的操作类型和人工介入方式，所有工具必须标注权限级别。

#### Scenario: L1 自动执行
- **WHEN** Agent 调用权限级别为 L1 的工具（如 `file_read`、`grep`）
- **THEN** 系统 SHALL 直接执行，不触发任何人工介入

#### Scenario: L2 执行前确认
- **WHEN** Agent 调用权限级别为 L2 的工具（如 `hunter_execute`、`bash`、`send_gm_cmd`）且 `permission_mode != "bypass"`
- **THEN** 系统 SHALL 通过 Tool pre_hook 暂停执行（asyncio.Event.wait()），向调用方发出 `interrupt_request`（含操作预览）

#### Scenario: L3 结果验收
- **WHEN** Worker 完成一个测试步骤或 Coordinator 完成汇总，产出测试结论
- **THEN** 系统 SHALL 通过 Run post_hook 暂停，展示测试结果，等待人工判断 pass/fail/rerun/investigate

#### Scenario: L4 人工操作
- **WHEN** Agent 分析认为需要提交 Bug、发布报告等 L4 操作时
- **THEN** 系统 SHALL 在消息中提供操作建议（含 Bug 标题、详情、严重程度等），由人工决定是否执行

---

### Requirement: Agno Hook 暂停与恢复机制
系统 SHALL 使用 Agno `pre_hook`/`post_hook` 结合 `asyncio.Event` 实现人工介入，暂停时通过 WebSocket 发出 `interrupt_request` 事件，恢复时通过 `POST /sessions/{id}/review` 端点接收人工决策。

#### Scenario: pre_hook 暂停触发
- **WHEN** L2 工具被调用时 Tool pre_hook 检测到需要人工确认
- **THEN** pre_hook 创建 `asyncio.Event` 并 `await event.wait()`，Agent 执行暂停，WebSocket 发出 `{"event_type": "interrupt_request", "interrupt_type": "preview_confirm", "payload": {...}}`

#### Scenario: 人工确认后恢复
- **WHEN** 人工通过 `POST /sessions/{id}/review` 提交 `{"action": "confirm"}`
- **THEN** 系统 SHALL 通过 `InterruptManager` 找到对应 `asyncio.Event` 调用 `event.set()`，pre_hook 返回允许执行，Agent 继续

#### Scenario: 人工取消
- **WHEN** 人工提交 `{"action": "cancel"}`
- **THEN** 系统 SHALL 设置 event 并标记取消状态，pre_hook 返回取消结果（`{"status": "cancelled_by_user"}`），Agent 跳过该工具调用并继续处理

#### Scenario: 人工修改内容
- **WHEN** 人工提交 `{"action": "modify", "modified_content": "..."}`（仅适用于 L2 脚本类操作）
- **THEN** 系统 SHALL 将修改后的内容注入 pre_hook 返回值，工具使用修改后的参数执行

---

### Requirement: permission_mode 配置
系统 SHALL 支持 `permission_mode` 配置项（存储在 `session_state` 中），影响 L2 工具的权限行为：`default`（正常询问）、`plan`（展示计划但不执行）、`bypass`（跳过所有 L2 确认，全自动执行）。

#### Scenario: bypass 模式跳过 L2 确认
- **WHEN** `permission_mode = "bypass"` 且调用 L2 工具
- **THEN** pre_hook SHALL 直接放行，不触发 asyncio.Event 暂停，但执行记录仍通过 post_hook 写入 Milvus

#### Scenario: plan 模式展示但不执行
- **WHEN** `permission_mode = "plan"` 且 Agent 准备执行 L2 工具
- **THEN** pre_hook SHALL 触发暂停，展示完整执行计划，等待人工明确确认后才放行实际执行

---

### Requirement: interrupt_request 事件格式
系统 SHALL 定义标准的 `interrupt_request` WebSocket 事件格式，包含足够信息供前端渲染人工审核界面。

#### Scenario: L2 预览确认事件格式
- **WHEN** L2 工具触发 interrupt
- **THEN** 发出 `{"event_type": "interrupt_request", "interrupt_type": "preview_confirm", "session_id": "...", "tool_name": "hunter_execute", "preview": "脚本内容...", "actions": ["confirm", "modify", "cancel"]}`

#### Scenario: L3 结果验收事件格式
- **WHEN** L3 结果验收触发 interrupt
- **THEN** 发出 `{"event_type": "interrupt_request", "interrupt_type": "result_verify", "session_id": "...", "result_summary": "...", "actions": ["pass", "fail", "rerun", "investigate"]}`