## ADDED Requirements

### Requirement: 会话生命周期管理
系统 SHALL 通过 `SessionManager` 管理所有 Agent 会话，每个会话有唯一 `session_id`，状态机为 `idle → running → interrupt_pending → running → completed/failed`。

#### Scenario: 创建会话
- **WHEN** 调用 `POST /sessions` 并提供 `agent_type`（`normal` 或 `coordinator`）和可选配置
- **THEN** 系统 SHALL 创建新会话，返回 `{"session_id": "uuid", "status": "idle"}`

#### Scenario: 会话状态流转
- **WHEN** 会话收到消息开始执行
- **THEN** 状态 SHALL 变为 `running`；触发 Hook interrupt 时变为 `interrupt_pending`；人工审核完成后变回 `running`；执行完成后变为 `completed`

#### Scenario: 会话超时清理
- **WHEN** 会话在 `interrupt_pending` 状态超过 30 分钟（可配置）无人工响应
- **THEN** 系统 SHALL 自动将会话状态设为 `failed`，记录超时原因

---

### Requirement: REST API 端点
系统 SHALL 提供标准 RESTful API（基于 FastAPI），所有请求/响应使用 JSON 格式，HTTP 状态码遵循 REST 规范。

#### Scenario: 发送消息（异步）
- **WHEN** 调用 `POST /sessions/{id}/messages` 并提供 `{"content": "测试战斗系统"}`
- **THEN** 系统 SHALL 启动 Agent `arun()` 执行（异步），立即返回 `{"message_id": "...", "status": "accepted"}`；完整结果通过 WebSocket 或 GET 轮询获取

#### Scenario: 查询会话状态
- **WHEN** 调用 `GET /sessions/{id}/status`
- **THEN** 响应 SHALL 包含 `status`、`turn_count`、`last_event`、`interrupt_payload`（若处于 interrupt_pending 状态）

#### Scenario: 提交人工审核结果
- **WHEN** 调用 `POST /sessions/{id}/review` 并提供 `{"action": "confirm", "notes": "..."}`
- **THEN** 系统 SHALL 通过 `InterruptManager` 恢复对应会话的 Agent 执行，注入人工决策

#### Scenario: 列出可用 Agent
- **WHEN** 调用 `GET /agents`
- **THEN** 响应 SHALL 包含所有已注册 Agent 的 `name`、`description`、`when_to_use`、`tools`、`permission_mode` 字段

---

### Requirement: WebSocket 流式推送
系统 SHALL 提供 `WS /sessions/{id}/stream` 端点，以 WebSocket 协议实时推送 Agent 执行事件。

#### Scenario: 连接 WebSocket
- **WHEN** 客户端连接 `WS /sessions/{id}/stream`
- **THEN** 系统 SHALL 接受连接，后续该会话产生的所有事件（token、tool_call_started、tool_call_completed、interrupt_request、run_complete）均通过此 WebSocket 推送

#### Scenario: 流式事件格式
- **WHEN** LLM 生成 token
- **THEN** WebSocket 推送 `{"event_type": "on_llm_stream", "session_id": "...", "content": "token内容", "timestamp": "..."}`

#### Scenario: interrupt_request 推送
- **WHEN** Agent Hook 触发暂停
- **THEN** WebSocket 推送 `{"event_type": "interrupt_request", "interrupt_type": "preview_confirm|result_verify", "payload": {...}}`，会话状态变为 `interrupt_pending`

#### Scenario: WebSocket 断开重连
- **WHEN** WebSocket 连接断开后客户端重新连接
- **THEN** 系统 SHALL 允许重新连接，会话执行不中断，可通过 `GET /sessions/{id}/status` 获取当前状态

---

### Requirement: AgentOS 集成
系统 SHALL 使用 Agno `AgentOS(agents=[], base_app=app)` 将自定义 FastAPI 应用与 Agno 框架集成，自定义路由和 AgentOS 内置路由共存。

#### Scenario: 自定义路由优先
- **WHEN** FastAPI 应用注册了自定义路由（如 `/sessions`、`/review`）
- **THEN** 自定义路由 SHALL 正常工作，不被 AgentOS 默认路由覆盖

---

### Requirement: Agent 注册表 API
系统 SHALL 提供 `GET /agents` 端点，返回所有可用 Agent 的元信息，包括内置 Agent 和 `AGENT.md` 文件定义的自定义 Agent。

#### Scenario: 列出所有 Agent
- **WHEN** 调用 `GET /agents`
- **THEN** 响应 SHALL 包含 `ExploreAgent`、`QAAutomationAgent`、`ConfigAnalyzerAgent` 等内置 Agent 和所有 `.claude/agents/` 目录下的自定义 Agent

---

### Requirement: 健康检查与配置端点
系统 SHALL 提供 `GET /health` 端点（服务健康状态含 Milvus 和 Storage 连接状态）和 `GET /config` 端点（当前配置摘要，不含敏感信息）。

#### Scenario: 健康检查
- **WHEN** 调用 `GET /health`
- **THEN** 响应 SHALL 包含 `{"status": "ok|degraded", "milvus": "connected|disconnected", "storage": "connected|disconnected", "version": "..."}`