## ADDED Requirements

### Requirement: Skill 目录加载
系统 SHALL 从 `.claude/skills/` 目录递归扫描，每个子目录下的 `SKILL.md` 文件构成一个 Skill 定义，目录名即 Skill 名称。

#### Scenario: 加载成功
- **WHEN** `.claude/skills/qa-debug-automation/SKILL.md` 存在
- **THEN** 系统 SHALL 加载并注册名为 `qa-debug-automation` 的 Skill，可通过 `/qa-debug-automation` 调用

#### Scenario: 缺少 SKILL.md
- **WHEN** Skill 目录下不存在 `SKILL.md` 文件
- **THEN** 系统 SHALL 跳过该目录并记录 warning 日志，不中断其他 Skill 加载

#### Scenario: 热更新
- **WHEN** `SKILL.md` 文件内容被修改
- **THEN** 系统 SHALL 在下次调用时重新加载（不缓存跨请求），无需重启服务

### Requirement: Frontmatter 解析
系统 SHALL 使用 `python-frontmatter` 解析 `SKILL.md` 的 YAML Frontmatter，提取标准字段并进行类型校验。

#### Scenario: 标准字段提取
- **WHEN** SKILL.md 包含 Frontmatter
- **THEN** 系统 SHALL 提取以下字段：`description`（必填）、`tools`（list，可选）、`agent`（str，可选）、`paths`（list，可选）、`args`（list，可选）、`effort`（1-5，可选）、`when_to_use`（str，可选）

#### Scenario: 缺少必填字段
- **WHEN** SKILL.md 的 Frontmatter 中缺少 `description` 字段
- **THEN** 系统 SHALL 拒绝加载该 Skill，记录 error 日志含文件路径

---

### Requirement: Skill 目录发现与热加载
系统 SHALL 从 `.claude/skills/<skill-name>/SKILL.md` 路径自动发现 Skill，支持用户级（`~/.qa-agent/skills/`）和项目级（`.claude/skills/`）两级目录，并在文件变更时热更新（不重启服务）。

#### Scenario: 目录扫描
- **WHEN** 系统启动或调用 `GET /skills` 端点
- **THEN** 系统 SHALL 扫描所有 Skill 目录，返回包含 `name`、`description`、`when_to_use`、`tools` 的 Skill 列表

#### Scenario: 热更新
- **WHEN** QA 工程师修改 `.claude/skills/qa-automation/SKILL.md` 文件内容
- **THEN** 系统 SHALL 在下次调用该 Skill 时自动加载最新内容，无需重启服务

---

### Requirement: Prompt 展开与变量替换
系统 SHALL 在执行 Skill 时按顺序进行：内嵌 Shell 命令执行、变量替换，生成最终 expanded prompt。

#### Scenario: 内嵌 Shell 命令执行
- **WHEN** SKILL.md 正文中包含 `` !`python scan_cases.py` `` 语法
- **THEN** 系统 SHALL 在 Skill 的 `baseDir` 目录执行该命令（超时5秒），将 stdout 替换到对应位置

#### Scenario: `$ARGUMENTS` 替换
- **WHEN** 用户调用 `/qa-debug-automation iOS 登录流程` 并且 SKILL.md 中含 `$ARGUMENTS`
- **THEN** 系统 SHALL 将 `$ARGUMENTS` 替换为 `iOS 登录流程`

#### Scenario: `${CLAUDE_SKILL_DIR}` 替换
- **WHEN** SKILL.md 中含 `${CLAUDE_SKILL_DIR}`
- **THEN** 系统 SHALL 将其替换为该 Skill 目录的绝对路径（Windows 下使用正斜杠）

#### Scenario: 命名参数替换
- **WHEN** Frontmatter 中定义 `args: [scenario, platform]`，用户输入 `iOS 登录`
- **THEN** 系统 SHALL 将 `$scenario` 替换为 `iOS 登录`，未提供的参数保留原始占位符

---

### Requirement: Skill 作为 SkillTool 注入 Agent
系统 SHALL 实现 `SkillTool`，使用 Agno `@tool` 装饰器定义，调用时将展开后的 Skill Prompt 作为新的 `HumanMessage` 注入当前对话流，Agent 接收后继续执行。

#### Scenario: Skill 调用触发 Prompt 注入
- **WHEN** Agent 调用 `skill__qa-debug-automation(arguments="iOS登录测试")` 工具
- **THEN** 系统 SHALL 加载并展开对应 SKILL.md，将 expanded prompt 作为新消息注入对话流

#### Scenario: Agent 继续执行
- **WHEN** Skill expanded prompt 被注入后
- **THEN** Agent 的下一轮 LLM 调用 SHALL 能读取该消息并基于 Skill 指令继续工作

#### Scenario: Skill 工具描述
- **WHEN** Agent 准备工具列表
- **THEN** 每个 SkillTool 的 LLM 可见 description SHALL 包含 Frontmatter 中的 `description` 和 `when_to_use` 字段

---

### Requirement: Skill 与 Agent 绑定
系统 SHALL 支持 Frontmatter 中的 `agent` 字段，当 Skill 被调用且该字段非空时，系统 SHALL 以指定 Agent 类型启动子 Agent 执行 Skill 展开后的任务。

#### Scenario: 绑定 Agent 的 Skill 调用
- **WHEN** SKILL.md 中 `agent: qa-automation-agent`，且该 Agent 已在注册表中
- **THEN** 系统 SHALL 创建 `QAAutomationAgent` 子实例执行展开后的 Prompt，而非在主 Agent 中执行