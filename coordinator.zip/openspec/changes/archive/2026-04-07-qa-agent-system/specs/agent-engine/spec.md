## ADDED Requirements

### Requirement: Agent 运行时状态定义
系统 SHALL 通过 `session_state`（挂载在 Agno `RunContext` 上）管理 Agent 运行时元数据，包括消息历史（由 Agno `Memory` 自动管理）、执行状态、Agent 配置、上下文阈值、和 MCP 状态。

#### Scenario: 状态初始化
- **WHEN** 创建新的 Agent 执行会话
- **THEN** `session_state` 中 `turn_count` 为 0，`stop_reason` 为 None，`max_turns` 默认为 25，`permission_mode` 默认为 `"default"`

#### Scenario: 消息管理
- **WHEN** Agent 循环产生新的 Assistant 消息或 Tool 执行结果
- **THEN** Agno `Memory` 自动追加到 chat_history，并在后续轮次中自动携带到 LLM 调用

---

### Requirement: Normal Agent 构建
系统 SHALL 通过 `create_normal_agent(config)` 工厂函数声明式构建 Agno `Agent` 实例，包含 model、tools、storage、memory、instructions、pre_hook/post_hook 配置，Agent 内部的工具调用循环由 Agno 框架驱动。

#### Scenario: 工具调用循环
- **WHEN** LLM 响应包含 tool_calls
- **THEN** Agno Agent 自动执行工具（触发 pre_hook/post_hook），将结果反馈给 LLM，继续循环直到 LLM 不再请求工具

#### Scenario: 任务完成退出
- **WHEN** LLM 响应不包含 tool_calls（即模型认为任务完成）
- **THEN** Agent 循环终止，返回 `RunResponse`，由 post_hook 决定是否触发后续逻辑（如 L3 验收或记忆蒸馏）

#### Scenario: 超过最大轮次
- **WHEN** `session_state.turn_count >= session_state.max_turns`
- **THEN** `stop_reason` 设置为 `"max_turns"`，Agent 被强制终止，post_hook 记录超时事件

---

### Requirement: 流式执行接口
系统 SHALL 提供异步流式接口 `agent.arun(message, stream=True)` 执行 Agent，通过 `RunResponse` 事件流向调用方逐步推送执行事件。

#### Scenario: 流式事件输出
- **WHEN** 调用 `agent.arun("测试战斗系统", stream=True)`
- **THEN** 返回异步迭代器，依次 yield 包含 `event`（`RunEvent.tool_call_started`、`RunEvent.tool_call_completed`、`RunEvent.assistant_response_stream`、`interrupt_request`、`RunEvent.run_complete`）的 `RunResponse` 对象

#### Scenario: LLM 供应商配置
- **WHEN** 初始化 Agent 时提供 `llm_base_url`、`llm_api_key`、`llm_model`
- **THEN** 使用 Agno `OpenAIChat(api_key=..., base_url=..., id=...)` 以 OpenAI 兼容接口连接到指定供应商，支持流式输出

---

### Requirement: System Prompt（Instructions）管理
系统 SHALL 通过 Agno `Agent(instructions=...)` 配置 System Prompt，Normal 模式与 Coordinator 模式使用不同的 instructions 文本。

#### Scenario: Instructions 注入
- **WHEN** Agent 启动时
- **THEN** Agno 自动将 `instructions` 作为 System Message 置于对话最前方，包含角色说明、工具列表、QA 宗旨

#### Scenario: Coordinator Instructions
- **WHEN** Agent 是 Coordinator Team 的 Leader
- **THEN** instructions 包含"将任务委派给成员""综合各成员结果""并行是你的核心能力"等 Coordinator 特有指令