## Why

QA团队目前依赖手工编写测试脚本和人工传递上下文，随着H73游戏版本迭代加快，测试覆盖率和知识传承效率严重不足。需要一个以"AI辅助人工、人工兜底结果"为宗旨的智能Agent系统，让QA工程师能快速定义专项测试Skill并复用历史测试经验，从而提升自动化测试效率。

## What Changes

- **新增** 基于 Agno 的 Agent 执行引擎，支持 Normal（Agent）/ Coordinator（Team coordinate）两种模式
- **新增** Markdown-based Skill 系统，QA 工程师通过编写 `SKILL.md` 定义专项测试技能
- **新增** 三层记忆架构：短期 Agent.memory、中期 Agent.storage、长期 Milvus 向量库
- **新增** 渐进式记忆蒸馏机制：执行记录写入 → 上下文阈值触发综合总结 → Coordinator 强制写入结论
- **新增** 四级人工权限体系，所有测试结果均需人工兜底确认（基于 Agno Tool pre_hook + asyncio.Event）
- **新增** MCP 集成层，复用现有 `game_debug_mcp` 的 GM 指令、REPL 执行能力
- **新增** FastAPI RESTful + WebSocket 流式 API 服务，对外暴露 Agent 能力
- **新增** 内置 QA 专用工具集：Hunter 执行、配置表分析、Excel Diff 等

## Capabilities

### New Capabilities

- `agent-engine`: Agno Agent 声明式实现的 Agent 核心执行引擎，支持 Normal/Coordinator 模式切换、内置工具调用循环、流式响应
- `skill-system`: Markdown-based Skill 加载与执行系统，支持 Frontmatter 元数据、内嵌 Shell 命令、参数替换、动态 Prompt 注入
- `memory-system`: 三层记忆架构（Agent.memory + Agent.storage + Milvus），含渐进式记忆蒸馏和跨会话语义检索
- `tool-system`: QA 专用工具集，含权限级别标注、并发安全控制、Hunter 集成、MCP 动态加载
- `coordinator-mode`: Agno Team(coordinate) 模式，支持多 Worker 并行编排、Leader 委派、结果汇总
- `permission-system`: 四级人工权限体系，基于 Agno Tool Hook + asyncio.Event 实现预览确认和结果验收
- `api-service`: FastAPI REST + WebSocket 服务，含会话管理、流式响应、人工审核端点

### Modified Capabilities

（无，这是全新系统）

## Impact

- **新增依赖**: `agno`, `pymilvus`, `fastapi`, `uvicorn`, `pydantic`, `python-frontmatter`, `tiktoken`
- **新增基础设施**: Milvus 向量数据库实例（本地 Docker 或云端）、PostgreSQL 或 SQLite（Agent.storage 持久化）
- **复用现有能力**: `game_debug_mcp` MCP 服务器（stdio 协议直接接入）、Hunter2 Python SDK、现有 Excel Diff 分析 API
- **目标用户**: H73 项目 QA 工程师，通过 REST API 或直接 Python SDK 调用
- **部署形态**: Python 后端服务（Docker），不包含前端 UI（API-only）
