"""
Stream Adapter — bridges Agno Agent/Team arun(stream=True) output to a
normalized event dict stream consumed by the WebSocket handler and debug printer.

Compatible with Agno 2.5.14+

Agno Event Types (from agno.run.response)
-----------------------------------------
  RunResponseStartedEvent   — agent run started
  RunResponseContentEvent   — incremental LLM text content
  ToolCallStartedEvent      — tool invocation started (has .tool with ToolExecution)
  ToolCallCompletedEvent    — tool invocation completed (has .tool with result)
  ToolCallErrorEvent        — tool invocation errored
  RunResponseCompletedEvent — agent finished the turn
  RunResponseErrorEvent     — agent raised an unhandled exception
  + others (Reasoning, Compression, Memory, etc.)

Normalized output event schema
------------------------------
Every event is a plain dict with at minimum:
    {"event_type": str, "session_id": str, ...payload}
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)

# Import Agno event types for isinstance checks (more reliable than string matching)
# Agno 2.5.14: events are in agno.run.response module
try:
    from agno.run.response import (
        ToolCallStartedEvent,
        ToolCallCompletedEvent,
        ToolCallErrorEvent,
        RunResponseContentEvent as RunContentEvent,
        RunResponseCompletedEvent as RunCompletedEvent,
        RunResponseErrorEvent as RunErrorEvent,
        RunResponseStartedEvent as RunStartedEvent,
    )
    _AGNO_EVENTS_AVAILABLE = True
except ImportError:
    # Fallback: try old import path
    try:
        from agno.run.agent import (
            ToolCallStartedEvent,
            ToolCallCompletedEvent,
            ToolCallErrorEvent,
            RunContentEvent,
            RunCompletedEvent,
            RunErrorEvent,
            RunStartedEvent,
        )
        _AGNO_EVENTS_AVAILABLE = True
    except ImportError:
        _AGNO_EVENTS_AVAILABLE = False
        logger.warning("Could not import Agno event types — falling back to string-based classification")


# ---------------------------------------------------------------------------
# Normalized event builders
# ---------------------------------------------------------------------------

def _token_event(session_id: str, content: str, model: str = "") -> dict:
    return {"event_type": "token", "session_id": session_id, "content": content, "model": model}


def _tool_start_event(session_id: str, tool_name: str, tool_call_id: str, inputs: dict) -> dict:
    return {
        "event_type": "tool_start",
        "session_id": session_id,
        "tool_name": tool_name,
        "tool_call_id": tool_call_id,
        "inputs": inputs,
    }


def _tool_end_event(session_id: str, tool_name: str, tool_call_id: str,
                     outputs: Any, elapsed_ms: float) -> dict:
    return {
        "event_type": "tool_end",
        "session_id": session_id,
        "tool_name": tool_name,
        "tool_call_id": tool_call_id,
        "outputs": outputs,
        "elapsed_ms": elapsed_ms,
    }


def _tool_error_event(session_id: str, tool_name: str, tool_call_id: str, error: str) -> dict:
    return {
        "event_type": "tool_error",
        "session_id": session_id,
        "tool_name": tool_name,
        "tool_call_id": tool_call_id,
        "error": error,
    }


def _run_complete_event(session_id: str, final_response: str) -> dict:
    return {"event_type": "run_complete", "session_id": session_id, "final_response": final_response}


def _run_error_event(session_id: str, error: str) -> dict:
    return {"event_type": "run_error", "session_id": session_id, "error": error}


def _run_started_event(session_id: str, agent_name: str) -> dict:
    return {"event_type": "run_started", "session_id": session_id, "agent_name": agent_name}


def _generic_event(session_id: str, event_name: str, content: Any = None) -> dict:
    return {"event_type": event_name, "session_id": session_id, "content": str(content) if content else ""}


# ---------------------------------------------------------------------------
# Main adapter
# ---------------------------------------------------------------------------

async def stream_agent_events(
    agent: Any,
    message: str,
    session_id: str,
) -> AsyncIterator[dict]:
    """
    Run `agent` with `message` and yield normalized event dicts.

    Uses agent.arun(stream=True) which returns an async iterable
    of Agno RunOutputEvent dataclass instances.
    """
    final_response = ""
    active_tools: dict[str, float] = {}  # tool_call_id → start_ts

    try:
        # Agent.arun with stream=True + stream_events=True returns an async generator
        # that yields ALL event types (tokens, tool calls, run lifecycle, etc.)
        # Without stream_events=True, only token content events are yielded.
        response_gen = agent.arun(message, stream=True, stream_events=True, session_id=session_id)

        # If the return is a coroutine (non-streaming path), await it first
        if asyncio.iscoroutine(response_gen):
            response_gen = await response_gen

        async for event in _iter_response(response_gen):
            normalized = _process_event(event, session_id, active_tools)
            if normalized is None:
                continue

            # Accumulate final response from token events
            if normalized["event_type"] == "token":
                final_response += normalized.get("content", "")

            yield normalized

        yield _run_complete_event(session_id, final_response)

    except Exception as exc:
        logger.exception("stream_agent_events error (session=%s)", session_id)
        yield _run_error_event(session_id, str(exc))
        raise


def _process_event(event: Any, session_id: str, active_tools: dict) -> dict | None:
    """Convert an Agno event to a normalized dict, or None to skip."""

    if _AGNO_EVENTS_AVAILABLE:
        return _process_event_typed(event, session_id, active_tools)

    # Fallback: string-based classification
    return _process_event_string(event, session_id, active_tools)


def _process_event_typed(event: Any, session_id: str, active_tools: dict) -> dict | None:
    """Process event using isinstance checks (preferred)."""

    if isinstance(event, RunContentEvent):
        content = event.content
        if content and isinstance(content, str):
            return _token_event(session_id, content)
        return None

    elif isinstance(event, ToolCallStartedEvent):
        tool_exec = event.tool
        if tool_exec is None:
            return None
        tool_name = tool_exec.tool_name or "unknown_tool"
        call_id = tool_exec.tool_call_id or ""
        inputs = tool_exec.tool_args or {}
        active_tools[call_id] = time.monotonic()
        return _tool_start_event(session_id, tool_name, call_id, inputs)

    elif isinstance(event, ToolCallCompletedEvent):
        tool_exec = event.tool
        if tool_exec is None:
            return None
        tool_name = tool_exec.tool_name or "unknown_tool"
        call_id = tool_exec.tool_call_id or ""
        result = tool_exec.result
        start_ts = active_tools.pop(call_id, time.monotonic())
        elapsed_ms = (time.monotonic() - start_ts) * 1000
        return _tool_end_event(session_id, tool_name, call_id, result, elapsed_ms)

    elif isinstance(event, ToolCallErrorEvent):
        tool_exec = event.tool
        tool_name = (tool_exec.tool_name if tool_exec else "unknown_tool") or "unknown_tool"
        call_id = (tool_exec.tool_call_id if tool_exec else "") or ""
        error_msg = str(event.content) if event.content else "unknown error"
        active_tools.pop(call_id, None)
        return _tool_error_event(session_id, tool_name, call_id, error_msg)

    elif isinstance(event, RunCompletedEvent):
        # RunCompleted carries the full final content; we already accumulate from tokens
        # but capture it here as well in case streaming missed content
        content = event.content
        if content and isinstance(content, str):
            return _token_event(session_id, content)
        return None

    elif isinstance(event, RunErrorEvent):
        error = str(event.content) if event.content else "Agent run error"
        return _run_error_event(session_id, error)

    elif isinstance(event, RunStartedEvent):
        agent_name = getattr(event, "agent_name", "")
        return _run_started_event(session_id, agent_name)

    else:
        # Log unhandled event types for debugging
        event_name = getattr(event, "event", type(event).__name__)
        logger.debug("Unhandled Agno event: %s", event_name)
        return _generic_event(session_id, str(event_name), getattr(event, "content", None))


def _process_event_string(event: Any, session_id: str, active_tools: dict) -> dict | None:
    """Fallback: classify events by the .event string field."""
    ev_str = getattr(event, "event", "")

    if ev_str == "RunContent":
        content = getattr(event, "content", "")
        if content and isinstance(content, str):
            return _token_event(session_id, content)
        return None

    elif ev_str == "ToolCallStarted":
        tool = getattr(event, "tool", None)
        if tool is None:
            return None
        tool_name = getattr(tool, "tool_name", "unknown") or "unknown"
        call_id = getattr(tool, "tool_call_id", "") or ""
        inputs = getattr(tool, "tool_args", {}) or {}
        active_tools[call_id] = time.monotonic()
        return _tool_start_event(session_id, tool_name, call_id, inputs)

    elif ev_str == "ToolCallCompleted":
        tool = getattr(event, "tool", None)
        if tool is None:
            return None
        tool_name = getattr(tool, "tool_name", "unknown") or "unknown"
        call_id = getattr(tool, "tool_call_id", "") or ""
        result = getattr(tool, "result", None)
        start_ts = active_tools.pop(call_id, time.monotonic())
        elapsed_ms = (time.monotonic() - start_ts) * 1000
        return _tool_end_event(session_id, tool_name, call_id, result, elapsed_ms)

    elif ev_str == "ToolCallError":
        tool = getattr(event, "tool", None)
        tool_name = getattr(tool, "tool_name", "unknown") if tool else "unknown"
        call_id = getattr(tool, "tool_call_id", "") if tool else ""
        error_msg = str(getattr(event, "content", "unknown error"))
        active_tools.pop(call_id, None)
        return _tool_error_event(session_id, tool_name, call_id or "", error_msg)

    elif ev_str == "RunCompleted":
        content = getattr(event, "content", "")
        if content and isinstance(content, str):
            return _token_event(session_id, content)
        return None

    elif ev_str == "RunError":
        error = str(getattr(event, "content", "Agent run error"))
        return _run_error_event(session_id, error)

    elif ev_str == "RunStarted":
        return _run_started_event(session_id, getattr(event, "agent_name", ""))

    else:
        logger.debug("Unhandled Agno event string: %s", ev_str)
        return _generic_event(session_id, ev_str, getattr(event, "content", None))


# ---------------------------------------------------------------------------
# Agno response iterator helper
# ---------------------------------------------------------------------------

async def _iter_response(response_gen: Any) -> AsyncIterator[Any]:
    """
    Normalise the Agno response: it may be an async generator or a
    plain RunOutput.  Yield each event uniformly.
    """
    # Async generator path (stream=True)
    if hasattr(response_gen, "__aiter__"):
        async for event in response_gen:
            yield event
        return

    # Sync generator path (edge case)
    if hasattr(response_gen, "__iter__") and not isinstance(response_gen, (str, bytes)):
        for event in response_gen:
            yield event
        return

    # Plain RunOutput — treat as a single terminal event
    yield response_gen