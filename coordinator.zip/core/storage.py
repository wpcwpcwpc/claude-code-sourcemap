"""
QA Agent System — Storage Factory

Returns the appropriate Agno Storage backend (SqliteDb or PostgresDb)
based on the configuration.

Compatible with Agno 2.5.14+ (uses agno.db module)
"""

from __future__ import annotations

import logging
from typing import Any

from core.config import QAAgentSettings, StorageBackend, settings

logger = logging.getLogger(__name__)


def get_storage(config: QAAgentSettings | None = None) -> Any:
    """Create an Agno storage instance based on config.

    Args:
        config: Settings override. Uses global ``settings`` if None.

    Returns:
        An Agno storage instance (SqliteDb or PostgresDb).
    """
    cfg = config or settings

    if cfg.storage_backend == StorageBackend.POSTGRES:
        try:
            # Agno 2.5.14: agno.db.postgres.PostgresDb
            from agno.db.postgres import PostgresDb
            logger.info("Using PostgreSQL storage: %s", cfg.storage_dsn[:40] + "...")
            return PostgresDb(
                db_url=cfg.storage_dsn,
                session_table="qa_agent_sessions",
            )
        except ImportError:
            logger.warning("PostgresDb not available (missing psycopg?). Falling back to SQLite.")

    # Default: SQLite
    # Agno 2.5.14: agno.db.sqlite.SqliteDb
    from agno.db.sqlite import SqliteDb
    db_path = str(cfg.sqlite_path_resolved)
    logger.info("Using SQLite storage: %s", db_path)
    return SqliteDb(
        db_file=db_path,
        session_table="qa_agent_sessions",
    )