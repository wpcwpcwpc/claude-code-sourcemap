"""
QA Agent System — Session State

Defines `QASessionState`, a dataclass mounted on Agno `RunContext.session_state`
to carry per-session runtime metadata through the Agent lifecycle.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional


@dataclass
class QASessionState:
    """Custom runtime state attached to every Agent session.

    Mounted via ``Agent(session_state=QASessionState(...))`` and accessible
    inside tools / hooks as ``agent.session_state`` or ``run_context.session_state``.
    """

    # ---- Execution tracking ----
    turn_count: int = 0
    stop_reason: Optional[str] = None  # "end_turn" | "max_turns" | "cancelled" | None
    max_turns: int = 25

    # ---- Context window management ----
    current_context_tokens: int = 0
    max_context_tokens: int = 128_000

    # ---- Permission ----
    permission_mode: str = "default"  # "default" | "plan" | "bypass"

    # ---- Agent identity ----
    agent_type: str = "normal"  # "normal" | "coordinator" | "worker"
    agent_name: str = ""
    session_id: str = ""
    worker_id: Optional[str] = None  # Set when running inside a Team

    # ---- Game context (H73-specific) ----
    game_version: str = ""
    module: str = ""  # e.g. "combat", "inventory", "quest"

    # ---- Interrupt state ----
    pending_interrupt_id: Optional[str] = None

    # ---- Compression bookkeeping ----
    compression_count: int = 0  # How many times context was compressed
    last_compression_turn: int = 0

    # ---- Task Plan (P1: structured task tracking) ----
    task_plan: Optional[Dict] = None  # Stores TaskPlan.to_dict() for persistence

    # ---- Helpers ----

    @property
    def context_usage_ratio(self) -> float:
        """Current context usage as a fraction of max."""
        if self.max_context_tokens <= 0:
            return 0.0
        return self.current_context_tokens / self.max_context_tokens

    def increment_turn(self) -> None:
        """Advance the turn counter by 1."""
        self.turn_count += 1

    def is_over_soft_threshold(self, soft: float = 0.70) -> bool:
        return self.context_usage_ratio >= soft

    def is_over_hard_threshold(self, hard: float = 0.85) -> bool:
        return self.context_usage_ratio >= hard

    def should_stop(self) -> bool:
        """Return True if the agent has exceeded max turns."""
        return self.turn_count >= self.max_turns
