"""
QA Agent System — Memory Configuration

Configures Agno MemoryManager for an Agent.

Agno v2 uses `memory_manager` parameter on Agent, not `memory`.
Memory features are also configurable via Agent constructor flags:
  - enable_user_memories
  - enable_session_summaries
  - add_memories_to_context
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from agno.memory import MemoryManager

from core.config import QAAgentSettings, settings

if TYPE_CHECKING:
    from agno.db.base import Db

logger = logging.getLogger(__name__)


def get_memory_manager(
    db: "Db | Any | None" = None,
    config: QAAgentSettings | None = None,
) -> MemoryManager:
    """Create an Agno MemoryManager instance.

    MemoryManager handles:
    - User memories: cross-session structured memory
    - Session summaries: compression of long conversations

    Args:
        db: Storage backend for persisting memories.
        config: Settings override. Uses global ``settings`` if None.

    Returns:
        Configured Agno MemoryManager instance.
    """
    cfg = config or settings

    manager = MemoryManager(
        db=db,
        # Model for memory operations (summarization, extraction)
        # Uses default model if not specified
    )

    logger.info("Agno MemoryManager configured")
    return manager


def get_memory_agent_kwargs(
    db: "Db | Any | None" = None,
    config: QAAgentSettings | None = None,
) -> dict:
    """Return Agent constructor kwargs for memory configuration.

    Instead of passing a Memory object, Agno v2 uses multiple kwargs
    on the Agent itself.

    Args:
        db: Storage backend for persisting memories.
        config: Settings override.

    Returns:
        Dict of kwargs to pass to Agent(...).
    """
    cfg = config or settings

    return {
        "memory_manager": get_memory_manager(db=db, config=cfg),
        # Enable user memory extraction
        "enable_user_memories": True,
        # Add memories to context for retrieval
        "add_memories_to_context": True,
        # Enable session summaries for long conversations
        "enable_session_summaries": True,
        "add_session_summary_to_context": True,
        # History management
        "add_history_to_context": True,
        "num_history_runs": cfg.default_max_turns,
    }