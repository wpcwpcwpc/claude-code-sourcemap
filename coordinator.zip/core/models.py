"""
QA Agent System — LLM Model Configuration

Creates Agno-compatible model instances from the centralized config.
Uses OpenAILike for compatibility with OpenAI-compatible API providers
such as 网易 AIGW, which proxies various models (Claude, GPT, etc.).

Compatible with Agno 2.5.14+
"""

from __future__ import annotations

from agno.models.openai.like import OpenAILike

from core.config import QAAgentSettings, settings


def get_model(config: QAAgentSettings | None = None) -> OpenAILike:
    """Create an Agno OpenAILike model instance from config.

    Uses OpenAILike instead of OpenAIChat because:
    - 网易 AIGW requires OpenAI-compatible but not strictly OpenAI format
    - OpenAILike skips OpenAI-specific API key validation
    - OpenAILike uses standard role_map without the 'developer' role

    Rate limit protection:
    - retries=3: Agno-level retry on model errors (including 429)
    - delay_between_retries=2: wait 2 seconds between retries
    - exponential_backoff=True: 2s → 4s → 8s increasing wait
    - max_retries=5: httpx-level retry (covers transport errors + 429)

    Args:
        config: Settings override. Uses global ``settings`` if None.

    Returns:
        Configured OpenAILike instance.
    """
    cfg = config or settings

    return OpenAILike(
        id=cfg.llm_model,
        api_key=cfg.llm_api_key or "not-provided",
        base_url=cfg.llm_base_url,
        # Rate limit protection — prevents 429 Too Many Requests
        retries=3,                      # Agno-level: retry up to 3 times on model errors
        delay_between_retries=2,        # Base delay 2 seconds between retries
        exponential_backoff=True,       # Exponential: 2s → 4s → 8s
        max_retries=5,                  # httpx-level: retry transport errors + 429
    )