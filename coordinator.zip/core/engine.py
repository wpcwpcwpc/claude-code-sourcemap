"""
QA Agent System — Agent Engine

Factory function for creating Agno Agent instances with the full
QA Agent configuration (model, tools, storage, memory, instructions, hooks).

Compatible with Agno 2.5.14+
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Callable, List, Optional

from agno.agent import Agent

from core.config import QAAgentSettings, settings
from core.instructions import NORMAL_AGENT_INSTRUCTIONS
from core.memory_setup import get_memory_agent_kwargs
from core.models import get_model
from core.prompts import PLAN_FIRST_INSTRUCTIONS, TOOL_ANTI_PATTERNS, get_task_management_section
from core.task_plan import TaskPlan
from core.session_state import QASessionState
from core.storage import get_storage

logger = logging.getLogger(__name__)


def create_normal_agent(
    config: QAAgentSettings | None = None,
    *,
    tools: Optional[List[Any]] = None,
    extra_instructions: str = "",
    session_id: Optional[str] = None,
    pre_hook: Optional[Callable] = None,
    post_hook: Optional[Callable] = None,
    agent_name: str = "QAAgent",
    permission_mode: Optional[str] = None,
    game_version: str = "",
    module: str = "",
    skills: Optional[Any] = None,
) -> Agent:
    """Create a fully configured Normal-mode Agno Agent.

    Args:
        config: Settings override. Uses global ``settings`` if None.
        tools: List of Agno tool functions. If None, uses default tool set.
        extra_instructions: Additional instructions appended to the system prompt.
        session_id: Unique session identifier. Auto-generated if None.
        pre_hook: Run-level pre_hook callable (Agno 2.5.14 format).
        post_hook: Run-level post_hook callable (Agno 2.5.14 format).
        agent_name: Human-readable agent name.
        permission_mode: Override for permission mode ("default"/"plan"/"bypass").
        game_version: H73 game version context.
        module: Game module being tested.

    Returns:
        Configured Agno Agent ready for ``agent.arun()``.
    """
    cfg = config or settings
    sid = session_id or str(uuid.uuid4())

    # Build instructions — layer Plan-First philosophy + anti-patterns + task management
    instructions = NORMAL_AGENT_INSTRUCTIONS
    instructions += f"\n\n{PLAN_FIRST_INSTRUCTIONS}"
    instructions += f"\n\n{TOOL_ANTI_PATTERNS}"
    instructions += f"\n\n{get_task_management_section()}"
    if extra_instructions:
        instructions += f"\n\n## Additional Context\n{extra_instructions}"

    # Build session state
    session_state = QASessionState(
        max_turns=cfg.default_max_turns,
        max_context_tokens=cfg.max_context_tokens,
        permission_mode=permission_mode or cfg.default_permission_mode.value,
        agent_type="normal",
        agent_name=agent_name,
        session_id=sid,
        game_version=game_version,
        module=module,
    )

    # Get storage for both agent and memory
    db = get_storage(cfg)

    # Get memory configuration kwargs (Agno 2.5.14: uses 'db' param)
    memory_kwargs = get_memory_agent_kwargs(db=db, config=cfg)

    # Build Agent kwargs (Agno 2.5.14 format)
    agent_kwargs = dict(
        name=agent_name,
        model=get_model(cfg),
        tools=tools or [],
        db=db,  # Agno 2.5.14: 'db' parameter
        instructions=instructions,
        session_state=session_state,
        session_id=sid,
        # Memory configuration (Agno 2.5.14 style)
        **memory_kwargs,
        # Markdown output for structured responses
        markdown=True,
    )

    # Hooks (Agno 2.5.14: list format - pre_hooks/post_hooks)
    if pre_hook is not None:
        agent_kwargs["pre_hooks"] = [pre_hook]
    if post_hook is not None:
        agent_kwargs["post_hooks"] = [post_hook]

    # Attach Agno Skills if provided (e.g., excel-diff-analyzer)
    if skills is not None:
        agent_kwargs["skills"] = skills

    # Create Agent
    agent = Agent(**agent_kwargs)

    skills_info = f", skills={skills.get_skill_names()}" if skills else ""
    logger.info(
        "Created Normal Agent '%s' (session=%s, permission=%s, tools=%d%s)",
        agent_name, sid, session_state.permission_mode, len(tools or []), skills_info,
    )

    return agent