"""
QA Agent System — Centralized Configuration

Uses pydantic-settings to load configuration from environment variables
and .env files. All settings have sensible defaults for local development.
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Literal, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PermissionMode(str, Enum):
    """Permission mode for L2 tool execution."""
    DEFAULT = "default"   # Normal: pause and ask user
    PLAN = "plan"         # Show execution plan, require explicit confirm
    BYPASS = "bypass"     # Skip all L2 confirmations (fully automatic)


class StorageBackend(str, Enum):
    """Supported storage backends for Agent session persistence."""
    SQLITE = "sqlite"
    POSTGRES = "postgres"


class QAAgentSettings(BaseSettings):
    """Master configuration for the QA Agent system."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ---- LLM Provider ----
    llm_base_url: str = Field(
        default="https://api.openai.com/v1",
        description="OpenAI-compatible API base URL",
    )
    llm_api_key: str = Field(
        default="",
        description="API key for the LLM provider",
    )
    llm_model: str = Field(
        default="gpt-4o",
        description="Model identifier",
    )

    # ---- Embedding ----
    embedding_model: str = Field(default="text-embedding-3-small")
    embedding_base_url: Optional[str] = Field(default=None)
    embedding_api_key: Optional[str] = Field(default=None)

    # ---- Milvus ----
    milvus_host: str = Field(default="localhost")
    milvus_port: int = Field(default=19530)
    milvus_enabled: bool = Field(default=True)

    # ---- Storage ----
    storage_backend: StorageBackend = Field(default=StorageBackend.SQLITE)
    sqlite_path: str = Field(default="./data/qa_agent.db")
    storage_dsn: str = Field(
        default="postgresql://qa_agent:qa_agent_dev@localhost:5432/qa_agent",
        description="PostgreSQL DSN (used when storage_backend=postgres)",
    )

    # ---- Context Thresholds ----
    context_soft_threshold: float = Field(
        default=0.70,
        ge=0.0,
        le=1.0,
        description="Soft compression threshold (fraction of max context)",
    )
    context_hard_threshold: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
        description="Hard compression threshold",
    )
    max_context_tokens: int = Field(
        default=128_000,
        description="Maximum context window size in tokens",
    )

    # ---- Agent Defaults ----
    default_max_turns: int = Field(default=25)
    default_permission_mode: PermissionMode = Field(default=PermissionMode.DEFAULT)

    # ---- API Server ----
    server_host: str = Field(default="0.0.0.0", alias="api_host")
    server_port: int = Field(default=8000, alias="api_port")
    api_host: str = Field(default="0.0.0.0")
    api_port: int = Field(default=8000)
    interrupt_timeout_minutes: int = Field(default=30)
    
    # ---- Logging ----
    log_level: str = Field(default="info")
    debug: bool = Field(default=False)

    # ---- Skill Directories ----
    project_skills_dir: str = Field(default=".claude/skills")
    user_skills_dir: str = Field(default="~/.qa-agent/skills")

    # ---- MCP ----
    mcp_config_path: str = Field(default=".claude/mcp.json")

    # ---- Derived helpers ----

    @property
    def sqlite_path_resolved(self) -> Path:
        """Return resolved SQLite path, creating parent dirs if needed."""
        p = Path(self.sqlite_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def embedding_api_key_resolved(self) -> str:
        """Fall back to llm_api_key if embedding-specific key is not set."""
        return self.embedding_api_key or self.llm_api_key

    @property
    def embedding_base_url_resolved(self) -> str:
        """Fall back to llm_base_url if embedding-specific URL is not set."""
        return self.embedding_base_url or self.llm_base_url


# Singleton — import `settings` anywhere to get the loaded config.
settings = QAAgentSettings()
