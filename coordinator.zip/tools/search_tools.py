"""
QA Agent System — Search Tools

Provides grep (L1) for regex-based file content search with path filtering.

Compatible with Agno 2.5.14+
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Optional

from agno.tools import tool

logger = logging.getLogger(__name__)

# Maximum number of matches to return
MAX_MATCHES = 50


@tool(
    name="grep",
    description=(
        "Search for a regex pattern across files in a directory. "
        "Returns matching lines with file paths and line numbers. "
        "Supports file type filtering via glob patterns."
    ),
)
def grep(
    pattern: str,
    path: str = ".",
    file_pattern: Optional[str] = None,
    case_sensitive: bool = False,
) -> str:
    """Search for a regex pattern in files.

    Args:
        pattern: Regular expression pattern to search for.
        path: Directory to search in (recursively). Default is current directory.
        file_pattern: Optional glob pattern to filter files (e.g. "*.py", "*.ts").
        case_sensitive: Whether the search is case-sensitive. Default False.

    Returns:
        Matching lines with file:line format, capped at 50 matches.
    """
    try:
        flags = 0 if case_sensitive else re.IGNORECASE
        compiled = re.compile(pattern, flags)
    except re.error as e:
        return f"Error: Invalid regex pattern: {e}"

    base = Path(path).resolve()
    if not base.exists():
        return f"Error: Directory not found: {path}"
    if not base.is_dir():
        return f"Error: Not a directory: {path}"

    # Collect files to search
    if file_pattern:
        files = sorted(base.rglob(file_pattern))
    else:
        files = sorted(f for f in base.rglob("*") if f.is_file())

    # Skip binary / very large files
    skip_extensions = {
        ".pyc", ".pyo", ".exe", ".dll", ".so", ".dylib",
        ".zip", ".tar", ".gz", ".bz2", ".7z", ".rar",
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp",
        ".mp3", ".mp4", ".avi", ".mkv", ".wav",
        ".db", ".sqlite", ".sqlite3",
        ".woff", ".woff2", ".ttf", ".eot",
    }
    max_file_size = 1_000_000  # 1 MB

    matches = []
    files_searched = 0

    for fpath in files:
        if fpath.suffix.lower() in skip_extensions:
            continue
        try:
            size = fpath.stat().st_size
        except OSError:
            continue
        if size > max_file_size or size == 0:
            continue

        files_searched += 1

        try:
            text = fpath.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        for line_no, line in enumerate(text.splitlines(), start=1):
            if compiled.search(line):
                rel = fpath.relative_to(base)
                # Truncate long lines
                display_line = line.strip()
                if len(display_line) > 200:
                    display_line = display_line[:200] + "..."
                matches.append(f"{rel}:{line_no}: {display_line}")

                if len(matches) >= MAX_MATCHES:
                    matches.append(f"\n[Results capped at {MAX_MATCHES} matches. Searched {files_searched} files.]")
                    return "\n".join(matches)

    if not matches:
        return f"No matches found for pattern '{pattern}' in {files_searched} files."

    result = "\n".join(matches)
    result += f"\n\n[Found {len(matches)} matches in {files_searched} files.]"
    return result
