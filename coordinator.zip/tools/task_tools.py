"""
QA Agent System — Task Management Tools

Provides task_list and task_update tools for structured task tracking.
Agent uses these to create, view, and progress through a TaskPlan.

The TaskPlan is persisted in agent.session_state.task_plan (Dict).
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from agno.tools import tool

from core.task_plan import TERMINAL_STATUSES, TaskPlan

logger = logging.getLogger(__name__)

# Valid statuses for task_update
VALID_UPDATE_STATUSES = {"create", "done", "failed", "skipped", "active"}

# Guide shown when no plan exists
NO_PLAN_GUIDE = (
    "No task plan yet. Create one by calling:\n\n"
    '  task_update(task_id=0, status="create", summary=\'{'
    '"goal": "your goal here", '
    '"strategy": "your approach here", '
    '"tasks": ["step 1", "step 2", "step 3"]'
    "}')\n\n"
    "Tips:\n"
    "- goal: What you want to achieve (1 sentence)\n"
    "- strategy: How you plan to achieve it (1-2 sentences)\n"
    "- tasks: Ordered list of 3-10 concrete steps\n"
)

# JSON format example shown on parse error
CREATE_JSON_EXAMPLE = (
    'Expected JSON format in summary:\n'
    '{\n'
    '  "goal": "Verify combat damage calculation",\n'
    '  "strategy": "Read config tables, write test script, execute via Hunter",\n'
    '  "tasks": [\n'
    '    "Read combat config tables to find damage formula",\n'
    '    "Write verification script for damage calculation",\n'
    '    "Execute test via Hunter and collect results",\n'
    '    "Analyze results and generate report"\n'
    '  ]\n'
    '}'
)


def _get_task_plan(agent) -> Optional[TaskPlan]:
    """Load TaskPlan from agent session_state, or None."""
    state = getattr(agent, "session_state", None)
    if state is None:
        return None
    plan_dict = getattr(state, "task_plan", None)
    if plan_dict is None:
        return None
    try:
        return TaskPlan.from_dict(plan_dict)
    except Exception as e:
        logger.warning("Failed to deserialize task_plan: %s", e)
        return None


def _save_task_plan(agent, plan: TaskPlan) -> None:
    """Save TaskPlan to agent session_state."""
    state = getattr(agent, "session_state", None)
    if state is None:
        logger.warning("Cannot save task_plan: agent has no session_state")
        return
    state.task_plan = plan.to_dict()


# ═══════════════════════════════════════════════════════════════════
# task_list — Read-only view of current plan
# ═══════════════════════════════════════════════════════════════════


@tool(
    name="task_list",
    description=(
        "View the current task plan and progress. "
        "Shows all tasks with their status (pending/active/done/failed/skipped). "
        "If no plan exists, shows instructions for creating one."
    ),
)
def task_list(agent) -> str:
    """Return the current TaskPlan status summary.

    Returns:
        Text summary of the plan, or creation guide if none exists.
    """
    plan = _get_task_plan(agent)

    if plan is None:
        return NO_PLAN_GUIDE

    return plan.to_summary()


# ═══════════════════════════════════════════════════════════════════
# task_update — Create plan or update task status
# ═══════════════════════════════════════════════════════════════════


@tool(
    name="task_update",
    description=(
        "Create a task plan or update a task's status. "
        "To create a plan: task_update(task_id=0, status='create', summary='{JSON plan}'). "
        "To complete a task: task_update(task_id=N, status='done', summary='result'). "
        "Valid statuses: create (with task_id=0), done, failed, skipped, active."
    ),
)
def task_update(
    agent,
    task_id: int,
    status: str,
    summary: str = "",
) -> str:
    """Create a plan or update a task's status.

    Args:
        task_id: Task ID to update. Use 0 with status='create' to create a new plan.
        status: New status: 'create', 'done', 'failed', 'skipped', or 'active'.
        summary: For 'create': JSON string with plan definition.
                 For others: brief result summary.

    Returns:
        Confirmation message with updated plan status.
    """
    # ── Validate status ─────────────────────────────────────────────
    if status not in VALID_UPDATE_STATUSES:
        return (
            f"Invalid status '{status}'. "
            f"Valid values: {', '.join(sorted(VALID_UPDATE_STATUSES))}."
        )

    # ── CREATE mode ─────────────────────────────────────────────────
    if task_id == 0 and status == "create":
        return _handle_create(agent, summary)

    # ── UPDATE mode — need existing plan ────────────────────────────
    if status == "create":
        return "To create a plan, use task_id=0 with status='create'."

    plan = _get_task_plan(agent)
    if plan is None:
        return (
            "No task plan exists yet. Create one first:\n"
            '  task_update(task_id=0, status="create", summary=\'{"goal": "...", ...}\')'
        )

    # ── Validate task_id ────────────────────────────────────────────
    try:
        task = plan._get_task(task_id)
    except KeyError:
        valid_ids = [str(t.id) for t in plan.tasks]
        return (
            f"Task ID {task_id} not found. "
            f"Use task_list() to see available tasks. "
            f"Valid IDs: {', '.join(valid_ids)}."
        )

    # ── Update the task ─────────────────────────────────────────────
    plan.mark_task(task_id, status, summary)  # type: ignore[arg-type]
    _save_task_plan(agent, plan)

    # ── Build response ──────────────────────────────────────────────
    done_count, total = plan.progress
    response_lines = [
        f"✓ Task {task_id} marked as {status}.",
    ]
    if summary:
        response_lines.append(f"  Summary: {summary}")

    response_lines.append(f"  Progress: {done_count}/{total} tasks complete.")

    if plan.is_complete:
        response_lines.append(
            "\n🎉 All tasks complete! Generate your final summary/report now."
        )
    elif plan.active_task:
        response_lines.append(
            f"\n▶ Next: Task {plan.active_task.id} — {plan.active_task.description}"
        )

    return "\n".join(response_lines)


def _handle_create(agent, summary: str) -> str:
    """Handle task_update(task_id=0, status='create', summary=JSON)."""
    # Check if plan already exists
    existing = _get_task_plan(agent)
    if existing is not None and not existing.is_complete:
        done_count, total = existing.progress
        return (
            f"A task plan already exists ({done_count}/{total} tasks complete). "
            "Complete or skip remaining tasks before creating a new plan. "
            "Use task_list() to see current status."
        )

    # Parse the JSON summary
    if not summary.strip():
        return f"summary parameter is required when creating a plan.\n\n{CREATE_JSON_EXAMPLE}"

    try:
        plan_data = json.loads(summary)
    except json.JSONDecodeError as e:
        return (
            f"Failed to parse plan JSON: {e}\n\n"
            f"{CREATE_JSON_EXAMPLE}"
        )

    # Validate and create TaskPlan
    try:
        plan = TaskPlan.from_create_json(plan_data)
    except (ValueError, KeyError) as e:
        return f"Invalid plan data: {e}\n\n{CREATE_JSON_EXAMPLE}"

    # Validate task count (3-10 recommended)
    if len(plan.tasks) < 2:
        return (
            f"Plan has only {len(plan.tasks)} task(s). "
            "A good plan should have 3-10 concrete steps. "
            "Please provide more detailed steps."
        )
    if len(plan.tasks) > 15:
        return (
            f"Plan has {len(plan.tasks)} tasks — too many. "
            "Consolidate into 3-10 high-level steps. "
            "You can break them down further during execution."
        )

    # Save
    _save_task_plan(agent, plan)

    logger.info(
        "Created task plan: goal='%s', tasks=%d (session=%s)",
        plan.goal, len(plan.tasks),
        getattr(getattr(agent, "session_state", None), "session_id", "?"),
    )

    response = [
        "✅ Task plan created!",
        f"  Goal: {plan.goal}",
        f"  Strategy: {plan.strategy}",
        f"  Tasks: {len(plan.tasks)}",
        "",
    ]

    for task in plan.tasks:
        marker = "▶️" if task.status == "active" else "⬜"
        response.append(f"  {marker} [{task.id}] {task.description}")

    response.append(
        f"\n▶ Starting with Task {plan.active_task.id}: {plan.active_task.description}"
        if plan.active_task else ""
    )

    return "\n".join(response)
