"""
QA Agent System — Hunter Execute Tool (L2)

Integrates with the Hunter2 platform to execute Python scripts
on remote devices. All executions require L2 human confirmation.

If the Hunter2 SDK is not installed, the tool degrades gracefully
and returns a clear error message.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

from agno.tools import tool

from hooks.permission_hook import l2_pre_hook

logger = logging.getLogger(__name__)

# Default timeout for Hunter2 script execution (seconds)
HUNTER_TIMEOUT = 120


@tool(
    name="hunter_execute",
    description=(
        "Execute a Python script on a remote device via Hunter2 platform. "
        "Shows script preview and requires human confirmation (L2 permission) before execution. "
        "Use for running automated QA test cases, GM command scripts, or device initialization."
    ),
)
async def hunter_execute(
    script: str,
    device_ip: str = "",
    token_id: str = "",
    group_name: str = "",
    timeout: int = HUNTER_TIMEOUT,
) -> str:
    """Execute a Python script on a remote device via Hunter2.

    Args:
        script: Python script content or path to execute.
        device_ip: Target device IP address. Uses default from config if empty.
        token_id: Hunter2 authentication token. Uses config default if empty.
        group_name: Hunter2 group name. Uses config default if empty.
        timeout: Execution timeout in seconds. Default 120.

    Returns:
        Script execution output, or error message.
    """
    from core.config import settings

    # Resolve defaults from env/config
    resolved_ip = device_ip or getattr(settings, "hunter_device_ip", "")
    resolved_token = token_id or getattr(settings, "hunter_token_id", "")
    resolved_group = group_name or getattr(settings, "hunter_group_name", "")

    # Attempt Hunter2 SDK execution
    try:
        result = await _execute_via_hunter2(
            script=script,
            device_ip=resolved_ip,
            token_id=resolved_token,
            group_name=resolved_group,
            timeout=timeout,
        )
        return result

    except HunterNotInstalledError:
        return (
            "Error: Hunter2 SDK is not installed. "
            "Please install it with: pip install hunter2-sdk\n"
            "Or contact the platform team for access."
        )
    except HunterConnectionError as e:
        return f"Error: Failed to connect to Hunter2 (device={resolved_ip}): {e}"
    except HunterTimeoutError:
        return f"Error: Script execution timed out after {timeout} seconds."
    except Exception as e:
        logger.exception("hunter_execute unexpected error")
        return f"Error: Unexpected Hunter2 execution error: {e}"


# ---------------------------------------------------------------------------
# Hunter2 SDK wrapper
# ---------------------------------------------------------------------------

class HunterNotInstalledError(Exception):
    pass


class HunterConnectionError(Exception):
    pass


class HunterTimeoutError(Exception):
    pass


async def _execute_via_hunter2(
    script: str,
    device_ip: str,
    token_id: str,
    group_name: str,
    timeout: int,
) -> str:
    """Call Hunter2 SDK in a thread executor (SDK may be synchronous)."""

    def _sync_execute() -> str:
        try:
            # Dynamic import: Hunter2 SDK may not be installed
            import importlib
            hunter_mod = importlib.import_module("hunter2")
        except ImportError:
            raise HunterNotInstalledError("hunter2 package not found")

        try:
            # Hunter2 SDK API (based on the qa-debug-automation skill pattern)
            client = hunter_mod.Client(
                token_id=token_id,
                group_name=group_name,
            )

            if device_ip:
                client.connect(device_ip)

            result = client.execute(script, timeout=timeout)
            return str(result)

        except hunter_mod.ConnectionError as e:
            raise HunterConnectionError(str(e))
        except hunter_mod.TimeoutError:
            raise HunterTimeoutError()
        except Exception as e:
            return f"Hunter2 execution result: {e}"

    # Run synchronous SDK in thread pool to avoid blocking event loop
    loop = asyncio.get_event_loop()
    try:
        result = await asyncio.wait_for(
            loop.run_in_executor(None, _sync_execute),
            timeout=timeout + 5,  # extra buffer for thread overhead
        )
        return result
    except asyncio.TimeoutError:
        raise HunterTimeoutError()
