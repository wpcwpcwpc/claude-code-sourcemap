"""
QA Agent System — Agent Spawn Tool (L1)

Allows an agent to spawn a sub-agent by name and delegate a task to it.
Used by Coordinator to dynamically create workers.
"""

from __future__ import annotations

import logging

from agno.tools import tool

logger = logging.getLogger(__name__)


@tool(
    name="agent_spawn",
    description=(
        "Spawn a sub-agent by name and execute a task with it. "
        "Use to delegate specialized work to a dedicated agent. "
        "Available agents: ExploreAgent, QAAutomationAgent, ConfigAnalyzerAgent, "
        "or any custom agent defined in .claude/agents/."
    ),
)
async def agent_spawn(agent_name: str, task: str, game_version: str = "", module: str = "") -> str:
    """Spawn a named agent and run a task.

    Args:
        agent_name: Name of the agent to spawn (from registry).
        task: Task description / message to run.
        game_version: Optional game version for context injection.
        module: Optional game module for context injection.

    Returns:
        The agent's response text, or an error message.
    """
    from agents.base import create_agent_from_definition
    from agents.registry import agent_registry

    definition = agent_registry.get(agent_name)
    if definition is None:
        available = ", ".join(agent_registry._definitions.keys())
        return (
            f"Error: Agent '{agent_name}' not found in registry. "
            f"Available: {available}"
        )

    logger.info("Spawning agent '%s' for task: %s", agent_name, task[:80])

    try:
        agent = await create_agent_from_definition(
            definition,
            task_description=task,
            game_version=game_version,
            module=module,
        )

        response = await agent.arun(task)

        result = ""
        if hasattr(response, "content") and response.content:
            result = str(response.content)
        else:
            result = str(response)

        logger.info(
            "Agent '%s' completed task (response_len=%d)", agent_name, len(result)
        )
        return result

    except Exception as e:
        logger.exception("Agent '%s' failed for task: %s", agent_name, task[:80])
        return f"Error: Agent '{agent_name}' failed: {e}"
