"""
QA Agent System — File Tools (v2: search/replace + validateInput)

Provides file_read (L1), file_edit (L2), and glob_search (L1) tools.

file_edit uses search/replace mode (not full overwrite) with a
multi-step validation chain inspired by Claude Code's FileEditTool.

Compatible with Agno 2.5.14+

References:
  - docs/07-核心工具实现.md §3 (FileEditTool)
  - Claude Code validateInput chain (10 steps)
"""

from __future__ import annotations

import glob as glob_mod
import hashlib
import logging
import os
from pathlib import Path
from typing import Optional

from agno.tools import tool

from .file_state_cache import get_file_state_cache

logger = logging.getLogger(__name__)

# Maximum bytes to return from a single file read
MAX_RESULT_SIZE = 100 * 1024  # 100 KB


# ═══════════════════════════════════════════════════════════════════════
# file_read  (L1, read-only)
# ═══════════════════════════════════════════════════════════════════════

@tool(
    name="file_read",
    description=(
        "Read a file's content with line numbers. "
        "Use offset and limit to read specific sections of large files. "
        "ALWAYS read a file before editing it."
    ),
)
def file_read(path: str, offset: int = 0, limit: int = 500) -> str:
    """Read a file and return its content with line numbers.

    Args:
        path: Relative or absolute path to the file.
        offset: Line number to start reading from (0-based). Default 0.
        limit: Maximum number of lines to return. Default 500.

    Returns:
        File content with line numbers, or an error message.
    """
    try:
        p = Path(path).resolve()
        if not p.exists():
            return f"Error: File not found: {path}"
        if not p.is_file():
            return f"Error: Not a file: {path}"

        raw = p.read_bytes()

        # Record read in state cache (raw bytes for accurate hash)
        text_full = raw.decode("utf-8", errors="replace")
        lines_all = text_full.splitlines()
        total_lines = len(lines_all)

        cache = get_file_state_cache()
        cache.record_read(
            str(p), raw,
            offset=offset, limit=limit, total_lines=total_lines,
        )

        if len(raw) > MAX_RESULT_SIZE:
            text = raw[:MAX_RESULT_SIZE].decode("utf-8", errors="replace")
            truncated = True
        else:
            text = text_full
            truncated = False

        lines = text.splitlines()
        selected = lines[offset: offset + limit]

        numbered = []
        for i, line in enumerate(selected, start=offset + 1):
            numbered.append(f"{i:>6}\t{line}")

        result = "\n".join(numbered)
        if truncated:
            result += f"\n\n[File truncated at {MAX_RESULT_SIZE // 1024}KB. Total size: {len(raw)} bytes]"
        if offset + limit < total_lines:
            result += f"\n\n[Showing lines {offset + 1}-{offset + len(selected)} of {total_lines}. Use offset/limit to read more.]"

        return result

    except Exception as e:
        logger.exception("file_read failed for %s", path)
        return f"Error reading file: {e}"


# ═══════════════════════════════════════════════════════════════════════
# file_edit  (L2, search/replace mode + validateInput)
# ═══════════════════════════════════════════════════════════════════════

def _validate_file_edit(
    file_path: str,
    old_string: str,
    new_string: str,
    replace_all: bool,
) -> Optional[str]:
    """Multi-step validation chain for file_edit.

    Returns None if valid, or a guidance error string if invalid.
    The error string is designed as a "retry prompt" for the LLM.
    """
    p = Path(file_path).resolve()
    abs_path = str(p)

    # Step 1: No-op detection
    if old_string == new_string:
        return (
            "No changes to make: old_string and new_string are identical. "
            "If you intended a different edit, double-check both values."
        )

    # Step 2: Create-new-file mode (old_string == "")
    if old_string == "":
        # Empty old_string → create or append
        if p.exists():
            return (
                f"File already exists: {file_path}. "
                "To edit an existing file, provide the exact old_string to replace. "
                "Use file_read to see the current content first."
            )
        return None  # OK to create

    # Step 3: File existence check
    if not p.exists():
        return (
            f"File not found: {file_path}. "
            "To create a new file, use old_string='' (empty string). "
            "If editing an existing file, check the file path with glob_search."
        )

    if not p.is_file():
        return f"Not a regular file: {file_path}"

    # Step 4: Read-before-write check
    cache = get_file_state_cache()
    record = cache.get_record(abs_path)
    if record is None:
        return (
            f"You must read the file before editing it. "
            f"Use file_read(path='{file_path}') first, then retry the edit. "
            f"This ensures you have the latest content and avoids stale edits."
        )

    # Step 5: External modification detection
    if cache.is_stale(abs_path):
        return (
            f"File has been modified since you last read it. "
            f"Read it again with file_read(path='{file_path}') before editing. "
            f"This prevents overwriting changes made by other processes."
        )

    # Step 6: Partial-read warning
    if record.is_partial:
        # Warning but don't block — the LLM might be editing within the read range
        logger.warning(
            "[file_edit] Editing %s after partial read (offset=%d, limit=%d). "
            "old_string may not be within the read range.",
            file_path, record.offset, record.limit,
        )

    # Step 7: Read file content for match checking
    try:
        content = p.read_text(encoding="utf-8")
    except Exception as e:
        return f"Error reading file for validation: {e}"

    # Step 8: old_string existence check
    if old_string not in content:
        # Try with normalized whitespace (common LLM mistake)
        normalized_old = " ".join(old_string.split())
        normalized_content = " ".join(content.split())
        if normalized_old in normalized_content:
            return (
                f"The old_string was not found with exact whitespace matching, "
                f"but a similar string exists in the file. "
                f"Make sure old_string matches exactly, including indentation and line breaks. "
                f"Re-read the file with file_read to get the exact content."
            )
        return (
            f"The old_string was not found in {file_path}. "
            f"Make sure it matches the file content exactly, "
            f"including whitespace and indentation. "
            f"Re-read the file with file_read(path='{file_path}') to verify."
        )

    # Step 9: Multiple match check
    match_count = content.count(old_string)
    if match_count > 1 and not replace_all:
        return (
            f"Found {match_count} matches for old_string in {file_path}. "
            f"Include more surrounding context lines to make it unique, "
            f"or set replace_all=True to replace all occurrences."
        )

    return None  # All checks passed


@tool(
    name="file_edit",
    description=(
        "Edit a file using search/replace. Provide old_string (exact text to find) "
        "and new_string (replacement text). To create a new file, use old_string='' "
        "with new_string containing the file content. "
        "You MUST read the file with file_read before editing it."
    ),
)
def file_edit(
    file_path: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
) -> str:
    """Edit a file by replacing old_string with new_string.

    Args:
        file_path: Path to the file to edit.
        old_string: Exact text to find and replace. Empty string = create new file.
        new_string: Text to replace old_string with.
        replace_all: If True, replace all occurrences. Default False (single match required).

    Returns:
        Success message with line change count, or validation error guidance.
    """
    # ── Validation chain ────────────────────────────────────────────────
    error = _validate_file_edit(file_path, old_string, new_string, replace_all)
    if error:
        return f"Validation error: {error}"

    # ── Execute edit ────────────────────────────────────────────────────
    try:
        p = Path(file_path).resolve()

        # Create new file mode
        if old_string == "":
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(new_string, encoding="utf-8")

            # Update state cache for the new file
            cache = get_file_state_cache()
            cache.record_read(str(p), new_string.encode("utf-8"))

            lines = new_string.count("\n") + (1 if new_string and not new_string.endswith("\n") else 0)
            return f"Created new file {file_path} ({lines} lines)"

        # Search/replace mode
        content = p.read_text(encoding="utf-8")

        if replace_all:
            count = content.count(old_string)
            updated = content.replace(old_string, new_string)
        else:
            count = 1
            updated = content.replace(old_string, new_string, 1)

        # Atomic-ish write
        p.write_text(updated, encoding="utf-8")

        # Update state cache with new content
        cache = get_file_state_cache()
        cache.record_read(str(p), updated.encode("utf-8"))

        # Count changed lines for feedback
        old_lines = old_string.count("\n") + 1
        new_lines = new_string.count("\n") + 1
        delta = new_lines - old_lines

        if count == 1:
            return (
                f"Successfully edited {file_path}: "
                f"replaced {old_lines} line(s) with {new_lines} line(s) "
                f"(net {delta:+d})"
            )
        else:
            return (
                f"Successfully edited {file_path}: "
                f"replaced {count} occurrences "
                f"({old_lines}→{new_lines} lines each, net {delta * count:+d})"
            )

    except Exception as e:
        logger.exception("file_edit failed for %s", file_path)
        return f"Error editing file: {e}"


# ═══════════════════════════════════════════════════════════════════════
# glob_search  (L1, read-only)
# ═══════════════════════════════════════════════════════════════════════

@tool(
    name="glob_search",
    description=(
        "Find files matching a glob pattern. "
        "Use this instead of bash 'find' or 'ls' commands. "
        "Returns a list of matching file paths (max 200 results)."
    ),
)
def glob_search(pattern: str, base_dir: str = ".") -> str:
    """Search for files matching a glob pattern.

    Args:
        pattern: Glob pattern (e.g. "**/*.py", "src/**/*.ts").
        base_dir: Base directory for the search. Default is current directory.

    Returns:
        Newline-separated list of matching file paths (max 200 results).
    """
    try:
        base = Path(base_dir).resolve()
        matches = sorted(base.glob(pattern))

        # Cap results
        max_results = 200
        if len(matches) > max_results:
            paths = [str(m.relative_to(base)) for m in matches[:max_results]]
            paths.append(f"\n... and {len(matches) - max_results} more files")
        else:
            paths = [str(m.relative_to(base)) for m in matches]

        if not paths:
            return f"No files found matching pattern: {pattern}"

        return "\n".join(paths)

    except Exception as e:
        logger.exception("glob_search failed for pattern %s", pattern)
        return f"Error in glob search: {e}"