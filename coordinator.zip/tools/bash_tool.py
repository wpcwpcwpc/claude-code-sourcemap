"""
QA Agent System — Bash Tool (v3: full classifier + auto-bg + guided errors)

Intelligent bash/shell execution with:
- 6-category command classification (via bash_classifier)
- Pipeline-aware read-only detection
- Tiered timeouts: SILENT→2s, SEARCH/READ/LIST→15s, WRITE→30s
- Auto-backgrounding after BLOCKING_BUDGET_MS (15s)
- sed -i interception → guides user to file_edit
- Guided error messages (errors as retry prompts for LLM)
- Known exit code semantics (grep:1=no match, diff:1=has diff)

Compatible with Agno 2.5.14+

References:
  - Claude Code BashTool (docs/07-核心工具实现.md §2)
  - StreamingToolExecutor auto-background (docs/06-工具系统架构.md)
"""

from __future__ import annotations

import logging
import re
import subprocess
import sys
from typing import Optional

from agno.tools import tool

from .bash_classifier import (
    CommandCategory,
    classify_command,
    is_read_only_command,
    detect_sed_inplace,
    SILENT_COMMANDS,
)
from .background_tasks import BackgroundTaskManager

logger = logging.getLogger(__name__)


# ── Tiered Timeouts (seconds) ──────────────────────────────────────────
TIMEOUT_SILENT = 2         # SILENT commands: mkdir, cp, mv
TIMEOUT_READ = 15          # SEARCH/READ/LIST: grep, cat, ls
TIMEOUT_WRITE = 30         # WRITE (default): python, npm, pip
TIMEOUT_BACKGROUND = 120   # Background tasks max lifetime

# Auto-background threshold
BLOCKING_BUDGET_S = 15     # Commands exceeding this get auto-backgrounded

_CATEGORY_TIMEOUT = {
    CommandCategory.SEARCH:  TIMEOUT_READ,
    CommandCategory.READ:    TIMEOUT_READ,
    CommandCategory.LIST:    TIMEOUT_READ,
    CommandCategory.NEUTRAL: TIMEOUT_READ,
    CommandCategory.SILENT:  TIMEOUT_SILENT,
    CommandCategory.WRITE:   TIMEOUT_WRITE,
}


# ── Safety Blacklist ────────────────────────────────────────────────────
COMMAND_BLACKLIST = [
    r"\brm\s+(-rf?|--recursive)\s+/\s*$",   # rm -rf /
    r"\brmdir\s+/\s*$",
    r"\bmkfs\b",
    r"\bdd\s+.*of=/dev/",
    r"\bformat\s+[a-z]:",                     # Windows format
    r":\(\)\{\s*:\|:&\s*\};:",                # Fork bomb
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bhalt\b",
    r"\binit\s+0\b",
]
_BLACKLIST_COMPILED = [re.compile(p, re.IGNORECASE) for p in COMMAND_BLACKLIST]


# ── Known Exit Code Semantics ──────────────────────────────────────────
# {base_command: {exit_code: (meaning, is_real_error)}}
KNOWN_EXIT_CODES = {
    "grep": {1: ("No matches found", False), 2: ("Syntax error in pattern", True)},
    "rg":   {1: ("No matches found", False), 2: ("Error occurred", True)},
    "ag":   {1: ("No matches found", False)},
    "diff": {1: ("Files differ", False), 2: ("Error", True)},
    "test": {1: ("Condition is false", False)},
    "[":    {1: ("Condition is false", False)},
    "cmp":  {1: ("Files differ", False), 2: ("Error", True)},
}


# Singleton background task manager
_bg_manager = BackgroundTaskManager(default_timeout=TIMEOUT_BACKGROUND)


# ── Internal helpers ────────────────────────────────────────────────────

def _is_command_blocked(command: str) -> Optional[str]:
    for pattern in _BLACKLIST_COMPILED:
        if pattern.search(command):
            return pattern.pattern
    return None


def _effective_timeout(category: CommandCategory, user_timeout: Optional[int]) -> int:
    if user_timeout is not None:
        return user_timeout
    return _CATEGORY_TIMEOUT.get(category, TIMEOUT_WRITE)


def _extract_base_cmd(command: str) -> str:
    """Extract base command name for exit code lookup."""
    parts = command.strip().split()
    if not parts:
        return ""
    cmd = parts[0]
    # Strip path
    if "/" in cmd:
        cmd = cmd.rsplit("/", 1)[-1]
    if "\\" in cmd:
        cmd = cmd.rsplit("\\", 1)[-1]
    if cmd.endswith(".exe"):
        cmd = cmd[:-4]
    return cmd.lower()


def _format_exit_code_info(command: str, exit_code: int) -> str:
    """Return helpful info about known exit codes, or empty string."""
    base = _extract_base_cmd(command)
    known = KNOWN_EXIT_CODES.get(base, {}).get(exit_code)
    if known:
        meaning, is_error = known
        if not is_error:
            return f" (Note: Exit code {exit_code} for '{base}' means: {meaning} — this is not an error)"
    return ""


def _format_timeout_error(
    command: str,
    category: CommandCategory,
    timeout_s: int,
    readonly: bool,
) -> str:
    """Build a guided timeout error message."""
    parts = [f"Error: Command timed out after {timeout_s} seconds."]
    parts.append(f"Command category: {category.name}")

    if readonly:
        parts.append(
            "Hint: This is a read-only command. The search may be too broad — "
            "try narrowing the pattern, path, or adding filters."
        )
    elif _bg_manager.can_auto_background(command):
        parts.append(
            "Hint: Consider re-running with run_in_background=True for long-running commands."
        )

    return "\n".join(parts)


def _format_not_found_error(command: str) -> str:
    base = _extract_base_cmd(command)
    return (
        f"Error: Command '{base}' not found. "
        f"Check that it is installed and available in PATH. "
        f"On this system ({sys.platform}), try: "
        f"'which {base}' (Linux/Mac) or 'where {base}' (Windows)."
    )


# ── Main Tool ───────────────────────────────────────────────────────────

@tool(
    name="bash",
    description=(
        "Execute a shell command. Commands are auto-classified with intelligent "
        "timeout tiers. Provide 'description' to explain your intent. "
        "Use run_in_background=true for long-running commands. "
        "Dangerous commands are blocked. "
        "IMPORTANT: Use dedicated tools (file_read, file_edit, grep, glob_search) "
        "instead of bash equivalents (cat, sed, grep, find)."
    ),
)
def bash(
    command: str,
    timeout: Optional[int] = None,
    cwd: Optional[str] = None,
    description: str = "",
    run_in_background: bool = False,
) -> str:
    """Execute a shell command with intelligent classification and timeouts.

    Args:
        command: The shell command to execute.
        timeout: Override timeout in seconds. If omitted, auto-determined.
        cwd: Working directory. Default is current directory.
        description: Human-readable intent (used for logging and HIL display).
        run_in_background: If True, run in background and return task ID.

    Returns:
        Command output, error guidance, or background task ID.
    """
    if not command or not command.strip():
        return "Error: Empty command. Provide a valid shell command to execute."

    desc_display = description or command[:80]

    # ── Step 1: Blacklist check ─────────────────────────────────────────
    blocked = _is_command_blocked(command)
    if blocked:
        return (
            f"Error: Command blocked by safety policy.\n"
            f"Matched pattern: {blocked}\n"
            f"This command could cause irreversible damage to the system."
        )

    # ── Step 2: sed -i interception ─────────────────────────────────────
    sed_result = detect_sed_inplace(command)
    if sed_result is not None:
        file_path, old_pat, new_pat = sed_result
        return (
            f"Instead of sed -i, use the file_edit tool for safer editing:\n\n"
            f"  file_edit(\n"
            f"    file_path='{file_path}',\n"
            f"    old_string='{old_pat}',\n"
            f"    new_string='{new_pat}',\n"
            f"    replace_all=True\n"
            f"  )\n\n"
            f"file_edit provides validation (read-before-write check, "
            f"exact match verification) and keeps the edit history."
        )

    # ── Step 3: Classify command ────────────────────────────────────────
    category = classify_command(command)
    readonly = is_read_only_command(command)
    effective_to = _effective_timeout(category, timeout)

    logger.info(
        "[bash] category=%s readonly=%s timeout=%ds bg=%s | %s%s",
        category.name, readonly, effective_to, run_in_background,
        command[:120],
        f" | {description}" if description else "",
    )

    # ── Step 4: Background execution path ───────────────────────────────
    if run_in_background:
        task_id = _bg_manager.start_task(
            command=command,
            cwd=cwd,
            timeout=TIMEOUT_BACKGROUND,
            description=desc_display,
        )
        return (
            f"Command started in background.\n"
            f"Task ID: {task_id}\n"
            f"Category: {category.name}\n"
            f"Use bash(command='bg_status {task_id}') to check progress."
        )

    # ── Step 4b: Background task status query ───────────────────────────
    if command.strip().startswith("bg_status "):
        task_id = command.strip().split(maxsplit=1)[1]
        status = _bg_manager.get_status(task_id)
        if status is None:
            return f"Error: No background task found with ID '{task_id}'."
        return (
            f"Task: {status['task_id']}\n"
            f"Status: {status['status']}\n"
            f"Elapsed: {status['elapsed_s']:.1f}s\n"
            f"Exit code: {status['exit_code']}\n"
            f"Output:\n{status.get('output', '(still running)')}"
        )

    # ── Step 5: Synchronous execution with tiered timeout ───────────────
    try:
        if sys.platform == "win32":
            # Use PowerShell instead of CMD for better compatibility:
            # - PowerShell supports both single and double quotes
            # - PowerShell handles nested quotes similar to bash
            # - Avoids CMD's quirky quote escaping rules
            # Use -NoProfile for faster startup, -Command to execute
            shell_cmd = ["powershell", "-NoProfile", "-Command", command]
        else:
            shell_cmd = ["bash", "-c", command]

        result = subprocess.run(
            shell_cmd,
            capture_output=True,
            text=True,
            timeout=effective_to,
            cwd=cwd,
        )

        output_parts = []
        if result.stdout:
            output_parts.append(result.stdout)
        if result.stderr:
            output_parts.append(f"[stderr]\n{result.stderr}")

        output = "\n".join(output_parts) if output_parts else ""

        # ── Step 5a: Silent command — no output is OK ───────────────────
        if not output:
            if category == CommandCategory.SILENT or result.returncode == 0:
                return "(command completed successfully, no output)"

        # ── Step 5b: Truncate very long output ──────────────────────────
        max_output = 50_000
        if len(output) > max_output:
            output = (
                output[:max_output]
                + f"\n\n[Output truncated at {max_output} chars. "
                f"Use grep or file_read for targeted reading.]"
            )

        # ── Step 5c: Exit code handling ─────────────────────────────────
        if result.returncode != 0:
            exit_info = _format_exit_code_info(command, result.returncode)
            if exit_info:
                # Known non-error exit code
                output = output + exit_info if output else exit_info
            else:
                output = f"[Exit code: {result.returncode}]\n{output}"

        return output

    except subprocess.TimeoutExpired:
        # ── Step 6: Auto-background on timeout ──────────────────────────
        if (
            not readonly
            and _bg_manager.can_auto_background(command)
            and effective_to <= BLOCKING_BUDGET_S
        ):
            # Auto-background: restart in background
            task_id = _bg_manager.start_task(
                command=command,
                cwd=cwd,
                timeout=TIMEOUT_BACKGROUND,
                description=desc_display,
            )
            return (
                f"Command auto-backgrounded after {effective_to}s timeout.\n"
                f"Task ID: {task_id}\n"
                f"Category: {category.name}\n"
                f"Use bash(command='bg_status {task_id}') to check progress."
            )

        # Regular timeout
        return _format_timeout_error(command, category, effective_to, readonly)

    except FileNotFoundError:
        return _format_not_found_error(command)

    except Exception as e:
        logger.exception("bash tool failed for command: %s", command)
        return f"Error executing command: {e}"