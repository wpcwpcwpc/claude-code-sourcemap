"""
QA Agent System — Application Entry Point

Usage:
    # Development
    python main.py

    # Production
    uvicorn main:app --host 0.0.0.0 --port 8000 --workers 1

Note: agent execution relies on asyncio; use a single worker process.
      Scale horizontally by running multiple containers behind a load balancer.
"""

import logging
import sys
from pathlib import Path

# Ensure the project root is on sys.path when running directly
sys.path.insert(0, str(Path(__file__).parent))

from core.config import settings

# Configure structured logging before importing anything else
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# Re-export the app object so `uvicorn main:app` works
from api.server import app  # noqa: E402  (imported after logging setup)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.server_host,
        port=settings.server_port,
        reload=settings.debug,
        log_level=settings.log_level.lower(),
        # Single worker is required for shared asyncio state (interrupt events)
        workers=1,
    )
