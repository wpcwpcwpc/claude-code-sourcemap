---
name: hunter-runner
description: 通过 Hunter2 平台远程连接设备并执行 Python 代码。当用户想通过 hunter 连接本机或远端设备、在指定设备上执行 Python 脚本/命令、运行自动化用例（如 run_case）时使用本 skill。支持连接本机（自动获取 IP）或指定远端 IP，需要 tokenid 和 groupname。触发词：hunter 执行、hunter 连接、hunter 发脚本、远端执行 Python、hunter run_case、hunter 脚本。
---

# Hunter Runner

通过 `hunter2_cli` 库连接设备并执行 Python 脚本。

## 前置条件

- 已安装 `hunter2_cli`（`pip install hunter2_cli`）
- 已安装 `psutil`（`pip install psutil`）
- 已有效的 `tokenid`（从 hunter2 网站获取）
- 已知 `groupname`（区分大小写，如 `H73`）

## 用户个人 Config 文件

**每位用户有一个专属 config 文件**，存放在固定路径：
`C:/Users/<username>/.codemaker/skills/hunter-runner/hunter_config.py`

当前用户（tanyawen02）的 config 文件内容已写死为：
```python
# hunter_config.py —— 个人 Hunter 连接配置，请勿提交到代码仓库
tokenid = "1fae458dcaa3bdcd8d2dc8afa82285bd-3484ab10-4fc0-4994-99df-843fdaf47607"
groupname = "H73"
```

**在生成执行脚本时，必须优先从 config 文件读取**，而不是让用户每次手动填写：

```python
import importlib.util, os

def _load_hunter_config():
    config_path = os.path.expanduser(
        "~/.codemaker/skills/hunter-runner/hunter_config.py"
    )
    spec = importlib.util.spec_from_file_location("hunter_config", config_path)
    cfg = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cfg)
    return cfg

_cfg = _load_hunter_config()
tokenid = _cfg.tokenid
groupname = _cfg.groupname
```

若 config 文件不存在，则回退到询问用户填写，并提示用户创建该文件。

## 核心工作流

### 1. 确认连接参数

config 文件已存在，直接读取，无需询问用户 tokenid/groupname。
仅在以下情况询问：
- config 文件不存在
- 需要连接**远端 IP**（非本机）时才询问目标 IP

### 2. 用例编写原则：生成独立 `.py` 脚本文件

**⚠️ 核心原则：将用例逻辑生成为一个独立的 `.py` 脚本文件，通过 `py -3 <script_path>` 执行。不使用内联 exec，不新建 TaskBase 子类文件。**

脚本结构固定为：
1. **传送** → `BaseApi.teleport_player(x, y, z)` + `time.sleep(5)` 等待场景加载
2. **前置准备**（可选）→ `BaseApi.set_water / set_healthy` 等
3. **执行 Case** → `run_case(cases=['CaseXxx'])`

每个 `hunter.script()` 调用对应一条远端执行语句，步骤之间用 `time.sleep()` 等待。

#### 标准脚本模板

```python
# encoding: utf-8
from hunter2_cli import Hunter
import socket, importlib.util, os
import time

def get_ipv4():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ipv4 = s.getsockname()[0]
        s.close()
        return ipv4
    except Exception:
        return '127.0.0.1'

def _load_hunter_config():
    config_path = os.path.expanduser(
        "~/.codemaker/skills/hunter-runner/hunter_config.py"
    )
    spec = importlib.util.spec_from_file_location("hunter_config", config_path)
    cfg = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cfg)
    return cfg

_cfg = _load_hunter_config()
tokenid = _cfg.tokenid
groupname = _cfg.groupname
devip = get_ipv4()
print("[Hunter] 本机 IP: {}".format(devip))

hunter = Hunter(tokenid, groupname, devip=devip)

# Step 1: 传送到目标坐标
hunter.script(r"from debug.qa_debug.Automation.common.BaseApi import BaseApi")
hunter.script(r"BaseApi.teleport_player(<x>, <y>, <z>)")
print("[Hunter] Step 1: 传送指令已发送，等待 5s 场景加载...")
time.sleep(5)

# Step 2: 前置准备（按需保留）
hunter.script(r"from debug.qa_debug.Automation.common.BaseApi import BaseApi")
hunter.script(r"BaseApi.set_water(10000)")
print("[Hunter] Step 2: 饮水状态已补满")

# Step 3: 执行 Case
hunter.script(r"from debug.qa_debug.Automation.main import run_case")
hunter.script(r"run_case(cases=['<CaseName>'])")
print("[Hunter] Step 3: <CaseName> 已提交，请观察游戏内执行结果")
```

#### 可用 Case 速查（来自 qa-debug-automation skill）

| Case 名 | 用途 |
|---------|------|
| `CaseUnlockWorldStone` | 寻路到最近世界石 + 长按F解锁 + 五项验证 |
| `CaseTransportBattle` | 传送到战斗区域并测试战斗 |
| `CaseLogin` / `CaseLoginNew` | 登录流程 |
| `CaseMapCombat` | 地图战斗测试 |
| `CaseOpenShop` | 打开商店 |
| `CaseCheckAllNpcValid` | 检查所有NPC有效性 |
| `CaseCheckTransportTowerValid` | 检查传送塔有效性 |
| `CaseTrunkSmokeTest` | 主干冒烟测试 |
| `CasePathRecorder` / `CasePathReplayer` | 路径录制/回放 |

### 3. 执行流程

1. 将生成的脚本**保存为临时文件**（如 `C:/Users/tanyawen02/hunter_run_tmp.py`）
2. 用终端命令执行（用户 Python 环境为 `py -3`）：
```powershell
py -3 C:/Users/tanyawen02/hunter_run_tmp.py
```

## 注意事项

- 生成的脚本是**本地 Python 脚本**（在用户机器上运行），通过 `hunter.script()` 将指令发送到游戏进程
- `groupname` 区分大小写
- 每次 `hunter.script()` 调用对应一条独立的远端执行语句
- 传送后必须 `time.sleep(5)` 等待场景加载，再执行后续步骤
- `BaseApi` 每次 `hunter.script()` 都需要重新 import（远端每条语句独立执行）

详细参数说明见 [references/hunter_usage.md](references/hunter_usage.md)
