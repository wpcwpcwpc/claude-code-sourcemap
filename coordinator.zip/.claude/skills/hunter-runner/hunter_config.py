# hunter_config.py —— 个人 Hunter 连接配置，请勿提交到代码仓库
tokenid = "1fae458dcaa3bdcd8d2dc8afa82285bd-3484ab10-4fc0-4994-99df-843fdaf47607"
groupname = "H73"
