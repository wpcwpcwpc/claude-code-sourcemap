# Hunter2 使用参考

## Hunter 类构造参数

```python
Hunter(tokenid, groupname, devip=None, devid=None)
```

| 参数 | 说明 | 示例 |
|------|------|------|
| `tokenid` | Hunter2 平台 Token，从个人设置中获取 | `"1fae458d...607"` |
| `groupname` | 申请的组别名称，**区分大小写** | `"H73"` |
| `devip` | 设备 IP 地址（二选一） | `"10.100.x.x"` |
| `devid` | 设备 ID（二选一，从 Hunter 网站获取） | `"组名+IP组成"` |

## 核心方法

### `hunter.script(code_str)`

在远端设备上执行一条 Python 语句。

```python
hunter.script(r"from debug.qa_debug.Automation.main import run_case")
hunter.script(r"run_case(cases=['CaseUnlockWorldStone'])")
```

- 每条语句单独调用一次
- 使用 raw string（`r"..."`）避免反斜杠转义问题
- 语句在远端设备的 Python 环境中顺序执行

## 获取本机 IP 的标准方式

```python
import socket

def get_ipv4():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ipv4 = s.getsockname()[0]
        s.close()
        return ipv4
    except Exception:
        return '127.0.0.1'
```

## 典型使用场景

### 场景1：连接本机执行自动化用例

```python
from hunter2_cli import Hunter
import socket

def get_ipv4():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

hunter = Hunter("YOUR_TOKEN", "H73", devip=get_ipv4())
hunter.script(r"from debug.qa_debug.Automation.main import run_case")
hunter.script(r"run_case(cases=['CaseXxx'])")
```

### 场景2：连接远端设备

```python
from hunter2_cli import Hunter

hunter = Hunter("YOUR_TOKEN", "H73", devip="192.168.1.100")
hunter.script(r"import some_module")
hunter.script(r"some_module.do_something()")
```

### 场景3：使用环境变量管理 Token（推荐）

```python
import os
from hunter2_cli import Hunter

tokenid = os.environ.get("HUNTER_TOKEN", "")
hunter = Hunter(tokenid, "H73", devip="...")
```

## Hunter2 网站

- 设备管理和 Token 申请：https://hunter2.netease.com
- API 接口（后端调用参考）：
  - 获取设备列表：`GET https://hunter2.netease.com/api/device/get_all_device`
  - 发送脚本：`POST https://hunter2.netease.com/api/device/send_script`