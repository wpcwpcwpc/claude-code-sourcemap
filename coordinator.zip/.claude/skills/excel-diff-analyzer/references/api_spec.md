# API 规范

Excel Diff 分析 API 的端点信息、curl 命令模板和响应结构说明。

## Diff API 端点

| 项目 | 值 |
|------|-----|
| **URL** | `http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_excel_batch_diff` |
| **方法** | POST |
| **Content-Type** | application/json |
| **描述** | Excel 批量差异分析，支持语义增强 |

### 请求体结构

```json
{
  "tasks": [
    {
      "file_url": "03开放世界生存/path/to/file.xlsx",
      "revisions": [2000088, 2007859]
    }
  ]
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `tasks` | array | 是 | 批量 diff 任务列表 |
| `tasks[].file_url` | string | 是 | SVN 文件路径，支持两种格式：<br>1. **相对路径**：`03开放世界生存/道具表.xlsx`（从 design/ 后开始）<br>2. **完整 SVN URL**：`svn://svn-viking.../trunk/design/...xlsx`（服务端自动提取相对路径） |
| `tasks[].revisions` | int[] | 是 | 版本号数组，每个版本与 revision-1 做 diff |

## 命令模板

> 使用 `python -c` 内联脚本调用 API，跨平台兼容（Windows/Linux/macOS）。需要 `requests` 库：`pip install requests`

### 单文件请求

```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_excel_batch_diff',json={'tasks':[{'file_url':'03开放世界生存/06模因系统/05_道具转化表.xlsx','revisions':[2000088,2007859]}]}).text)"
```

### 多文件批量请求

```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_excel_batch_diff',json={'tasks':[{'file_url':'03开放世界生存/path/to/file1.xlsx','revisions':[2000088,2007859]},{'file_url':'03开放世界生存/path/to/file2.xlsx','revisions':[2003028,2004555]}]}).text)"
```

### 保存响应到文件

```bash
python -c "import requests,json;r=requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_excel_batch_diff',json={'tasks':[{'file_url':'03开放世界生存/06模因系统/05_道具转化表.xlsx','revisions':[2000088,2007859]}]});open('response.json','w',encoding='utf-8').write(json.dumps(r.json(),ensure_ascii=False,indent=2))"
```

## 响应结构

### 顶层结构

```json
{
  "code": 200,
  "message": "处理结果描述",
  "data": {
    "diff_data": { ... },
    "processing_info": { ... },
    "summary": { ... }
  }
}
```

| 字段 | 说明 |
|------|------|
| `code` | HTTP 状态码，200 = 成功 |
| `message` | 处理结果描述 |
| `data.diff_data` | 按文件 URL 索引的差异数据（核心数据） |
| `data.processing_info` | 处理状态（cache_hit/processed） |
| `data.summary` | 统计摘要（total_files, cache_hit_rate 等） |

### diff_data 层级结构

```
data.diff_data
  └── {file_url}               # 以文件相对路径为 key
       └── sheet_changes[]     # 工作表变更数组
            ├── sheet_name     # 工作表名称
            ├── column_info    # 列元信息字典 {列名: 描述或null}
            └── row_changes[]  # 行级变更数据列表
```

### row_changes 数据格式

每一行是一个 dict，key 为**列名**，value 使用压缩编码格式：

| 值类型 | 含义 | 示例 |
|--------|------|------|
| 字符串 / 数字（标量） | 该列**未变化**，值为当前内容 | `"是"`、`136` |
| 数组 `[旧值, 新值]` | 该列**有变化**，`[0]` 为旧值，`[1]` 为新值 | `["手枪穿甲弹", "手枪高速弹"]` |

> ⚠️ **解读规则**：值为标量 → 未变化；值为二元数组 → 有变化，第一个元素是变更前，第二个元素是变更后，"Skip"为空值代表改行数据作废，不参与分析和展示，填"是"表示该行数据生效
### column_info 格式

```json
{
  "Skip": null, //⚠️空值代表改行数据作废，不参与分析和展示，填"是"表示该行数据生效
  "序号": null,
  "物品1": "填写背包_物品表中的物品ID，留空表示该槽位无物品",
  "权重1": "该物品在掉落池中的权重值，概率=本权重/总权重",
  "总权重": null
}
```

- 有业务意义的描述：保留为字符串
- 空描述或纯类型标注（"整数"/"浮点数"/"字符串"）：置为 `null`

### 完整行变更示例

```json
{
  "skip": "是",
  "序号": 136,
  "转化前id": "30150223(智能型手枪穿甲弹)",
  "转化id1": ["30150331(手枪穿甲弹)", "30150131(手枪钢芯弹)"],
  "转化数量1": ["1", "2"],
  "11": ["手枪穿甲弹", "手枪高速弹"]
}
```

### 语义格式说明

- **正常解析**：`"30150331(手枪穿甲弹)"` — ID 后跟括号内的业务名称
- **解析失败**：`"2004(未找到物品)"` — ID 无法解析为有效名称
- **未解析**：纯数字如 `"5090000101"` — 服务端未覆盖的字段，需要后续语义增强

## Issue 输入辅助 API

提供从 issue_id 到 SVN 修订号、从修订号到配置表文件的两个原子接口，用于 Phase 1 自动构建 tasks[]。

---

### /get_issue_revisions 接口

| 项目 | 值 |
|------|-----|
| **URL** | `http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_issue_revisions` |
| **方法** | POST |
| **Content-Type** | application/json |
| **描述** | 通过 issue_id 获取关联的 SVN 修订号，自动 fallback H73-缺陷跟踪项目 |

#### 请求体

```json
{
  "issue_id": "12345"
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `issue_id` | string | 是 | Redmine issue/bug 编号 |

#### 响应结构

```json
{
  "code": 200,
  "data": {
    "issue_id": "12345",
    "revisions": ["2007859", "2007900"],
    "project_matched": "H73（New）"
  }
}
```

| 字段 | 说明 |
|------|------|
| `data.issue_id` | 查询的 issue_id |
| `data.revisions` | 修订号字符串列表，未找到时为 `[]` |
| `data.project_matched` | 实际命中的 Redmine 项目名，两个项目均未命中时为 `null` |

> 接口内部先查 `H73（New）`，若 revisions 为空自动 fallback 到 `H73-缺陷跟踪`，调用方无需关心项目名。

#### 命令模板

```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_issue_revisions',json={'issue_id':'12345'}).text)"
```

---

### /get_revision_xlsx_files 接口

| 项目 | 值 |
|------|-----|
| **URL** | `http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_revision_xlsx_files` |
| **方法** | POST |
| **Content-Type** | application/json |
| **描述** | 批量获取多个修订号在指定分支下变更的 xlsx/xls 文件列表，自动去重，返回完整 SVN URL |

#### 请求体

```json
{
  "revisions": ["2007859", "2007900"],
  "branch": "gray"
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `revisions` | string[] | 是 | SVN 修订号列表，支持一次传多个 |
| `branch` | string | 是 | 分支类型：`trunk` 或 `gray` |

#### 响应结构

```json
{
  "code": 200,
  "data": {
    "revisions": ["2007859", "2007900"],
    "branch": "gray",
    "files": [
      {
        "file_url": "svn://svn-viking.gz.netease.com/svn/branches/branch_gray/design/01数值系统/03投放系统/道具表.xlsx",
        "action": "M"
      }
    ]
  }
}
```

| 字段 | 说明 |
|------|------|
| `data.files` | xlsx/xls 文件列表，无配置表变更时为 `[]`，同一文件在多个修订中只返回一次 |
| `data.files[].file_url` | 完整 SVN URL，可直接用于 `get_excel_batch_diff` 的 `tasks[].file_url` |
| `data.files[].action` | 变更类型：`M`=修改、`A`=新增、`D`=删除、`R`=替换（同一文件多次出现取最后一次） |

> `file_url` 已包含完整 SVN 路径（含分支前缀），可直接传入 `get_excel_batch_diff`，服务端会自动提取相对路径。

#### 命令模板

```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_revision_xlsx_files',json={'revisions':['2007859','2007900'],'branch':'gray'}).text)"
```

---

## API 内置语义转换

diff API 服务端会自动对特定列的 ID 进行 名称解析。匹配规则基于列名关键词：

| 列名包含 | 转换类型 | 示例 |
|---------|---------|------|
| "投放"、"掉落" | 普通/稀有掉落名称查询 | `5090000101` → `5090000101(T1收容箱)` |
| "道具"、"物品"、"装备" | 物品名称查询 | `30150331` → `30150331(手枪穿甲弹)` |
| "转化id" | 物品转化查询 | `30150131` → `30150131(手枪钢芯弹)` |

**重要**：并非所有列的 ID 都会被服务端转换。例如"普通掉落项ID"、"稀有掉落项ID"等列可能不在自动转换范围内。这些未覆盖的纯数字 ID 需要在 Phase 3 中通过 `references/semantic_lookup.md` 中的 curl 命令手动查询。
