# 语义增强规范

对 diff 数据中未被 API 自动解析的纯数字 ID 进行业务名称查询的规则和命令模板。

> 使用 `python -c` 内联脚本调用 API，跨平台兼容（Windows/Linux/macOS）。需要 `requests` 库：`pip install requests`

## ID 识别规则

在分析 diff 数据中的 old/new 值时，按以下规则判断是否需要查询：

| 条件 | 动作 | 原因 |
|------|------|------|
| 纯数字，位数 ≥ 6 | ✅ 查询 | 很可能是业务 ID |
| 纯数字，位数 < 6 | ❌ 跳过 | 通常是数量、权重或序号 |
| 已有 `"ID(名称)"` 格式（含括号） | ❌ 跳过 | 已被 diff API 解析 |
| 非数字（文字、混合内容） | ❌ 跳过 | 不是 ID |

**示例判断**：
- `"5090000101"` → ✅ 10位纯数字，查询
- `"500"` → ❌ 3位，跳过（是数量）
- `"30150331(手枪穿甲弹)"` → ❌ 已解析，跳过
- `"手枪高速弹"` → ❌ 非数字，跳过

## 字段名 → 查询类型映射

根据待查询 ID 所在的字段名称，选择对应的查询 API：

| 字段名包含 | 查询类型 | API 端点 |
|-----------|---------|---------|
| "普通掉落" | `common_drop` | get_common_drop |
| "稀有掉落" | `rare_drop` | get_rare_drop |
| 其他所有情况 | `item`（兜底） | get_gift_by_item |

**映射示例**：
- "普通掉落项ID" 列中的 `5090000101` → 使用 common_drop 查询
- "稀有掉落项ID" 列中的 `5119005101` → 使用 rare_drop 查询
- "额外生成规则" 列中的 `901918` → 使用 item 查询（兜底）
- "转化id1" 列中未解析的数字 → 使用 item 查询（兜底）

## 命令模板

### 1. 普通掉落查询 (common_drop)

```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_common_drop',data={'common_drop_id':'{ID}','env':'trunk'}).text)"
```

**响应路径**：`data`（整个 data 对象包含掉落信息）
**关键字段**：`common_remark`（备注名称）、`items`（掉落物品列表）

**示例**：
```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_common_drop',data={'common_drop_id':'5090000101','env':'trunk'}).text)"
```

### 2. 稀有掉落查询 (rare_drop)

```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_rare_drop',data={'rare_drop_id':'{ID}','env':'trunk'}).text)"
```

**响应路径**：`data`（整个 data 对象包含掉落信息）
**关键字段**：`rare_remark`（备注名称）、`items`（掉落物品列表）

**示例**：
```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_rare_drop',data={'rare_drop_id':'5119005101','env':'trunk'}).text)"
```

### 3. 物品名称查询 (item) — 兜底

```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_gift_by_item',data={'item_id':'{ID}','env':'trunk'}).text)"
```

**响应路径**：`data.item_name`
**关键字段**：`item_name`（物品名称）

**示例**：
```bash
python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_gift_by_item',data={'item_id':'99000027','env':'trunk'}).text)"
```

## 查询结果集成规则

### 成功时

将原始数字 ID 替换为 `"ID（名称）"` 格式：
- 查询前：`"5090000101"`
- 查询后：`"5090000101（T1 suitcase）"`

### 失败时

保留原始 ID，追加标注：
- API 返回空结果：`"5090000101（未查询到名称）"`
- 命令执行失败：`"5090000101（查询失败）"`

### 不因失败影响报告

部分 ID 查询失败不影响报告的生成和完整性。未查询到的 ID 在报告中保留原始值并标注即可。

## 批量查询指导

### 基本策略

- 这些 API 响应极快（<100ms），逐个查询即可
- 不要因为 ID 数量多而犹豫或跳过查询
- 当需要查询时，直接执行命令，不要延迟
- **由 LLM 组织多次单条命令调用**，无需使用循环语法

### 多 ID 场景

当需要查询多个 ID 时，LLM 应逐个执行查询命令。例如需要查询 3 个物品 ID：

1. 执行: `python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_gift_by_item',data={'item_id':'99000027','env':'trunk'}).text)"`
2. 执行: `python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_gift_by_item',data={'item_id':'99000067','env':'trunk'}).text)"`
3. 执行: `python -c "import requests;print(requests.post('http://7.24.187.157:38388/api/get_gift_by_item',data={'item_id':'30150331','env':'trunk'}).text)"`

这种方式简单可靠，避免了平台特定的循环语法差异。

### 查询优先级

1. 先完成字段级统计（Dimension 3），确定哪些值是未解析的 ID
2. 按字段名映射确定查询类型
3. 执行查询，回填结果
4. 使用增强后的数据继续后续分析维度