# 分段处理规范

当 API 响应数据较大时，Excel Diff 分析技能使用分段处理机制，确保 LLM 能够完整读取并分析所有数据。

## 概述

**触发条件**: API 响应文件 >= 200KB  
**切分脚本**: `.claude/skills/excel-diff-analyzer/scripts/split_response.py`  
**切分策略**: file_url → sheet → row_changes 批次（三层递进）

> 所有命令使用 Python 实现，跨平台兼容（Windows/Linux/macOS）。需要 `requests` 库：`pip install requests`

---

## Step 2.1: 创建临时工作目录

在运行前创建一个隔离的临时目录，用于存放响应文件和 chunk 文件。

```bash
python -c "import os,tempfile;d=os.path.join(tempfile.gettempdir(),'excel_diff_'+str(os.getpid()));os.makedirs(d,exist_ok=True);print(d)"
```

执行后会输出临时目录路径，例如：`C:\Users\xxx\AppData\Local\Temp\excel_diff_12345`

后续步骤中用这个路径替换 `{DIFF_TEMP}`。

---

## Step 2.2: API 调用，保存响应到临时文件

使用 Python 将 API 响应直接保存到文件：

```bash
python -c "import requests,json;r=requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_excel_batch_diff',json={'tasks':[{'file_url':'{FILE_PATH}','revisions':[{REV1},{REV2}]}]});open('{DIFF_TEMP}/response.json','w',encoding='utf-8').write(json.dumps(r.json(),ensure_ascii=False,indent=2))"
```

**参数说明**：
- `{FILE_PATH}`: 配置表相对路径，如 `03开放世界生存/06模因系统/05_道具转化表.xlsx`
- `{REV1},{REV2}`: 版本号列表，如 `2000088,2007859`
- `{DIFF_TEMP}`: Step 2.1 创建的临时目录路径

> ⏱️ API 调用需要 10 秒～1 分钟，耐心等待响应写入完成。

---

## Step 2.3: 检测响应大小

```bash
python .claude/skills/excel-diff-analyzer/scripts/split_response.py check "{DIFF_TEMP}/response.json" --threshold 200
```

**结果判断:**

| 输出 | 退出码 | 含义 | 下一步 |
|------|--------|------|--------|
| `OK (X.XKB < 200KB threshold)` | `0` | 无需切分 | 直接跳至 [Step 2.6 直接读取](#step-26-路径a-直接读取) |
| `NEEDS_SPLIT (X.XKB >= 200KB threshold)` | `1` | 需要切分 | 继续 Step 2.4 |
| `ERROR: ...` | `2` | 脚本错误 | 检查 Python 3 是否已安装，检查文件路径 |

---

## Step 2.4: 切分响应文件（仅 NEEDS_SPLIT 时执行）

```bash
python .claude/skills/excel-diff-analyzer/scripts/split_response.py split "{DIFF_TEMP}/response.json" "{DIFF_TEMP}" --max-size 200
```

**预期输出:**
```
Split into N chunk(s).
Manifest: {DIFF_TEMP}/manifest.json
```

切分完成后，临时目录结构如下：
```
{DIFF_TEMP}/
├── response.json          # 原始 API 响应（完整）
├── manifest.json          # chunk 索引文件
├── chunk_000.json         # 第 1 个分段
├── chunk_001.json         # 第 2 个分段
└── ...
```

---

## Step 2.5: 路径 B — 分段读取与累积分析

### 5.1 读取 manifest.json

首先读取 `manifest.json`（路径为 `{DIFF_TEMP}/manifest.json`），了解分段概况：

```json
{
  "source_file": "...",
  "output_dir": "...",
  "max_size_kb": 200,
  "summary": { ... },
  "chunks": [
    {
      "file": "chunk_000.json",
      "file_url": "03开放世界生存/道具表.xlsx",
      "sheet_name": "主表",
      "row_count": 180,
      "batch": null
    },
    {
      "file": "chunk_001.json",
      "file_url": "03开放世界生存/道具表.xlsx",
      "sheet_name": "转化表",
      "row_count": 150,
      "batch": { "index": 0, "start": 0, "end": 149, "total": 600 }
    }
  ]
}
```

读取后在对话中展示分段计划：
> "响应数据已切分为 N 个分段，开始逐段分析..."

### 5.2 逐段读取 chunk 并累积分析

对 `manifest.chunks` 中的每个 chunk 依次执行：

1. **读取** `{DIFF_TEMP}/<chunk.file>` 的完整内容
2. **分析** 该 chunk 的 `row_changes`：
   - 识别变更模式（old→new 规律）
   - 统计模式频率
   - 收集未解析的 ≥6 位纯数字 ID
   - 识别数据异常
3. **累积** 分析结果到内存中的累积变量（见 Step 2.5.3）
4. **输出进度**：`"已处理 X/N 分段（文件: <file_url>，sheet: <sheet_name>，本段 Z 行）"`

**注意 `batch_info` 字段：**

若 chunk 包含 `batch_info`，表示这是同一个 sheet 的行级切分批次：
- `column_info` 字段在每个批次中都完整保留，直接使用
- 同一 sheet 的多个批次的模式统计需合并（相同模式的 count 相加，samples 取各批次代表性样本）

### 5.3 需要累积的数据结构

在 LLM 的对话上下文中维护以下累积数据：

**变更模式统计**
```
{
  "<模式名称>": {
    "count": <累计出现次数>,
    "samples": [
      {"chunk": "chunk_000", "row_index": 15, "field": "<列名>", "old": "<旧值>", "new": "<新值>"},
      ...最多保留 5 个代表性样本
    ]
  }
}
```

**发现的异常**
```
[
  {"type": "数据异常|业务风险|一致性问题", "desc": "<描述>", "chunk": "chunk_XXX", "row_index": N},
  ...
]
```

**待查询 ID 列表**（用于 Phase 3 语义增强）
```
[
  {"id": "5090000101", "context": "<所在列名>", "chunk": "chunk_XXX"},
  ...去重保留
]
```

---

## Step 2.6: 路径 A — 直接读取（响应 < 200KB）

当 `check` 命令返回 `OK` 时，直接读取响应文件：

使用 `read_file` 工具读取 `{DIFF_TEMP}/response.json` 的完整内容，然后按正常 Phase 3 流程分析。

---

## Step 2.7: 清理临时文件（Phase 3 完成后）

在最终报告生成并展示给用户后，执行清理：

```bash
python .claude/skills/excel-diff-analyzer/scripts/split_response.py clean "{DIFF_TEMP}"
```

**预期输出:**
```
Cleaned: {DIFF_TEMP}
```

---

## 完整流程图

```
Phase 2 开始
    │
    ▼
Step 2.1: 创建临时目录 {DIFF_TEMP}
    │
    ▼
Step 2.2: Python API 调用 → 保存到 {DIFF_TEMP}/response.json
    │
    ▼
Step 2.3: check response.json
    │
    ├──── OK (< 200KB) ────────────────────────────────────┐
    │                                                       │
    ▼                                                       │
Step 2.4: split response.json → chunk_*.json + manifest   │
    │                                                       │
    ▼                                                       │
Step 2.5: 读取 manifest → 逐段读取 chunk → 累积分析        │
    │                                                       │
    └──────────────────────────────────────────────────────┤
                                                           │
                                              Step 2.6: 直接读取 response.json
                                                           │
                                                           ▼
                                                     进入 Phase 3
                                                           │
                                                           ▼
                                                   生成最终报告
                                                           │
                                                           ▼
                                              Step 2.7: clean {DIFF_TEMP}
```