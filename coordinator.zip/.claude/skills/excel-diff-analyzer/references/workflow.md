# 工作流规范

Excel Diff 深度分析的三阶段工作流详细规范。

## Phase 1: 智能输入解析

### 输入方式

**方式 A（推荐）：issue_id 驱动输入**

用户提供 issue 编号、分支和需求描述，技能自动获取文件路径和修订号：

```
issue: 12345, 67890   branch: gray   需求: 弹药数值调整和掉落权重优化
```

**方式 B（备用）：直接输入文件路径 + 版本号**

| 格式类型 | 示例 | 解析方式 |
|---------|------|---------|
| SVN 完整 URL + 版本范围 | `"svn://svn-viking.gz.netease.com/svn/trunk/design/items.xlsx [1915000..1917018]"` | 直接提取 URL 和版本 |
| 自然语言 from/to | `"config.xlsx from version 1915000 to 1917018"` | 关键词匹配提取 |
| 自然语言 between | `"analyze items.xlsx changes between r1915000 and r1917018"` | 关键词匹配提取 |
| 单版本号 | `"items.xlsx 2006360"` | 单版本有效，API 自动与 revision-1 做 diff |
| 多版本列表 | `"drops.xlsx versions: 1915000, 1916500, 1917018"` | 逗号分隔提取 |
| 相对路径 | `"/trunk/design/drops.xlsx 2007859"` | 补全为完整 SVN URL |

### issue_id 驱动输入流程（方式 A）

**混合策略说明**：
- **Step 1.1（单号→修订号）**：只能通过 HTTP API 获取（Redmine 数据）
- **Step 1.2（修订号→文件）**：优先 SVN CLI，失败时降级 HTTP API
- API 规范详见 `references/api_spec.md` 的「Issue 输入辅助 API」章节

---

**Step 1.1: 通过 API 获取修订号列表（仅 API）**

对每个 issue_id 调用 `/get_issue_revisions`，收集修订号并去重。

```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_issue_revisions',json={'issue_id':'{ISSUE_ID}'}).text)"
```

> 📖 完整 API 规范见 `references/api_spec.md`「/get_issue_revisions 接口」

- 若某个 issue 返回 `revisions: []`，告知用户该 issue 无关联修订，跳过
- 合并所有修订号：`all_revisions = set([...])`

---

**Step 1.2: 获取修订文件路径（CLI 优先，API 兜底）**

对 Step 1.1 获取的每个修订号，查询其变更的 xlsx/xls 文件。

#### 策略 A: SVN CLI（优先）

对每个修订号执行 `svn diff --summarize`，获取变更文件列表：

```bash
# trunk 分支
svn diff -r {revision-1}:{revision} --summarize \
    svn://svn-viking.gz.netease.com/svn/trunk/design

# gray 分支
svn diff -r {revision-1}:{revision} --summarize \
    svn://svn-viking.gz.netease.com/svn/branches_gray/design
```

**示例**（revision = 2004206，branch = trunk）：
```bash
svn diff -r 2004205:2004206 --summarize svn://svn-viking.gz.netease.com/svn/trunk/design
# 输出：
# M       svn://svn-viking.gz.netease.com/svn/trunk/design/01数值系统/03投放系统/05_物品投放属性随机规则表.xlsx
```

**处理逻辑**：
1. 对每个 revision 执行上述命令
2. 从输出中筛选 `.xlsx` 和 `.xls` 文件（忽略其他文件类型）
3. 提取文件的完整 SVN URL
4. 收集所有文件路径（不用手动去重，后端 API 会处理）

**分支 URL 映射**：
| branch 参数 | SVN URL |
|------------|---------|
| `trunk` | `svn://svn-viking.gz.netease.com/svn/trunk/design` |
| `gray` | `svn://svn-viking.gz.netease.com/svn/branches_gray/design` |

- 若 CLI 命令成功返回 → 继续 Step 1.3
- 若 CLI 失败（无权限、网络问题）→ 降级到**策略 B**

#### 策略 B: HTTP API（兜底）

当 SVN CLI 不可用时，调用后端 API 获取文件列表：

```bash
python -c "import requests;print(requests.post('http://openworld-rescheck.netease.com:9998/api/v1/dify_workflow/get_revision_xlsx_files',json={'revisions':['2007859','2007900','2007861'],'branch':'gray'}).text)"
```

响应示例：
```json
{"code": 200, "data": {"files": [{"file_url": "svn://...道具表.xlsx", "action": "M"}, {"file_url": "svn://...采集表.xlsx", "action": "M"}]}}
```

- 接口已在服务端按 file_url 去重
- 若返回 `files: []` 说明这批修订号均无配置表变更

---

**Step 1.3: 构建 tasks[]**

接口已完成去重，直接以返回的 `files[]` 中的 `file_url` 构建 tasks，`revisions` 使用 Step 1.1 合并的全量修订号列表：

```
all_revisions = sorted(list(set(所有 issue 的修订号)))

tasks = [
    {"file_url": f["file_url"], "revisions": all_revisions}
    for f in files
]
```

**Step 1.4: 向用户展示汇总确认表，等待确认**

展示格式（示例）：

```
✅ 根据 issue 12345、67890 在 gray 分支找到以下配置表变更：

#  文件名                               修订号              操作
1  01数值系统/03投放系统/道具表.xlsx     2007859, 2007900    M
2  01数值系统/03投放系统/采集表.xlsx     2007859             M
3  02战斗系统/技能表.xlsx               2007861             A

📋 请确认以上文件列表。
   确认后将调用 Diff API 分析这些文件的变更内容并生成深度分析报告。
   
   如需排除某个文件，请告知编号。
```

**重要**：必须等待用户明确确认（"确认"/"开始"/"OK"等）后才能进入 Phase 2。

**Step 1.5: 用户确认后进入 Phase 2**

- 用户确认 → 以构建好的 tasks[] 进入 Phase 2
- 用户要求排除文件 → 从 tasks[] 移除对应条目，重新展示确认表
- 用户要求添加文件 → 直接手动补充 file_url 和 revisions 到 tasks[]

## Phase 2: API 调用

> 📖 curl 命令模板和请求体格式见 `references/api_spec.md`
> 📖 分段处理命令和 LLM 累积分析规范见 `references/chunked_processing.md`

### 调用流程

1. 创建临时目录 `$DIFF_TEMP`
2. 执行 curl，响应保存到 `$DIFF_TEMP/response.json`
3. 检测文件大小（`split_response.py check`）
4. < 200KB → 直接读取；≥ 200KB → 分段处理
5. Phase 3 完成后清理临时目录

### 注意事项

- API 响应耗时 **10秒~1分钟为正常**，不要过早判定超时
- 网络超时时重试 1-2 次
- 空 diff 时告知用户两版本间无变更

---

## Phase 3: 深度分析与报告生成

### 分析步骤顺序

1. **基本信息提取** → 文件名、工作表名、版本范围、总变更行数
2. **列头解析** → 识别列结构，标注缺失列名的列号
3. **变更模式聚类** → 按行号分段，识别重复 old→new 模式，计数
4. **字段级统计** → 每个变更字段的模式频率分析
5. **语义增强** → 对未解析的 ≥6位纯数字 ID 执行 curl 查询（详见 `references/semantic_lookup.md`）
6. **业务语义解释** → 将技术模式翻译为业务含义（基于数据推理，禁止猜测）
7. **异常和风险识别** → 数据异常、业务风险、一致性问题
8. **结构化输出** → 按报告模板组装最终报告（详见 `references/output_format.md`）

### 语义增强触发时机

- 在步骤 4（字段级统计）完成后、步骤 6（业务解释）之前执行
- 扫描所有 old/new 值中的纯数字，按照 `references/semantic_lookup.md` 的规则判断并查询
- 将查询结果回填到分析数据中，后续步骤使用增强后的数据

### 大数据集处理策略（>500 行变更）

当变更行数超过 500 行时：
- 以模式级分析为主，不逐行枚举
- 每个模式提供 3-5 个代表性样本行
- 确保每一行都归入某个命名模式组，不遗漏
- 在报告中标注："由于变更量较大（N行），本报告以模式级分析为主，每个模式提供代表性样本"

## 阶段间数据传递

```
Phase 1 输出 → Phase 2 输入
  构造好的 API 请求参数（file_url, revisions）

Phase 2 中间产物（临时文件）
  $DIFF_TEMP/response.json          ← curl API 响应（完整 JSON）
  $DIFF_TEMP/manifest.json          ← chunk 索引（分段路径时生成）
  $DIFF_TEMP/chunk_000.json         ← 各分段数据（分段路径时生成）
  $DIFF_TEMP/chunk_001.json
  ...

Phase 2 输出 → Phase 3 输入
  路径A（直接）: $DIFF_TEMP/response.json 的完整 data.diff_data
  路径B（分段）: 逐段读取 chunk_*.json 后在 LLM 上下文中累积的
                 模式统计 + 异常列表 + 待查 ID 列表
  两路径最终均提供：sheet_changes → column_info, row_changes

Phase 3 完成后
  清理 $DIFF_TEMP 目录（split_response.py clean）

Phase 3 输出 → 报告存储
  结构化的 Markdown 分析报告
  → 展示在对话中
```
