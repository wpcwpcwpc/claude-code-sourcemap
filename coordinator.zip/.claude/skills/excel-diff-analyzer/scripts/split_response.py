#!/usr/bin/env python3
"""
split_response.py - Excel Diff 大响应切分工具

跨平台 CLI 工具，用于检测、切分和清理 Excel diff API 的大响应文件。
支持 Windows (CMD/PowerShell) 和 Linux/macOS (bash)。

用法:
  check  检测文件大小是否超过阈值
         python split_response.py check <file_path> [--threshold <KB>]
         退出码: 0=OK (无需切分), 1=NEEDS_SPLIT (需要切分)

  split  切分大 JSON 响应为多个小文件
         python split_response.py split <input_json> <output_dir> [--max-size <KB>]

  clean  删除临时目录
         python split_response.py clean <dir_path>
"""

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

DEFAULT_THRESHOLD_KB = 200
DEFAULT_MAX_SIZE_KB = 200


# ─────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────

def get_file_size_kb(file_path: str) -> float:
    """返回文件大小 (KB)"""
    return os.path.getsize(file_path) / 1024


def get_json_size_kb(obj) -> float:
    """计算 Python 对象序列化为 JSON 后的大小 (KB)"""
    return len(json.dumps(obj, ensure_ascii=False).encode("utf-8")) / 1024


# ─────────────────────────────────────────────
# check 命令
# ─────────────────────────────────────────────

def cmd_check(args):
    """
    检测文件大小，判断是否需要切分。
    输出: OK 或 NEEDS_SPLIT
    退出码: 0=OK, 1=NEEDS_SPLIT
    """
    file_path = args.file_path
    threshold_kb = args.threshold

    if not os.path.exists(file_path):
        print(f"ERROR: File not found: {file_path}", file=sys.stderr)
        sys.exit(2)

    size_kb = get_file_size_kb(file_path)

    if size_kb >= threshold_kb:
        print(f"NEEDS_SPLIT ({size_kb:.1f}KB >= {threshold_kb}KB threshold)")
        sys.exit(1)
    else:
        print(f"OK ({size_kb:.1f}KB < {threshold_kb}KB threshold)")
        sys.exit(0)


# ─────────────────────────────────────────────
# split 命令
# ─────────────────────────────────────────────

def cmd_split(args):
    """
    切分大 JSON 响应为多个小 chunk 文件，并输出 manifest.json。

    切分策略（三层递进）:
      Level 1: 按 file_url 分组
      Level 2: 按 sheet_changes[i] 切分
      Level 3: 单个 sheet >= max_size 时，按 row_changes 批次切分
    """
    input_file = args.input_json
    output_dir = args.output_dir
    max_size_kb = args.max_size

    if not os.path.exists(input_file):
        print(f"ERROR: Input file not found: {input_file}", file=sys.stderr)
        sys.exit(2)

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # 读取原始响应
    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    diff_data = data.get("data", {}).get("diff_data", {})
    if not diff_data:
        print("ERROR: No diff_data found in response JSON.", file=sys.stderr)
        sys.exit(2)

    chunk_index = 0
    manifest = {
        "source_file": str(Path(input_file).resolve()),
        "output_dir": str(output_path.resolve()),
        "max_size_kb": max_size_kb,
        "summary": data.get("data", {}).get("summary", {}),
        "chunks": [],
    }

    for file_url, file_data in diff_data.items():
        sheet_changes = file_data.get("sheet_changes", [])

        for sheet in sheet_changes:
            sheet_name = sheet.get("sheet_name", "unknown")
            column_info = sheet.get("column_info", {})
            row_changes = sheet.get("row_changes", [])

            # 计算整个 sheet 序列化后的大小
            sheet_obj = {
                "file_url": file_url,
                "sheet_name": sheet_name,
                "column_info": column_info,
                "row_changes": row_changes,
            }
            sheet_size_kb = get_json_size_kb(sheet_obj)

            if sheet_size_kb < max_size_kb:
                # ── Level 2: 整个 sheet 作为一个 chunk ──
                chunk_file = f"chunk_{chunk_index:03d}.json"
                chunk_path = output_path / chunk_file

                with open(chunk_path, "w", encoding="utf-8") as f:
                    json.dump(sheet_obj, f, ensure_ascii=False, indent=2)

                manifest["chunks"].append(
                    {
                        "file": chunk_file,
                        "file_url": file_url,
                        "sheet_name": sheet_name,
                        "row_count": len(row_changes),
                        "batch": None,
                    }
                )
                chunk_index += 1

            else:
                # ── Level 3: sheet 过大，按 row_changes 批次切分 ──
                total_rows = len(row_changes)

                # 动态估算每批行数（保留 10% 余量防止估算偏差）
                if sheet_size_kb > 0 and total_rows > 0:
                    batch_size = max(
                        1,
                        int(total_rows * max_size_kb / sheet_size_kb * 0.9),
                    )
                else:
                    batch_size = 100  # 降级默认值

                batch_index = 0
                for start in range(0, total_rows, batch_size):
                    end = min(start + batch_size, total_rows)
                    batch_rows = row_changes[start:end]

                    chunk_file = f"chunk_{chunk_index:03d}.json"
                    chunk_path = output_path / chunk_file

                    chunk_obj = {
                        "file_url": file_url,
                        "sheet_name": sheet_name,
                        "column_info": column_info,
                        "row_changes": batch_rows,
                        "batch_info": {
                            "batch_index": batch_index,
                            "row_start": start,
                            "row_end": end - 1,
                            "total_rows": total_rows,
                        },
                    }

                    with open(chunk_path, "w", encoding="utf-8") as f:
                        json.dump(chunk_obj, f, ensure_ascii=False, indent=2)

                    manifest["chunks"].append(
                        {
                            "file": chunk_file,
                            "file_url": file_url,
                            "sheet_name": sheet_name,
                            "row_count": len(batch_rows),
                            "batch": {
                                "index": batch_index,
                                "start": start,
                                "end": end - 1,
                                "total": total_rows,
                            },
                        }
                    )
                    chunk_index += 1
                    batch_index += 1

    # 写入 manifest.json
    manifest_path = output_path / "manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(f"Split into {chunk_index} chunk(s).")
    print(f"Manifest: {manifest_path}")


# ─────────────────────────────────────────────
# clean 命令
# ─────────────────────────────────────────────

def cmd_clean(args):
    """
    删除指定的临时目录及其所有内容。
    """
    dir_path = args.dir_path

    if not os.path.exists(dir_path):
        print(f"Directory not found (already clean): {dir_path}")
        sys.exit(0)

    if not os.path.isdir(dir_path):
        print(f"ERROR: Path is not a directory: {dir_path}", file=sys.stderr)
        sys.exit(2)

    shutil.rmtree(dir_path)
    print(f"Cleaned: {dir_path}")


# ─────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Excel Diff 大响应切分工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── check ──
    p_check = subparsers.add_parser(
        "check", help="检测文件大小是否超过阈值 (退出码: 0=OK, 1=NEEDS_SPLIT)"
    )
    p_check.add_argument("file_path", help="要检测的文件路径")
    p_check.add_argument(
        "--threshold",
        type=float,
        default=DEFAULT_THRESHOLD_KB,
        metavar="KB",
        help=f"大小阈值 (KB)，默认 {DEFAULT_THRESHOLD_KB}",
    )
    p_check.set_defaults(func=cmd_check)

    # ── split ──
    p_split = subparsers.add_parser(
        "split", help="切分大 JSON 响应为多个小 chunk 文件"
    )
    p_split.add_argument("input_json", help="输入的 JSON 文件路径")
    p_split.add_argument("output_dir", help="输出目录路径")
    p_split.add_argument(
        "--max-size",
        type=float,
        default=DEFAULT_MAX_SIZE_KB,
        dest="max_size",
        metavar="KB",
        help=f"单个 chunk 最大大小 (KB)，默认 {DEFAULT_MAX_SIZE_KB}",
    )
    p_split.set_defaults(func=cmd_split)

    # ── clean ──
    p_clean = subparsers.add_parser("clean", help="删除临时目录及其所有内容")
    p_clean.add_argument("dir_path", help="要删除的目录路径")
    p_clean.set_defaults(func=cmd_clean)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
