# MCP 自动化脚本模板

## 聚落探索任务模板（已验证，代顿医院 T1_E）

> **适用场景**：完成聚落探索任务——解锁世界石 + 打开神秘宝箱/武器箱/装备箱并拾取物品。
> 输入数据来自聚落配置表（聚落Key、中心坐标、世界石坐标、Prefab名、各宝箱坐标）。

### 使用方式

将配置表一行数据填入下方 `SETTLEMENT_CONFIG`，分三个 MCP 调用依次执行（因单次有超时限制）。

### 调用 1：初始化 + 解锁世界石

```python
from debug.debug_tool import transport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
from ui.ui_manager.UIManager import UIManager
import time

# ========== 配置（从表格填入）==========
WS_X, WS_Y, WS_Z = 5771.0, 88.5, -4526.0   # 世界石_坐标

# ========== 执行 ==========
# 设置无敌防战斗干扰
BaseApi.set_invincible_level_2()
BaseApi.set_healthy()

# 传送到世界石
transport(WS_X, WS_Y, WS_Z)
time.sleep(2)
pos = BaseApi.get_player_pos()
print("pos:", pos)

# 确认世界石在感知范围
hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")), None)
part = hud.get_part(pid)
collect_res = part.collect_multi_res
print("interact count:", len(collect_res))
if collect_res:
    r = collect_res[0]
    print("res_type:", r.get("res_type"), "interact_ui_type:", r.get("interact_ui_type"))
    print("exec_state before:", r.get("exec_state"))

# 解锁世界石（res_type=15，即时交互，用 open_interact_ui 触发 UIWorldStonePromptPC.on_activate）
BaseApi.open_interact_ui()
time.sleep(3)

collect_res2 = part.collect_multi_res
if collect_res2:
    new_state = collect_res2[0].get("exec_state")
    print("exec_state after:", new_state)
    print("worldstone unlocked:", new_state == "003")
else:
    print("worldstone collect_res empty after activate")
```

### 调用 2：打开第一个宝箱（神秘宝箱 / 武器箱）

```python
from debug.debug_tool import transport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
from ui.ui_manager.UIManager import UIManager
import time

# ========== 配置（从表格填入）==========
BOX1_X, BOX1_Y, BOX1_Z = 5800.359, 88.983, -4587.241  # 神秘宝箱_坐标

# ========== 执行 ==========
transport(BOX1_X, BOX1_Y, BOX1_Z)
time.sleep(2)

hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")), None)
part = hud.get_part(pid)
collect_res = part.collect_multi_res
print("box count:", len(collect_res))

if not collect_res:
    print("no box found - may be already opened or in AOI blind spot")
else:
    r = collect_res[0]
    print("box:", r.get("interact_name"), "behavior_time:", r.get("behavior_time"), "is_long_press:", r.get("is_long_press"))
    part.near_res = r
    part.on_click_collect_down(click_interact_btn=True)
    print("click_down triggered, waiting behavior_time...")
    time.sleep(r.get("behavior_time", 2.0) + 1)
    part.on_click_collect_up(click_interact_btn=True)
    time.sleep(2)

    # 查找 UIRemnantPC
    remnant = None
    for panel_path in BaseApi.get_open_panels():
        if panel_path.startswith("PanelHud."):
            p_obj = hud.get_part(int(panel_path.split(".")[1]))
            if p_obj and type(p_obj).__name__ == "UIRemnantPC":
                remnant = p_obj
                break

    if remnant:
        print("items:", remnant.item_dict)
        remnant.get_all_treasure_box_items()
        time.sleep(1.5)
        print("pickup done")
    else:
        print("UIRemnantPC not found")
```

### 调用 3：打开第二个宝箱（装备箱）

```python
from debug.debug_tool import transport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
from ui.ui_manager.UIManager import UIManager
import time

# ========== 配置（从表格填入）==========
BOX2_X, BOX2_Y, BOX2_Z = 5813.1, 94.5, -4481.8   # 装备箱_坐标

# ========== 执行 ==========
transport(BOX2_X, BOX2_Y, BOX2_Z)
time.sleep(2)

hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")), None)
part = hud.get_part(pid)
collect_res = part.collect_multi_res
print("box count:", len(collect_res))

if not collect_res:
    print("no box found")
else:
    r = collect_res[0]
    print("box:", r.get("interact_name"), "behavior_time:", r.get("behavior_time"))
    part.near_res = r
    part.on_click_collect_down(click_interact_btn=True)
    time.sleep(r.get("behavior_time", 2.0) + 1)
    part.on_click_collect_up(click_interact_btn=True)
    time.sleep(2)

    remnant = None
    for panel_path in BaseApi.get_open_panels():
        if panel_path.startswith("PanelHud."):
            p_obj = hud.get_part(int(panel_path.split(".")[1]))
            if p_obj and type(p_obj).__name__ == "UIRemnantPC":
                remnant = p_obj
                break

    if remnant:
        print("items:", remnant.item_dict)
        remnant.get_all_treasure_box_items()
        time.sleep(1.5)
        print("pickup done")
    else:
        print("UIRemnantPC not found")
```

### 诊断：宝箱找不到时（collect_multi_res 为空）

```python
from debug.debug_tool import transport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
from ui.ui_manager.UIManager import UIManager
import time

# 传送到宝箱坐标后等待更长时间
transport(BOX_X, BOX_Y, BOX_Z)
time.sleep(5)  # 给更长时间让 AOI 感知建立

hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")), None)
part = hud.get_part(pid)
collect_res = part.collect_multi_res
print("collect_multi_res:", collect_res)

# 如果还是空，尝试在附近移动后再查
# 宝箱在建筑内部高处时，sense_range 可能小于 3.0m，需要贴近
# 检查附近可交互物（可能宝箱在更大范围）
nearby = BaseApi.get_nearby_interactables(radius=20.0)
print("world_interactables:", nearby.get("world_interactables"))
```

---

### 简单状态检查模板
```python
from debug.qa_debug.Automation.common.BaseApi import BaseApi

# 获取玩家状态
hp_status = BaseApi.get_hp_status()
pos = BaseApi.get_player_pos()

print(f"血量状态: {hp_status}")
print(f"当前位置: {pos}")
```

### 传送操作模板
```python
from debug.qa_debug.Automation.Tasks.TaskTransport import TaskTransport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import math3d

# 传送到目标坐标
target_pos = math3d.vector(x, y, z)  # 替换为实际坐标
transport_task = TaskTransport(target_pos)

print(f"开始传送到 {target_pos}")
for _ in transport_task:
    pass
print("传送完成")

# 验证到达
current_pos = BaseApi.get_player_pos()
print(f"当前位置: {current_pos}")
```

### 移动操作模板
```python
from debug.qa_debug.Automation.Tasks.TaskMoveTo import TaskMoveTo
import math3d

# 寻路移动到目标
target_pos = math3d.vector(x, y, z)  # 替换为实际坐标
move_task = TaskMoveTo(target_pos=target_pos, stop_threshold=2.0)

print(f"开始移动到 {target_pos}")
for _ in move_task:
    pass
print("移动完成")
```

### UI 交互模板
```python
from debug.qa_debug.Automation.common.BaseApi import BaseApi

# 检查当前开放的面板
panels = BaseApi.get_open_panels()
print(f"当前开放面板: {panels}")

# 检查特定面板是否显示
panel_name = "PanelXxx"  # 替换为实际面板名
if BaseApi.is_ui_showing(panel_name):
    print(f"{panel_name} 正在显示")
else:
    print(f"{panel_name} 未显示")

# 按F交互
BaseApi.open_interact_ui()
print("已按F交互")
```

### 战斗操作模板
```python
from debug.qa_debug.Automation.Tasks.TaskAutoAttack import TaskAutoAttack
from debug.qa_debug.Automation.common.BaseApi import BaseApi

# 设置无敌模式（可选）
BaseApi.set_invincible_level_2()
print("已开启无敌模式")

# 自动攻击
attack_task = TaskAutoAttack()
for _ in attack_task:
    pass
print("攻击完成")
```

### 采集操作模板
```python
from debug.qa_debug.Automation.Tasks.TaskCollect import TaskCollect
import math3d

# 采集指定位置的资源
resource_pos = math3d.vector(x, y, z)  # 替换为资源坐标
collect_task = TaskCollect(target_pos=resource_pos)

print(f"开始采集位置 {resource_pos} 的资源")
for _ in collect_task:
    pass
print("采集完成")
```

### 等待操作模板
```python
from debug.qa_debug.Automation.Tasks.TaskWaitForSeconds import TaskWaitForSeconds
from debug.qa_debug.Automation.Tasks.TaskTimeOut import TimeWaiter

# 方法1: 使用 TaskWaitForSeconds
wait_task = TaskWaitForSeconds(seconds=5.0)
print("开始等待5秒...")
for _ in wait_task:
    pass
print("等待完成")

# 方法2: 使用 TimeWaiter (更常用)
print("开始等待3秒...")
for _ in TimeWaiter(3.0):
    pass
print("等待完成")
```

## 组合模板

### 传送 + 状态检查模板
```python
from debug.qa_debug.Automation.Tasks.TaskTransport import TaskTransport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import math3d

# 1. 传送
target_pos = math3d.vector(x, y, z)
transport_task = TaskTransport(target_pos)

print(f"开始传送到 {target_pos}")
for _ in transport_task:
    pass

# 2. 检查状态
current_pos = BaseApi.get_player_pos()
hp_status = BaseApi.get_hp_status()

print(f"传送完成")
print(f"当前位置: {current_pos}")
print(f"血量状态: {hp_status}")

# 3. 如果血量不足则补血
if hp_status['current_hp'] < hp_status['max_hp']:
    BaseApi.set_healthy()
    print("已回复满血")
```

### 移动 + 交互模板
```python
from debug.qa_debug.Automation.Tasks.TaskMoveTo import TaskMoveTo
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import math3d

# 1. 移动到目标
target_pos = math3d.vector(x, y, z)
move_task = TaskMoveTo(target_pos=target_pos)

print(f"移动到交互点 {target_pos}")
for _ in move_task:
    pass

# 2. 交互
print("开始交互...")
BaseApi.open_interact_ui()

# 3. 等待UI出现并处理
from debug.qa_debug.Automation.Tasks.TaskTimeOut import TimeWaiter
for _ in TimeWaiter(2.0):  # 等待2秒
    pass

# 检查是否有对话选项
options = BaseApi.get_dialog_options()
if options:
    print(f"发现对话选项: {options}")
    # 选择第一个选项
    if len(options) > 0:
        BaseApi.dialog_select_option(options[0])
        print(f"已选择选项: {options[0]}")
```

### 循环采集模板
```python
from debug.qa_debug.Automation.Tasks.TaskMoveTo import TaskMoveTo
from debug.qa_debug.Automation.Tasks.TaskCollect import TaskCollect
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import math3d

# 采集点列表
collect_points = [
    math3d.vector(x1, y1, z1),
    math3d.vector(x2, y2, z2),
    math3d.vector(x3, y3, z3),
]

print(f"开始循环采集，共 {len(collect_points)} 个采集点")

for i, point in enumerate(collect_points):
    print(f"第 {i+1}/{len(collect_points)} 个采集点: {point}")
    
    # 1. 移动到采集点
    move_task = TaskMoveTo(target_pos=point)
    for _ in move_task:
        pass
    
    # 2. 采集
    collect_task = TaskCollect(target_pos=point)
    for _ in collect_task:
        pass
    
    print(f"第 {i+1} 个采集点完成")

print("所有采集点完成")
```

## 错误处理模板

### 带异常处理的完整模板
```python
try:
    from debug.qa_debug.Automation.Tasks.TaskTransport import TaskTransport
    from debug.qa_debug.Automation.common.BaseApi import BaseApi
    import math3d
    
    # 检查前置条件
    from dcs_core.Env import Env
    if not Env.PLAYER_HOLDER:
        raise RuntimeError("玩家未就绪")
    
    # 执行主要逻辑
    target_pos = math3d.vector(x, y, z)
    transport_task = TaskTransport(target_pos)
    
    print(f"开始传送到 {target_pos}")
    for _ in transport_task:
        pass
    
    # 验证结果
    current_pos = BaseApi.get_player_pos()
    distance = (current_pos - target_pos).length
    
    if distance < 10.0:  # 10米容错范围
        print(f"传送成功，距离目标 {distance:.2f} 米")
    else:
        print(f"传送可能失败，距离目标 {distance:.2f} 米")
    
except ImportError as e:
    print(f"导入错误: {e}")
except RuntimeError as e:
    print(f"运行时错误: {e}")
except Exception as e:
    print(f"未知错误: {e}")
```

## 调试辅助模板

### 详细日志模板
```python
import time
from debug.qa_debug.Automation.common.BaseApi import BaseApi

def log_with_timestamp(message):
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

# 开始执行
log_with_timestamp("脚本开始执行")

# 记录初始状态
initial_pos = BaseApi.get_player_pos()
initial_hp = BaseApi.get_hp_status()
log_with_timestamp(f"初始位置: {initial_pos}")
log_with_timestamp(f"初始血量: {initial_hp}")

# 执行具体操作（在这里添加你的代码）
# ...

# 记录结束状态
final_pos = BaseApi.get_player_pos()
final_hp = BaseApi.get_hp_status()
log_with_timestamp(f"结束位置: {final_pos}")
log_with_timestamp(f"结束血量: {final_hp}")

log_with_timestamp("脚本执行完成")
```