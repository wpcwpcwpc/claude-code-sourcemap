# MCP 工具使用指南

## 可用的 MCP 工具

### repl_execute - Python 代码执行
**功能**: 在游戏进程内执行 Python 代码
```python
use_mcp_tool("game_debug_mcp", "repl_execute", {
    "code": "print('Hello from game process!')"
})
```

### send_gm_cmd - 原始 GM 指令
**功能**: 发送原始 GM 指令字符串
```python
use_mcp_tool("game_debug_mcp", "send_gm_cmd", {
    "cmd": "%add_item(10001, 100)"
})
```

### call_gm_command - 结构化 GM 调用
**功能**: 通过指令名和参数 JSON 调用 GM 指令
```python
use_mcp_tool("game_debug_mcp", "call_gm_command", {
    "name": "tp_to_pos",
    "params_json": '{"x": 1000, "y": 0, "z": 1000}'
})
```

### search_gm_by_intent - 智能指令搜索
**功能**: 通过自然语言描述搜索 GM 指令
```python
use_mcp_tool("game_debug_mcp", "search_gm_by_intent", {
    "intent": "传送到指定坐标"
})
```

### list_gm_commands - 指令列表查询
**功能**: 按分类和关键字搜索 GM 指令
```python
use_mcp_tool("game_debug_mcp", "list_gm_commands", {
    "category": "常用",
    "keyword": "传送"
})
```

### repl_namespace - 查看变量空间
**功能**: 获取当前 REPL 会话中的所有变量
```python
use_mcp_tool("game_debug_mcp", "repl_namespace", {})
```

### repl_history - 执行历史
**功能**: 获取最近的 REPL 执行历史
```python
use_mcp_tool("game_debug_mcp", "repl_history", {"limit": 10})
```

### repl_describe - 对象描述
**功能**: 获取对象的结构化描述，用于探索游戏对象
```python
use_mcp_tool("game_debug_mcp", "repl_describe", {
    "expr": "BigWorld.player()",
    "max_depth": 2
})
```

### repl_reset - 重置会话
**功能**: 重置 REPL 会话，清空所有变量和历史
```python
use_mcp_tool("game_debug_mcp", "repl_reset", {})
```

## MCP 自动化执行模式

### 模式 1: 简单脚本执行
适用于单步操作或简单的状态检查：

```python
script = '''
from debug.qa_debug.Automation.common.BaseApi import BaseApi
hp_status = BaseApi.get_hp_status()
print(f"当前血量: {hp_status}")
'''

use_mcp_tool("game_debug_mcp", "repl_execute", {"code": script})
```

### 模式 2: 分步协程执行
适用于需要时间的移动、战斗等操作：

```python
# Step 1: 定义任务类
setup_script = '''
from debug.qa_debug.Automation.Tasks.TaskTransport import TaskTransport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import math3d

class MCPTransportTask:
    def __init__(self, target_pos):
        self.target_pos = target_pos
        self.task = None
        
    def execute(self):
        print(f"开始传送到 {self.target_pos}")
        self.task = TaskTransport(self.target_pos)
        for _ in self.task:
            pass
        print("传送完成")
        
        # 验证结果
        current_pos = BaseApi.get_player_pos()
        print(f"当前位置: {current_pos}")

# 实例化任务
transport_task = MCPTransportTask(math3d.vector(1000, 50, 2000))
'''

# Step 2: 执行任务
execute_script = '''
transport_task.execute()
'''

# 分别执行
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": setup_script})
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": execute_script})
```

### 模式 3: 结合 GM 指令
先用 GM 设置状态，再执行自动化：

```python
# 1. 通过 GM 设置无敌
use_mcp_tool("game_debug_mcp", "call_gm_command", {
    "name": "swtich_wd", 
    "params_json": "{}"
})

# 2. 执行自动化脚本
script = '''
from debug.qa_debug.Automation.Tasks.TaskMoveTo import TaskMoveTo
import math3d

# 移动到危险区域（已经无敌了）
move_task = TaskMoveTo(target_pos=math3d.vector(5000, 100, 5000))
for _ in move_task:
    pass

print("已安全移动到危险区域")
'''

use_mcp_tool("game_debug_mcp", "repl_execute", {"code": script})
```

## 最佳实践

### 1. 错误处理
```python
script = '''
try:
    from debug.qa_debug.Automation.common.BaseApi import BaseApi
    result = BaseApi.get_hp_status()
    print(f"成功: {result}")
except Exception as e:
    print(f"错误: {e}")
'''
```

### 2. 状态检查
在执行重要操作前先检查游戏状态：

```python
pre_check = '''
from dcs_core.Env import Env
if not Env.PLAYER_HOLDER:
    print("玩家未就绪，请稍后再试")
else:
    print("玩家就绪，可以执行自动化")
'''
```

### 3. 分步反馈
对于长时间任务，提供分步进度反馈：

```python
script = '''
print("第1步: 开始传送...")
# 传送代码
print("第2步: 检查到达状态...")
# 验证代码  
print("第3步: 执行完成")
'''
```