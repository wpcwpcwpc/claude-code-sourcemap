---
name: mcp-runner
description: H73游戏MCP自动化脚本生成与执行助手。通过MCP服务器的repl_execute在游戏进程内直接执行自动化脚本，替代Hunter远程执行方案。当用户描述想要自动化的游戏操作（如移动、战斗、UI交互、传送、世界石解锁、收集、验证状态等），根据 debug/qa_debug/Automation 目录下已有的 Case、Task 和 BaseApi，智能组合拼接出可运行的 Python 自动化脚本并通过MCP直接执行。触发词：mcp执行、mcp自动化、生成并执行脚本、mcp运行用例、游戏内执行、通过mcp执行。
---

# MCP Runner - 游戏内自动化执行助手

## 核心优势

**MCP vs Hunter 对比：**
- ✅ **MCP**: 直接在游戏进程内执行，无网络延迟，执行稳定
- ❌ **Hunter**: 需要网络连接，可能有延迟和连接问题
- ✅ **MCP**: 原生访问游戏对象和API，性能最优
- ❌ **Hunter**: 通过RPC调用，有额外开销

## 核心工作流

1. **理解用户意图** - 明确自动化目标和验证条件
2. **分析现有资源** - 查找可复用的 Case、Task、BaseApi 方法  
3. **生成执行脚本** - 基于已有积木块智能组合拼装
4. **MCP直接执行** - 通过 `repl_execute` 在游戏进程内运行
5. **实时反馈结果** - 输出执行状态和验证结果

## MCP 执行模式

> **强制要求**：所有脚本必须通过 `game_debug_mcp` 的 `repl_execute` 工具执行，不得使用其他 MCP server 或 Hunter 方案。`game_debug_mcp` 地址为 `http://127.0.0.1:19836/mcp`，已确认在线可用。

### 脚本生成原则
基于 `qa-debug-automation` skill 的架构，复用已有的自动化积木块：

```python
# 标准模板结构
# encoding: utf-8
from dcs_core.Env import Env
from debug.qa_debug.Automation.Tasks.TaskBase import TaskBase
# ... 根据需求导入具体 Task 类

class MCPAutoCase(TaskBase):
    def tick(self):
        while not Env.PLAYER_HOLDER:  # 等待玩家就绪
            yield
        
        # Step 1: 执行具体操作
        # Step 2: 验证结果
        # Step 3: 完成任务
        self._finish()

# 直接在MCP中执行
case = MCPAutoCase()
for _ in case:
    pass  # 协程执行完成
```

### MCP 执行接口

**必须使用 `game_debug_mcp` 执行所有脚本，调用方式如下：**

```python
# ✅ 引擎 API / UI / ECS 操作：必须加 main_thread=True，在游戏主线程执行
use_mcp_tool("game_debug_mcp", "repl_execute", {
    "code": "from debug.debug_tool import transport\ntransport(7313.1, 85.9, -5362.6)",
    "main_thread": True
})

# ✅ 纯 Python 只读查询（不涉及引擎对象）：可省略 main_thread（默认 False，后台线程执行）
use_mcp_tool("game_debug_mcp", "repl_execute", {
    "code": "print(len(some_list))"
})

# ✅ GM 指令同样必须通过 game_debug_mcp
use_mcp_tool("game_debug_mcp", "call_gm_command", {
    "name": "指令名",
    "params_json": "{}"
})

# ❌ 禁止：不得使用其他 MCP server 或 Hunter 方案
```

**`main_thread` 参数选择规则：**

| 代码类型 | main_thread | 原因 |
|---------|-------------|------|
| `transport`、`on_key_event`、`BaseApi.*`、`UIManager.*`、ECS 组件操作 | `True` | 引擎 API 线程不安全，必须在主线程执行 |
| `ClientAvatar`、`get_world_stone_state` 等游戏实体查询 | `True` | 访问游戏对象，需主线程 |
| `print`、纯 Python 计算、`import sys` 等 | `False`（默认） | 无引擎依赖，后台线程即可 |

> **原则：凡是 `import game`、`from debug.*`、`from ui.*`、`from entities.*` 的代码，一律加 `main_thread=True`。**

**`game_debug_mcp` 可用工具一览：**

| 工具 | 用途 |
|------|------|
| `repl_execute` | 在游戏进程内执行 Python 代码（主力工具），`main_thread=True` 调度到游戏主线程 |
| `call_gm_command` | 通过指令名 + 参数 JSON 执行 GM 指令 |
| `send_gm_cmd` | 发送原始 GM 指令字符串 |
| `search_gm_by_intent` | 自然语言搜索匹配 GM 指令 |
| `list_gm_commands` | 按分类/关键字列出 GM 指令 |
| `list_gm_categories` | 列出所有 GM 指令分类 |
| `repl_namespace` | 查看 REPL 会话当前变量 |
| `repl_history` | 查看 REPL 执行历史 |
| `repl_reset` | 重置 REPL 会话 |
| `repl_describe` | 获取游戏对象结构描述 |

**执行优势：**
- 🔥 **实时执行** - 无需文件保存，直接在游戏内运行
- 🎯 **状态同步** - 变量和对象状态在 REPL 会话中保持
- 🛠️ **调试友好** - 支持分步执行和状态检查
- ⚡ **高性能** - 直接访问游戏对象，无额外开销

## 已验证的常用模块路径

> 以下模块路径均经过游戏进程内实际 import 验证，可直接使用。

```python
# UI 管理器（正确路径）
from ui.ui_manager.UIManager import UIManager          # ✅ 已验证
# ❌ from neox.engine.uisystem.UIManager import UIManager  # 报错：neox 不是 package
# ❌ from ui.UIManager import UIManager                    # 报错：无此模块

# InteractHud 交互部件
from ui.main_ui_part.InteractHudPartItemNew import InteractHudPartItemNewPC  # ✅

# UIRemnant 掉落物/残留物面板
from ui.main_ui_part.UIRemnant import UIRemnantPC  # ✅

# 传送（快速，推荐优先使用）
from debug.debug_tool import transport             # ✅ 比 TaskTransport 更快
transport(x, y, z)

# 查找 UIManager 正确路径的通用方法
import sys
[k for k in sys.modules if 'uimanager' in k.lower()]  # 动态查找
```

## 常用自动化模式

### 移动 & 传送
```python
# ✅ 推荐：debug_tool.transport（快速，无加载等待）
# 调用 1：执行传送
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from debug.debug_tool import transport
transport(6730.2, 57.0, -5720.2)
print("transport done")
""", "main_thread": True})
time.sleep(6)  # 本地等待场景加载（on_scene_loading_change:False）

# 调用 2：执行传送后的操作
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": "...", "main_thread": True})

# TaskMoveTo 正确签名：(start_point, end_point, stop_threshold)
# ⚠️ end_point 必须传列表 [x,y,z]，不能传 math3d.vector（源码 while 循环内有下标访问 bug）
# ⚠️ TaskMoveTo 在 repl_execute 内同步阻塞，路程远会超时，优先用 transport 替代
```

### 状态检查 & 设置
```python
from debug.qa_debug.Automation.common.BaseApi import BaseApi
hp_status = BaseApi.get_hp_status()
pos = BaseApi.get_player_pos()
BaseApi.set_healthy()           # 满血满水
BaseApi.set_invincible_level_2() # 无敌模式
```

### 查询附近可交互物件
```python
from debug.qa_debug.Automation.common.BaseApi import BaseApi

# 查附近世界交互物（宝箱/采集点等实体）
nearby = BaseApi.get_nearby_interactables(radius=8.0)
print(nearby["world_interactables"])   # 宝箱/场景物件会出现在这里
print(nearby["nearest_world_interactable"])

# ⚠️ 宝箱/装备箱不一定出现在 world_interactables
# 真正的交互数据在 InteractHudPartItemNewPC.collect_multi_res 里
# 用以下方式获取：
from ui.ui_manager.UIManager import UIManager
hud = UIManager.panels.get("PanelHud")
part = hud.get_part(109)  # part_id 每次会话可能变化，用 get_interact_prompts 动态获取
print(part.collect_multi_res)  # 包含 interact_name, is_long_press, res_type 等完整信息
```

### 动态获取 InteractHudPart 的 part_id
```python
# ⚠️ InteractHudPart 的 part_id 每次游戏会话不固定，必须动态查询
from debug.qa_debug.Automation.common.BaseApi import BaseApi
prompts = BaseApi.get_interact_prompts()
interact_part_id = None
for p in prompts["prompts"]:
    if "InteractHud" in p.get("object_type", ""):
        interact_part_id = p["part_id"]
        break
print("InteractHud part_id:", interact_part_id)
```

### 世界石解锁完整流程（已验证）

> 适用于：聚落探索解锁世界石，`res_type=15`，`interact_ui_type='UIWorldStonePrompt'`
>
> ⚠️ **`on_key_event` 可在 repl_execute 中调用（实测不崩溃）。**
> 上次 Dump（`UIGraphic::UpdateVisibleState` / `uigraphic.cpp:741`）是**场景加载期间**（`on_scene_loading_change:True` / `run gm command timeout`）触发 F 键导致的时序问题。
> **必须等场景加载完成后再触发 F 键。**

```python
# === 推荐方式 A：run_case（自动处理移动 + 场景状态检测）===
from debug.qa_debug.Automation.main import run_case
run_case(cases=['CaseUnlockWorldStone'])
# run_case 立即返回，Case 在主线程协程帧循环中异步执行
```

```python
# 本地等待后，调用 2：轮询验证状态并截图
from entities.ClientAvatar import ClientAvatar
from debug.qa_debug.Automation.common.BaseApi import BaseApi
state = ClientAvatar.get_instance().get_world_stone_state(10101)
print("state:", state)  # WorldStoneState.ACTIVATED = 解锁成功
BaseApi.screenshot("QA/settlement/T1_A/01_worldstone_unlocked.png")
```

```python
# === 方式 B：直接按 F 键（拆分为多次调用，sleep 在本地）===

# 调用 1：传送
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from debug.debug_tool import transport
from neox_editor.EditorInput import on_key_event
from entities.ClientAvatar import ClientAvatar
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import game
transport(7313.1, 85.9, -5362.6)
print("transport done")
""", "main_thread": True})
time.sleep(6)  # 本地等待场景加载完成（on_scene_loading_change:False）

# 调用 2：按下 F 键
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from neox_editor.EditorInput import on_key_event
import game
on_key_event(game.MSG_KEY_DOWN, game.VK_F)
print("F key down")
""", "main_thread": True})
time.sleep(2)  # 本地等待按键响应

# 调用 3：抬起 F 键
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from neox_editor.EditorInput import on_key_event
import game
on_key_event(game.MSG_KEY_UP, game.VK_F)
print("F key up")
""", "main_thread": True})
time.sleep(3)  # 本地等待服务端响应

# 调用 4：验证状态并截图
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from entities.ClientAvatar import ClientAvatar
from debug.qa_debug.Automation.common.BaseApi import BaseApi
state = ClientAvatar.get_instance().get_world_stone_state(10201)
print("stone state:", state)
BaseApi.screenshot("QA/settlement/T1_B/01_worldstone.png")
""", "main_thread": True})```

**世界石编号查询（通过 WorldStoneHelper）：**
```python
import game_common.helper.WorldStoneHelper as wsh
# ⚠️ 不要用 get_world_stone_no_by_name()，其参数是显示名，不是 global_name
target_global = "scene_openworld_07E70403-1205003A-53827A3B-6E88111E_anchor_worldstone"
for k, v in wsh.world_stone_data.items():
    if v.get('global_name') == target_global:
        print("stone_no:", k, "name:", v.get('name'))
        break
# 输出示例: stone_no: 10101  name: 世界石·望岛镇
```

**解锁状态说明：**
- `WorldStoneState.ACTIVATED` → 已解锁（通过 `avt.get_world_stone_state(stone_no)` 查询）
- `collect_multi_res[0].exec_state == "003"` → 客户端缓存显示已解锁（可能滞后于服务端）
- `collect_multi_res[0].exec_state == "002"` → 未解锁（可交互）
- `collect_multi_res` 为空 → 不在 AOI 范围，或 `handle_interact_info` 被错误调用导致 res 消失（≠解锁成功）

### 宝箱 / 装备箱完整交互流程（已验证）

> 适用于：装备箱（iron_box）、武器箱、补给箱等 `res_type=10` 类型，`is_long_press=True`
>
> ⚠️ **宝箱有冷却机制**：`interact_cooldown=5.0`，打开后会从 `collect_multi_res` 中消失。若传送到坐标后 `collect_multi_res` 为空，说明宝箱已被打开或不在感知范围内（建筑内部可能有 AOI 盲区）。

```python
# === 宝箱完整交互流程（拆分为多次调用，sleep 在本地）===

# 调用 1：传送到宝箱坐标
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from debug.debug_tool import transport
transport(6730.2, 57.0, -5720.2)
print("transport done")
""", "main_thread": True})
time.sleep(5)  # 本地等待场景加载 + AOI 感知建立

# 调用 2：检测宝箱并触发长按
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from ui.ui_manager.UIManager import UIManager
from debug.qa_debug.Automation.common.BaseApi import BaseApi
hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
interact_part_id = next(
    (p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")),
    None
)
part = hud.get_part(interact_part_id)
collect_res = part.collect_multi_res
if not collect_res:
    print("NOT_FOUND")
else:
    behavior_time = collect_res[0].get("behavior_time", 2.0)
    print("box:", collect_res[0].get("interact_name"), "behavior_time:", behavior_time)
    part.near_res = collect_res[0]
    part.on_click_collect_down(click_interact_btn=True)
    print("LONG_PRESS_START")
""", "main_thread": True})
time.sleep(3)  # 本地等待 behavior_time（通常 2.0s）+ 余量

# 调用 3：释放长按
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from ui.ui_manager.UIManager import UIManager
from debug.qa_debug.Automation.common.BaseApi import BaseApi
hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")), None)
part = hud.get_part(pid)
part.on_click_collect_up(click_interact_btn=True)
print("LONG_PRESS_END")
""", "main_thread": True})
time.sleep(2)  # 本地等待服务端响应，UIRemnantPC 出现

# 调用 4：找 UIRemnantPC 并全部拾取
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
from ui.ui_manager.UIManager import UIManager
from debug.qa_debug.Automation.common.BaseApi import BaseApi
hud = UIManager.panels.get("PanelHud")
remnant = None
for panel_path in BaseApi.get_open_panels():
    if panel_path.startswith("PanelHud."):
        pid = int(panel_path.split(".")[1])
        p_obj = hud.get_part(pid)
        if p_obj and type(p_obj).__name__ == "UIRemnantPC":
            remnant = p_obj
            break
if remnant:
    print("items:", remnant.item_dict)
    remnant.get_all_treasure_box_items()
    print("PICKUP_DONE")
    BaseApi.screenshot("QA/box/box_opened.png")
else:
    print("UIRemnantPC NOT FOUND")
""", "main_thread": True})```

### UI 面板新面板检测（通用）
```python
# 检测新弹出的非 HUD 常驻面板
BASE_PANELS = {"PanelDebugBtn","PanelFlapNumber","PanelNoviceGuide","PanelToast",
               "PanelSceneRoot","PanelNoticeToast","PanelHud","PanelCharPlaneWarning",
               "PanelUid","PanelTraceBack"}
new_panels = [p for p in BaseApi.get_open_panels()
              if p not in BASE_PANELS and not p.startswith("PanelHud.")]
```

## 已知陷阱与修正

| 场景 | 错误做法 | 正确做法 |
|------|---------|---------|
| `TaskMoveTo` 参数 | `TaskMoveTo(target_pos=vec)` | `TaskMoveTo(start_list, end_list, threshold)` |
| `TaskMoveTo` end_point 类型 | 传 `math3d.vector` | 传 `[x, y, z]` 列表（源码 while 循环有下标访问） |
| UIManager import | `from neox.engine.uisystem.UIManager` | `from ui.ui_manager.UIManager import UIManager` |
| InteractHudPart part_id | 硬编码 `109` | 通过 `BaseApi.get_interact_prompts()` 动态查询 |
| `get_current_interact_target()` | 依赖此 API 查宝箱 | 改用 `part.collect_multi_res`（需 `dcs_game_interact` 模块缺失） |
| 宝箱触发方式 | `BaseApi.open_interact_ui()` 或 `trigger_specific_key_event("do_open_treasure_box")` | `part.near_res = collect_res; part.on_click_collect_down(True)` |
| 世界石触发方式 | `on_key_event` 在场景加载期间调用，或未加 `main_thread=True` | 必须等场景加载完成后触发 F 键；所有引擎 API 必须加 `main_thread=True`，否则在后台线程调用引擎对象会崩溃 |
| 世界石 res_type | 以为与宝箱相同（10） | 世界石为 `res_type=15`，`behavior_time=0`，无 `long_press_interact_func` 字段 |
| 世界石解锁验证 | 检查 `exec_state` 是否变为 `"003"`，或 `collect_multi_res` 变空 | **正确方式**：`avt.get_world_stone_state(stone_no) == WorldStoneState.ACTIVATED`；`collect_multi_res` 变空可能是 `handle_interact_info` 副作用，≠ 解锁成功 |
| 世界石编号查询 | 用 `wsh.get_world_stone_no_by_name(name)` 直接查 | 参数是显示名非 global_name；正确方式：遍历 `wsh.world_stone_data`，匹配 `v.get('global_name') == target_global` |
| `time.sleep()` 写在 code 里 | `code` 字符串中使用 `time.sleep()` 或 `import time` | **严禁**：sleep 在主线程内阻塞游戏帧循环，必须拆成多次调用，sleep 写在两次调用之间（本地执行） |
| 传送后立即操作 | 同一个 code 里 `transport()` 后直接操作 | 拆两次调用：第1次 transport，本地 sleep 6s 等场景加载，第2次执行后续操作 |
| 宝箱解锁后装备位置 | 以为弹出独立面板 | 以 `UIRemnantPC` HUD Part 形式出现 |
| `get_all_treasure_box_items` 调用 | 不需要参数 | `remnant.get_all_treasure_box_items()` 直接调用 |
| 宝箱找不到（空 collect_multi_res） | 以为脚本出错 | 宝箱有冷却（`interact_cooldown=5.0`），打开后从感知列表消失；高度坐标（Y 较高）的宝箱可能在建筑内 AOI 盲区 |
| MCP HTTP 请求中文字符 | 在 `code` 字符串中直接写中文注释 | curl 发请求时中文被 GBK 编码，服务端 UTF-8 解码报错；所有注释改为英文或去掉 |
| `process_click_interact_btn` 调用 | `part.process_click_interact_btn()` | 需传 `interact_info` 参数：`part.process_click_interact_btn(res)` |
| `on_click_btn_interact_down` 调用 | `part.on_click_btn_interact_down()` | 需传 `click_recognizer` 和 `e` 两个参数（通常不用此方法） |
| `trigger_specific_key_event` 调用 | `BaseApi.trigger_specific_key_event("do_interact")` | 需传 `part_key` 和 `method_name` 两个参数 |

## MCP repl_execute 执行规范（强制）

> `repl_execute` 默认（`main_thread=False`）在 MCP 后台线程执行，**不在游戏主线程**。
> 引擎 API（render、BaseApi、ECS 组件、UIManager、on_key_event 等）是线程不安全的，
> 必须传 `main_thread=True` 调度到游戏主线程执行，否则会崩溃或产生未定义行为。
> 此外，`time.sleep()` 写在 code 里即便在主线程也会阻塞游戏帧循环。

### 强制规则

**❌ 禁止在 `code` 字符串中使用 `time.sleep()`**
**❌ 禁止在 `code` 字符串中 `import time`（防止误用）**
**✅ 引擎 API 调用必须加 `"main_thread": True`**
**✅ 所有等待必须在两次 `repl_execute` 调用之间，在本地（调用方侧）执行**

```python
# ❌ 错误示例 1：缺少 main_thread=True，引擎 API 在后台线程执行，会崩溃
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": "transport(7313.1, 85.9, -5362.6)"})

# ❌ 错误示例 2：sleep 写在 code 里，阻塞游戏主线程帧循环
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": """
transport(7313.1, 85.9, -5362.6)
time.sleep(6)           # 阻塞帧循环 6 秒，严禁！
on_key_event(...)
time.sleep(2)           # 严禁！
""", "main_thread": True})

# ✅ 正确：加 main_thread=True，sleep 拆到本地两次调用之间
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": "transport(7313.1, 85.9, -5362.6)", "main_thread": True})
time.sleep(6)   # 本地等待场景加载，游戏主线程正常运行帧循环
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": "on_key_event(game.MSG_KEY_DOWN, game.VK_F)", "main_thread": True})
time.sleep(2)   # 本地等待按键响应
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": "on_key_event(game.MSG_KEY_UP, game.VK_F)", "main_thread": True})
time.sleep(3)   # 本地等待服务端响应
use_mcp_tool("game_debug_mcp", "repl_execute", {"code": "print(avt.get_world_stone_state(10201))", "main_thread": True})
```

### 拆分原则

| 需要等待的场景 | 拆分方式 |
|--------------|---------|
| 传送后等场景加载 | 第1次调用执行 `transport`，本地 sleep 6s，第2次调用执行后续操作 |
| 宝箱长按 CD（behavior_time） | 第1次调用触发 `on_click_collect_down`，本地 sleep behavior_time+1s，第2次调用执行 `on_click_collect_up` |
| 按键后等服务端响应 | 按键调用结束后，本地 sleep 2~3s，再发第2次调用验证状态 |
| 等待 UI 面板出现 | 本地 sleep 后，调用 `BaseApi.get_open_panels()` 轮询 |

- 单次调用内**禁止使用 `for _ in TaskPressFUnitlPanelShow(): pass`**（协程帧循环时长不可控）
- 协程任务（`TaskMoveTo` 等）在 repl_execute 内同步阻塞，路程远会超时，改用 `transport` 传送替代
- 单次 `repl_execute` 内执行时长应控制在 **5 秒以内**（不含本地 sleep）

## 资源引用

详细的 Task 用法和 BaseApi 方法参考复用 `qa-debug-automation` skill:

- **Task 积木块速查**: 见 qa-debug-automation references/tasks.md
- **BaseApi 方法大全**: 见 qa-debug-automation references/base_api.md
- **已有 Cases 参考**: 见 qa-debug-automation references/cases.md

## 关键特性

- **零配置执行** - 无需 Hunter 连接，直接在游戏进程运行
- **积木化组装** - 复用现有 Task/Case/BaseApi 架构
- **实时反馈** - 执行结果立即可见，支持调试
- **协程友好** - 保持原有 yield 协程执行模型
- **状态持久** - REPL 会话保持变量和对象状态
