---
name: qa-debug-automation
description: H73游戏QA自动化脚本生成助手。当用户描述想要自动化的游戏操作（如移动、战斗、UI交互、传送、世界石解锁、收集、验证状态等），根据 debug/qa_debug/Automation 目录下已有的 Case、Task 和 BaseApi，以及 debug_tool、fast_debug、GMCommon 等调试模块，智能组合拼接出可运行的 Python 自动化脚本。支持通过 Hunter2 平台远程推送并执行脚本。触发词：写自动化用例、生成自动化脚本、帮我写一个Case、自动化测试、QA用例、hunter执行、hunter运行、hunter发脚本、GM指令、debug_tool、fast_debug。
---

# QA Debug Automation 脚本生成助手

## 架构概览

```
G:/trunk/client/script/
├── debug_tool.py                          # 根级：Entity查询/Avatar/性能分析（服务端风格）
└── debug/
    ├── debug_tool.py                      # 客户端：Entity代理/UI/动画/碰撞调试
    ├── debug_methods/
    │   ├── GMCommon.py                    # 调试面板 GM 快捷命令（call_gm_cmd 封装）
    │   └── GMHunter.py                    # Hunter 连接切换
    └── qa_debug/
        └── Automation/
            ├── Cases/                     # 独立完整用例（继承 TaskBase，实现 tick()）
            ├── SmokeTestCases/            # 冒烟测试用例集
            ├── Tasks/                     # 可复用原子任务积木块
            └── common/
                └── BaseApi.py             # 底层 API（玩家属性、摄像机、物品、UI等）
```

**核心执行模型：**
- 所有任务/用例都是 Python 生成器（`yield` 协程），每帧推进一次
- `TaskBase.logic()` 每帧调用一次，`self._finish()` 结束任务
- 用例继承 `TaskBase`，在 `tick()` 中用 `yield` 分帧等待，用 `for _ in SomeTask(): yield` 串联子任务

## 用例编写模板

```python
# encoding: utf-8
from dcs_core.Env import Env
from debug.qa_debug.Automation.Tasks.TaskBase import TaskBase
# ... 其他 import

class CaseXxx(TaskBase):
    def tick(self):
        while not Env.PLAYER_HOLDER:  # 前置等待
            yield
        # Step 1: 传送到目标
        for _ in TaskTransport(math3d.vector(x, y, z)):
            yield
        # Step 2: 执行操作
        BaseApi.set_healthy()
        yield
        # Step 3: 验证
        assert some_condition
        self._finish()
```

## 常用 Task 积木块速查

详细用法见 [references/tasks.md](references/tasks.md)。

| Task 类 | import 路径 | 用途 | 关键参数 |
|---------|------------|------|---------|
| `TaskTransport` | `Tasks.TaskTransport` | 传送到坐标（含加载等待） | `pos: vector`, `euler: vector` |
| `TaskTransportStable` | `Tasks.TaskTransport` | 稳定传送（传送两次防穿地） | `pos`, `euler`, `tolerance=2` |
| `TaskMoveTo` | `Tasks.TaskMoveTo` | 寻路移动到目标点 | `start_point: list`, `end_point: list`, `stop_threshold: float` |
| `TaskWaitForSeconds` | `Tasks.TaskWaitForSeconds` | 等待N秒 | `seconds: float` |
| `TaskWaitForLoad` | `Tasks.TaskWaitForLoad` | 等待场景加载完成 | — |
| `TaskWaitForCondition` | `Tasks.SmokeTestTask.TaskWaitForCondition` | 等待条件满足 | `condition: lambda`, `timeout` |
| `TaskAutoMove` | `Tasks.SmokeTestTask.TaskAutoMove` | AUTO_MOVE寻路 | `target_pos`, `stop_distance` |
| `TaskJump` | `Tasks.TaskJump` | 跳跃 | — |
| `TaskWhile` | `Tasks.TaskWhile` | 循环直到条件 | `condition: lambda`, `task` |
| `TaskPressFUnitlPanelShow` | `Tasks.TaskPressFUntilPanelShow` | 长按F直到Panel出现 | `panel_name` |
| `TaskCollect` | `Tasks.TaskCollect` | 采集目标资源 | `target_pos` |
| `TaskCollectWater` | `Tasks.TaskCollectWater` | 收集水 | — |
| `TaskAutoAttack` | `Tasks.TaskAutoAttack` | 自动近战攻击 | — |
| `TaskKillNearMonsterUsingGun` | `Tasks.TaskKillNearMonsterUsingGun` | 击杀附近怪物 | — |
| `TaskEquipWeaponAndMod` | `Tasks.TaskEquipWeaponAndMod` | 装备武器和模组 | `weapon_id` |
| `TaskLogin` | `Tasks.TaskLogin` | 登录流程 | `account`, `password` |
| `TaskCreateMonster` | `Tasks.TaskCreateMonster` | GM创建怪物 | `monster_id`, `pos` |
| `TaskTimeOut` | `Tasks.TaskTimeOut` | 超时计时器 | `timeout_sec` |
| `TimeWaiter` | `Tasks.TaskTimeOut` | 分帧等待N秒（for循环内用） | `seconds` |

## BaseApi 常用方法

详细 API 见 [references/base_api.md](references/base_api.md)。

### 感知层（只读查询，用于 Hunter 闭环 check_fn）

> 完整感知层说明及 UI Panel 操作层见 [references/base_api.md](references/base_api.md)。

**玩家状态感知：**
```python
BaseApi.get_player_pos()         # 坐标 → vector（hunter 中须转 [pos.x, pos.y, pos.z]）
BaseApi.get_hp()                 # 当前血量 → float
BaseApi.get_max_hp()             # 最大血量 → float（取决于角色等级/配置）
BaseApi.get_hp_percentage()      # 血量百分比 → float 0~100
BaseApi.get_hp_status()          # 详细血量状态 → dict
                                 # {current_hp, max_hp, percentage,
                                 #  is_full_health, is_low_health, is_critical, missing_hp}
BaseApi.get_water()              # 当前水值 → float
BaseApi.get_food()               # 当前食物值 → float
BaseApi.get_san()                # 当前理智值 → float
BaseApi.is_alive()               # 是否存活 → bool（验证 set_healthy() 生效的推荐方式）
```

**UI 面板状态感知：**
```python
BaseApi.is_ui_showing('PanelXxx')               # Panel 是否显示 → bool
BaseApi.get_open_panels()                        # 所有已显示 Panel 列表 → list[str]
                                                 # PanelHud 会展开活动 Part："PanelHud.PartName"
BaseApi.get_panel_parts('PanelHud')              # 指定面板的活动 Part 列表 → list
BaseApi.is_panel_part_active('PanelHud', 'PartName')  # 指定 Part 是否活动 → bool
BaseApi.get_ui_text('PanelDialog', 'label_title')     # 指定控件文本 → str
BaseApi.get_dialog_type()                        # 对话类型 → '对话'|'提示'|None
BaseApi.get_dialog_options()                     # 对话选项 → list[str]
BaseApi.get_dialog_text()                        # 对话文本 → dict {'title','content'}
BaseApi.get_scene()                              # 场景类型 → str
```

**任务状态感知：**
```python
BaseApi.get_cur_task_name()         # 当前任务名 → str
BaseApi.get_cur_track_trigger()     # 当前任务 trigger ID → int/str
BaseApi.get_cur_task_pos()          # 任务目标坐标列表 → [vector,...]（需转换）
```

**⚠️ 仍缺失：**

| 函数签名 | 用途 | 返回类型 | 备注 |
|---------|------|----------|------|
| `get_case_status(case_name)` | Case 执行状态（main 模块） | `str` | — |
| `get_current_interact_target()` | 当前交互目标 | `dict` | 依赖 `dcs_game_interact`，实测报错，改用 `InteractHudPartItemNewPC.collect_multi_res` |

### 写操作（状态设置）

```python
BaseApi.set_healthy()               # 满血+满水+满食物+复活
BaseApi.set_hp(10000)               # 设置血量
BaseApi.set_water(10000)            # 补满水值
BaseApi.set_food(10000)             # 补满食物
BaseApi.set_invincible_level_2()    # 无敌（无受击）
BaseApi.revive()                    # 复活
BaseApi.add_money(coin_type, num)   # 添加货币
BaseApi.add_item(item_id, count)    # 添加物品
```

**位置 & 传送**
```python
BaseApi.transport(x, y, z)          # 传送（低层）
BaseApi.teleport_player(x, y, z)    # 传送（GM指令）

# ✅ 推荐优先使用 debug_tool.transport（更快，无加载等待）
from debug.debug_tool import transport
transport(x, y, z)
```

**交互目标查询（宝箱/装备箱场景必读）**
```python
# ⚠️ get_current_interact_target() 依赖 dcs_game_interact 模块，实测报错
# ✅ 改用以下方式获取当前交互目标数据：

# 方式1：通过 InteractHudPartItemNewPC.collect_multi_res（最完整）
# part_id 每次会话不固定，先动态查询
prompts = BaseApi.get_interact_prompts()
interact_part_id = next(
    (p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")),
    None
)
from ui.ui_manager.UIManager import UIManager
hud = UIManager.panels.get("PanelHud")
part = hud.get_part(interact_part_id)
collect_res_list = part.collect_multi_res
# 每个 collect_res 包含：interact_name, is_long_press, res_type, use_behavior_progress 等

# 方式2：BaseApi.get_nearby_interactables(radius=8.0)（世界实体，宝箱可能不在此列）
nearby = BaseApi.get_nearby_interactables(radius=8.0)
```

**朝向 & 摄像机**
```python
BaseApi.set_char_euler_on_client(yaw)           # 设置角色朝向（不动摄像机）
BaseApi.set_camera_euler(x, y, z)               # 设置摄像机朝向
BaseApi.set_collection_camera(target_pos)       # 摄像机对准目标点
```

**UI**
```python
BaseApi.open_interact_ui()                      # 按 F 交互
BaseApi.get_dialog_options()                    # 获取对话选项列表
BaseApi.dialog_select_option("选项文字")        # 选择对话选项
BaseApi.is_ui_showing("PanelXxx")               # 检查 UI 是否显示
BaseApi.show_hint("文字")                       # 显示提示
```

**任务系统**
```python
BaseApi.get_cur_task_name()                     # 当前追踪任务名
BaseApi.get_cur_task_pos()                      # 当前任务目标坐标列表
```

## 扩展调试模块速查

详细文档见 [references/debug_tools.md](references/debug_tools.md)。

### debug/debug_tool.py（客户端调试）

```python
from debug.debug_tool import p, m, transport, show_nearby_collect_res

p               # 当前玩家 Entity 代理（Proxy，实时获取）
m               # 最近怪物 Entity 代理
transport(x, y, z)                 # 传送（自动判断私服/GM）
show_nearby_collect_res()          # 打印附近采集资源信息
show_nearby_ent()                  # 打印附近 NPC 信息
get_all_dead_region()              # 打印当前所在死亡区域信息
show_dcs_entity()                  # 打印所有 DCS Entity 状态
create_on_prefab(prefabID, activeAI=True)  # 根据 prefab 数据生成单位
switch_sensor()                    # 开关感知体可视化
switch_show_measure_grid()         # 开关网格辅助线
be_hit_test(x, z, count=1)         # 受弹压力测试
```

### debug_tool.py（根级，Entity/性能）

```python
import debug_tool

debug_tool.get_entities_by_class_name('Avatar')  # 按类名查 Entity
debug_tool.get_client_avatar()                   # 获取客户端 Avatar
debug_tool.stop_all_npcs_ai()                    # 暂停所有 NPC AI
debug_tool.start_all_npcs_ai()                   # 恢复所有 NPC AI
debug_tool.get_entity_class_count()              # 统计各类 Entity 数量
debug_tool.real_npc_num()                        # 统计真实 NPC 数量
debug_tool.StatTool.get_stat_items()             # 获取性能采样项列表
```

### 服务端 GM 指令（ClientAvatar.call_gm_cmd）

服务端 GM 指令通过 `ClientAvatar.call_gm_cmd` 调用，格式为：
`call_gm_cmd(cmd_name, dcs_uid, *args)`，其中 `dcs_uid` 通常传 `''` 表示自身，`uid` 由框架自动注入无需手动传。

```python
from entities.ClientAvatar import ClientAvatar
avt = ClientAvatar.get_instance()

avt.call_gm_cmd('buff_event', '', buff_id, buff_lv, True)   # 添加 Buff
avt.call_gm_cmd('buff_event', '', buff_id, buff_lv, False)  # 移除 Buff
avt.call_gm_cmd('destroy_food_buff', '')                     # 销毁所有食物 Buff
avt.call_gm_cmd('add_item', '', item_no, item_num)           # 添加物品
avt.call_gm_cmd('del_item', '', item_no, item_num)           # 删除物品
avt.call_gm_cmd('accept_task', '', task_id)                  # 强制接受任务
avt.call_gm_cmd('trigger_event', '', event_name, arg)        # 触发任务事件
avt.call_gm_cmd('health_event', '', 'add_water', 10000)      # 补水
avt.call_gm_cmd('health_event', '', 'add_food', 10000)       # 补食物
avt.call_gm_cmd('super_hp', '', True)                        # 超高血量
avt.call_gm_cmd('wudi', '', True)                            # 无敌
avt.call_gm_cmd('transport', '', x, y, z)                    # 传送
avt.call_gm_cmd('kill_monsters', '')                         # 杀死附近怪物
```

> ⚠️ GM 指令是异步发往服务端的，调用后需 `yield` 或 `for _ in TaskWaitForSeconds(N): yield` 等待后再验证状态。

**完整指令列表 & 自动化示例**：见 [references/server_gm.md](references/server_gm.md)  
所有 GM 指令实现位于 `server_helper/GM/GM*.py`，查 `CMD` 和 `ARGS` 字段可确认参数顺序。

## 已有 Cases 速查

详细说明见 [references/cases.md](references/cases.md)。

| Case 类 | 用途 |
|---------|------|
| `CaseUnlockWorldStone` | 移动到最近世界石 + 长按F解锁 + 五项验证 |
| `CaseTransportBattle` | 传送到战斗区域并测试战斗 |
| `CaseLogin` / `CaseLoginNew` / `CaseLoginNewV2` | 登录流程 |
| `CaseMapCombat` | 地图战斗测试 |
| `CaseOpenShop` | 打开商店 |
| `CasePathRecorder` / `CasePathReplayer` | 路径录制/回放 |
| `CaseCheckAllNpcValid` | 检查所有NPC有效性 |
| `CaseCheckTransportTowerValid` | 检查传送塔有效性 |
| `CaseTrunkSmokeTest` | 主干冒烟测试 |

## 脚本生成工作流

1. **理解用户意图** — 明确：触发条件、操作步骤、验证目标
2. **判断执行模式** — 完整流程用 run_case（模式A）；临时操作用 GM/debug_tool（模式C）
3. **查找已有 Case** — 是否有现成的可复用/参考（见 cases.md）
4. **选择 Task 积木或工具函数** — 从 tasks.md 选原子任务，或从 debug_tools.md 选即时工具
5. **拼装用例** — 套用模板，按步骤串联任务，soft-assert 验证
6. **清缓存提示** — 编辑 .py 后提醒删除同名 .pyc：
   ```powershell
   Remove-Item "路径\CaseXxx.pyc" -ErrorAction SilentlyContinue
   ```

## 关键约定

- **不要用 `time.sleep()`**，用 `for _ in TimeWaiter(N): yield` 替代（MCP repl_execute 内例外，见下）
- **不要瞬移**，需要移动时用 `TaskMoveTo` 或 `AUTO_MOVE` + `yield` 循环
- **TaskMoveTo 正确签名**：`TaskMoveTo(start_point, end_point, stop_threshold)`，`end_point` 必须传 `[x,y,z]` 列表，不能传 `math3d.vector`（源码 while 循环内有下标访问）
- **Shift 奔跑**：`MSG_KEY_DOWN` → 每帧 `MSG_KEY_PRESSED` → `MSG_KEY_UP`
- **验证用 soft-assert**：每项用 `try/except Exception` 包裹，失败不阻断后续
- **输出格式**：`"{scene}剧本、{prefab}prefab内，{name}，{check}：成功/失败"`

## 宝箱 / 装备箱交互流程（经验证）

> 适用于 `res_type=10`、`is_long_press=True` 类型的场景交互物件（装备箱/武器箱/补给箱）。

### 关键结论

1. **宝箱不是 Entity**，`show_nearby_ent()` 看不到，`get_nearby_interactables()` 的 `world_interactables` 可能为空
2. **交互数据在 `InteractHudPartItemNewPC.collect_multi_res`** 中，包含完整的 `interact_name`、`is_long_press`、`res_type` 等
3. **`InteractHudPart` 的 part_id 每次会话不固定**，必须通过 `get_interact_prompts()` 动态查询
4. **触发方式**：将 `collect_res` 赋给 `part.near_res`，然后调用 `on_click_collect_down(True)` → 等待 → `on_click_collect_up(True)`
5. **解锁后装备**：以 `UIRemnantPC` HUD Part 形式出现（不是独立弹窗），调用 `remnant.get_all_treasure_box_items()` 全部拾取
6. **拾取成功验证**：`UIRemnantPC` part 从 HUD 消失即代表拾取成功
7. **⚠️ 宝箱有冷却机制**：`interact_cooldown=5.0`，打开后会从 `collect_multi_res` 中消失。若传送到坐标后列表为空，可能原因：
   - 宝箱已被本次会话或其他玩家之前打开，处于冷却/已采集状态
   - 宝箱在建筑内部且 AOI `interact_sense_range` 较小（如 `3.0m`），传送落点需在宝箱实际位置 3m 内
   - Y 坐标偏高（建筑二楼）时直接传送可能落在宝箱感知范围之外

### 完整代码模板（在 MCP repl_execute 中分步执行）

```python
# ---- 步骤 A：解锁宝箱（单次 repl_execute 调用）----
from ui.ui_manager.UIManager import UIManager
from debug.qa_debug.Automation.common.BaseApi import BaseApi

# 动态获取 InteractHudPart
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type","")), None)
hud = UIManager.panels.get("PanelHud")
part = hud.get_part(pid)

# 确认是宝箱（is_long_press=True）
collect_res = part.collect_multi_res
if not collect_res:
    print("no box in range")
else:
    r = collect_res[0]
    print("box:", r.get("interact_name"), "is_long_press:", r.get("is_long_press"), "behavior_time:", r.get("behavior_time"))
    part.near_res = r
    part.on_click_collect_down(click_interact_btn=True)
    print("click_down triggered")

# ---- 等待 behavior_time + 1 秒（在 MCP 外 sleep，避免单次调用超时）----

# ---- 步骤 B：释放并拾取（单次 repl_execute 调用）----
from ui.ui_manager.UIManager import UIManager
from debug.qa_debug.Automation.common.BaseApi import BaseApi
import time

hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type","")), None)
part = hud.get_part(pid)
part.on_click_collect_up(click_interact_btn=True)
print("click_up triggered")

time.sleep(2)  # 等待服务端响应，UIRemnantPC 出现

# 找 UIRemnantPC
remnant = None
for panel_path in BaseApi.get_open_panels():
    if panel_path.startswith("PanelHud."):
        p_obj = hud.get_part(int(panel_path.split(".")[1]))
        if p_obj and type(p_obj).__name__ == "UIRemnantPC":
            remnant = p_obj
            break

if remnant:
    print("items:", remnant.item_dict)
    remnant.get_all_treasure_box_items()
    time.sleep(1.5)
    print("pickup done")
else:
    print("UIRemnantPC not found")
```

## 世界石解锁流程（经验证）

> 适用于 `res_type=15`、`behavior_time=0`（即时交互）、`interact_ui_type='UIWorldStonePrompt'` 类型。
> 聚落探索配置表中的「世界石_Scene路径」字段对应 `world_stone_data` 的 `global_name`。

### 关键结论

1. **世界石 res_type=15**，区别于宝箱的 res_type=10
2. **触发方式与宝箱不同**：不能用 `on_click_collect_down()`，必须用 `BaseApi.open_interact_ui()`
   - `open_interact_ui()` 内部触发 `UIWorldStonePromptPC.on_activate`
   - 这会向服务端发送解锁请求
3. **解锁验证**：`exec_state` 从 `"002"` 变为 `"003"` 表示解锁成功
4. **编号查询**：通过 `wsh.world_stone_data` 遍历，用配置表的 `global_name` 字段匹配 `stone_no`
5. **`wsh.get_world_stone_no_by_name(prefab_name)` 返回 0**，说明该函数是按 name 字段查询，不是 prefab；应按 global_name 遍历

### 世界石编号查询

```python
import game_common.helper.WorldStoneHelper as wsh
# 用配置表的「世界石_Scene路径」字段（即 global_name）匹配
target_global = "scene_openworld_07E70707-1120002A-7133E423-3C8B2802_anchor_worldstone"
for k, v in wsh.world_stone_data.items():
    if v.get("global_name") == target_global:
        print("stone_no:", k, "name:", v.get("name"))
        # 输出: stone_no: 10501  name: 世界石·代顿医院
        break
```

### 解锁代码模板

```python
from debug.debug_tool import transport
from debug.qa_debug.Automation.common.BaseApi import BaseApi
from ui.ui_manager.UIManager import UIManager
import time

transport(5771.0, 88.5, -4526.0)  # 世界石坐标
time.sleep(2)

hud = UIManager.panels.get("PanelHud")
prompts = BaseApi.get_interact_prompts()
pid = next((p["part_id"] for p in prompts["prompts"] if "InteractHud" in p.get("object_type", "")), None)
part = hud.get_part(pid)

# 确认世界石在感知范围
collect_res = part.collect_multi_res
if collect_res and collect_res[0].get("res_type") == 15:
    print("exec_state before:", collect_res[0].get("exec_state"))  # 002

    # 触发解锁（不是 on_click_collect_down！）
    BaseApi.open_interact_ui()
    time.sleep(3)

    collect_res2 = part.collect_multi_res
    if collect_res2:
        print("exec_state after:", collect_res2[0].get("exec_state"))  # 003 = success
    else:
        print("worldstone target gone after activate")
```

## Hunter 执行指南

Hunter2 平台用于远程向设备推送并执行 Python 脚本。脚本在游戏进程内运行，可直接调用游戏内 API。

> **核心执行模型已升级为 TaskRunner 闭环模式**，详见 `hunter-runner` skill。
> 本节保留三种执行模式说明，供 execute_fn 内部选择合适的调用方式。

### 三种执行模式

#### 模式 A：run_case（继承 TaskBase 的 Case）

所有继承 `TaskBase` 的 Case 类必须通过 `run_case` 调用，**适合作为 Task 的 execute_fn**：

```python
# 在 TaskRunner 的 execute_fn 中使用：
execute_fn=lambda: (
    hunter.script(r"from debug.qa_debug.Automation.main import run_case"),
    hunter.script(r"run_case(cases=['CaseUnlockWorldStone'])")
)
# 配合 check_fn=check_can_interact 等感知函数确认完成
```

支持同时运行多个 Case（按顺序执行）：

```python
hunter.script(r"run_case(cases=['CaseLogin', 'CaseUnlockWorldStone'])")
```

#### 模式 B：直接调用（普通 Python 函数/工具脚本）

不继承 `TaskBase` 的独立工具脚本，可直接 import 后调用函数：

```python
hunter.script(r"import sys; sys.path.insert(0, 'G:/trunk/client/script')")
hunter.script(r"from debug.qa_debug.gen_world_stone_test_cases import main; main()")
```

> ⚠️ 直接调用前需确认 import 路径在游戏进程中是否已注册。若未注册需手动 `sys.path.insert`。

#### 模式 C：GM指令 / debug_tool / fast_debug（即时调试）

适合一次性的调试、状态设置、信息查询操作，无需创建 Case 文件：

```python
# 复活 + 补满状态
hunter.script(r"""
from entities.ClientAvatar import ClientAvatar
avt = ClientAvatar.get_instance()
avt.call_gm_cmd('revive')
avt.call_gm_cmd('health_event', 'add_water', 10000)
avt.call_gm_cmd('health_event', 'add_food', 10000)
avt.call_gm_cmd('whosyourdaddy')
""")

# 传送到指定坐标
hunter.script(r"from debug.debug_tool import transport; transport(1500.0, 80.0, -3200.0)")

# 查看玩家位置
hunter.script(r"from debug.debug_tool import p; print(p.pos2, p.height)")

# 给玩家加 buff
hunter.script(r"from entities.ClientAvatar import ClientAvatar; ClientAvatar.get_instance().call_gm_cmd('buff_event', '', buff_id, 1, True)")

# 添加物品
hunter.script(r"from entities.ClientAvatar import ClientAvatar; ClientAvatar.get_instance().call_gm_cmd('add_item', 30001001, 10)")

# 截图
hunter.script(r"from debug.debug_methods.GMCommon import screen_cut; screen_cut(0, [])")
```

### 模式选择指南

| 场景 | 推荐模式 |
|------|---------|
| 完整的自动化流程（移动+交互+验证） | 模式 A（run_case） |
| 生成测试数据 / 批量检查有效性 | 模式 A 或 B |
| 临时传送/补状态/加物品 | 模式 C（GM指令） |
| 即时查询信息（坐标/Entity/日志） | 模式 C（debug_tool） |

### 注意事项

| 场景 | 说明 |
|------|------|
| 修改脚本后必须清缓存 | 删除对应 `.pyc`，否则游戏加载旧字节码 |
| run_case 是协程调度器 | 会等待上一个 Case 的 `self._finish()` 才启动下一个 |
| 脚本报错不会中断游戏 | 查看游戏内 debug console 或 hunter 返回的 stdout |
| 推送后有延迟 | 大脚本传输需几秒，等待 hunter 返回 `Done` 再判断结果 |
| GMCommon 函数签名 | `func(dirty_index, params)`，Hunter调用时传 `(0, [参数])` |
