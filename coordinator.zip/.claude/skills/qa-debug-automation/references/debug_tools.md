# Debug Tool 模块完整参考

本文档覆盖 `G:/trunk/client/script` 下所有可通过 Hunter 调用的调试工具，包括：

- `debug_tool.py`（根级，服务端/Entity 工具）
- `debug/debug_tool.py`（客户端 Entity/UI/动画工具）
- `debug/fast_debug.py`（FastDebug 快速调试工具类）
- `debug/debug_methods/GMCommon.py`（调试面板 GM 命令）

---

## 目录
1. [debug_tool.py（根级）](#debugtoolpy根级)
2. [debug/debug_tool.py（客户端）](#debugdebugtoolpy客户端)
3. [debug/fast_debug.py](#debugfastdebugpy)
4. [debug/debug_methods/GMCommon.py](#debugdebugmethodsgmcommonpy)
5. [Hunter 调用方式总结](#hunter-调用方式总结)

---

## debug_tool.py（根级）

**位置**: `G:/trunk/client/script/debug_tool.py`  
**用途**: 一个在线调试工具集，主要用于 Entity 查询、Avatar 操作、性能分析等。  
**适用进程**: 客户端进程（通过 hunter 推送）

### Entity 查询

```python
import sys; sys.path.insert(0, 'G:/trunk/client/script')
import debug_tool

# 通过类名获取所有 Entity 列表（快捷别名 ent）
entities = debug_tool.get_entities_by_class_name('Avatar')
entities = debug_tool.ent('Avatar')  # 等价

# 获取客户端唯一 Avatar
avt = debug_tool.get_client_avatar()

# 通过用户名/角色名/uid 获取 Avatar
avt = debug_tool.get_avatar_by_user_name('username')
avt = debug_tool.get_avatar_by_char_name('charname')
avt = debug_tool.get_avatar_by_uid(uid)

# 获取各类单例
roll_center = debug_tool.get_rollcenter()
server_drop_center = debug_tool.get_ServerDropCenter()

# 获取 Soul（服务端代理）
soul = debug_tool.get_soul_by_avt_uid(avt_uid)

# 统计各类 Entity 数量
class_count = debug_tool.get_entity_class_count()  # → {'Avatar': 3, ...}
avatar_count = debug_tool.get_avatar_count_in_entity_manager()
real_npc = debug_tool.real_npc_num()

# 获取 gc 内存中的 instance
objs = debug_tool.get_gc_objects('Avatar')
objs = debug_tool.match_gc_objects('NPC')  # 模糊匹配
```

### NPC AI 控制

```python
# 暂停/恢复所有 NPC AI
debug_tool.stop_all_npcs_ai()
debug_tool.start_all_npcs_ai()

# 创建/控制单个 NPC
debug_tool.restart_npc(npc_no=422040101)
npc = debug_tool.npc(npc_no)

# 填充 NPC 资源
debug_tool.fill_resrc(res_no, num)

# 强制 NPC 加入某个资源点
debug_tool.npc_join(res_no, *npc_nos)
```

### 内存/性能分析

```python
# 对象图分析（需 import objgraph）
debug_tool.show_objgraph_diff(new_og_ret, old_og_ret)
debug_tool.show_most_common_func(limit=100)
debug_tool.get_n_most_common_func_list(seq=0)  # 返回某个函数的所有 instance
debug_tool.show_back_refs('ClassName', num=1)   # 显示引用链（输出 .png）
debug_tool.show_invalid_holder_cyc_refs(num=1)  # 显示无效 Holder 的引用链

# Timer 统计
timer_stat = debug_tool.get_timer_counter()  # → [(desc, count), ...]

# 性能统计工具（服务端）
items = debug_tool.StatTool.get_stat_items()
stat  = debug_tool.StatTool.get_stat()
sample = debug_tool.StatTool.get_latest_stat_sample()
samples = debug_tool.StatTool.get_samples(start=0, num=10, stride=1)
```

### 调试辅助

```python
# 函数调用追踪（自动打日志）
debug_tool.tracefunc('func_name1', 'func_name2')
debug_tool.tracemodule('module_name')
debug_tool.stoptrace()

# 序列化对象为 dict
d = debug_tool.get_dict_state(obj, depth=5)

# 性能 profile
debug_tool.start_profile()
debug_tool.dump_profile()

# 开启某个客户端的 debug 信息显示
debug_tool.enable_avt_client_debug(uid, duration=30)
```

### Allocator 负载显示

```python
debug_tool.show_allocator_master_load()
```

---

## debug/debug_tool.py（客户端）

**位置**: `G:/trunk/client/script/debug/debug_tool.py`  
**用途**: 客户端调试工具，提供 Entity 代理（DebugHolderProxy）、UI/动画/碰撞/场景调试  
**适用进程**: 客户端进程

### 核心快捷变量

导入后可直接使用以下代理对象（Proxy，访问时实时获取）：

```python
from debug.debug_tool import p, m, pm, visual, ui, b, pv, cm

p        # 当前玩家 Entity（DebugHolderProxy）
m        # 最近怪物 Entity
pm       # 当前玩家 world.model（主角模型资源对象）
visual   # 当前玩家 ModelProxy（动画图等）
ui       # UI Proxy（访问 UIManager）
b        # 第一个建筑 Entity
pv       # 玩家当前载具 Entity
cm       # CollectMgr 代理
```

### Entity 获取

```python
from debug.debug_tool import entity, get_controlled_player, get_monster, get_other_player

# 通过 uid 获取 Entity（支持字符串 uid）
e = entity(uid)

# 快速获取当前玩家
p = get_controlled_player()

# 最近怪物
m = get_monster()

# 其他玩家（第一个）
other = get_other_player()

# 通过前缀/后缀模糊查找
e = startswith('1234')
e = endswith('5678')

# 按 EntityType 枚举获取 uid 列表
uids = uid_by_type(204)  # 参数是 EntityType 的整数值

# 获取 Avatar 实例
avt = avatar()

# 获取 Soul（服务端 RPC 代理）
soul_obj = soul()

# 获取 F10 创建的 AI 对象
ai_ent = get_ai_entity()
```

### Visual / 动画

```python
from debug.debug_tool import get_visual, record, stop, auto_record_switch

# 获取 VisualProxy（ModelProxy 的封装）
v = get_visual()           # 当前玩家
v = get_visual(visual_pid) # 指定 pid

# 动画图录制
record()                    # 开始录制当前玩家
record(uid='xxxx')          # 录制指定 uid
record_pid(pid)             # 录制指定 visual_pid
stop()                      # 结束录制

# 自动录制（引擎侧录制，不需要手动结束）
auto_record_switch(uid=None, flag=True, total_time=15.0)
save_auto_record_data(uid=None)  # 保存自动录制数据

# LOD 调试
change_lod_bias(lod_bias=0.5)
get_lod_level()

# 播放单动画
play_anim(path='character/.../animation/xxx.animation')
```

### UI 调试

```python
from debug.debug_tool import ui_panel, get_model_uid_by_panel_name

# 获取 UI Proxy
proxy = ui_proxy()

# 获取指定 Panel 对象
panel = ui_panel('PanelHud')

# 获取界面内3D模型的 uid
uid = get_model_uid_by_panel_name('PanelEquipmentBag')

# 获取界面模型 LOD 等级
get_ui_model_lod_level('PanelEquipmentBag')

# 获取界面模型 VisualProxy
v = get_panel_visual('PanelEquipmentBag')
```

### 碰撞 / 感知体 / 物理

```python
from debug.debug_tool import switch_sensor, test_collision

# 开关感知体显示
switch_sensor()

# 测试碰撞检测（打印结果）
test_collision(radius=2, vertical=15, horizontal=15)

# 碰撞体交互显示
show_all_interaction_body_pos()     # 开启逐帧绘制
clear_all_interaction_body_pos()    # 关闭并清除

# 布料/软骨
enable_cloth(enable=True)
enable_physicalbone(enable=True)
enable_cloth_physicbone_collider(enable, is_cloth)
switch_physicalbone_config(enable_col, enable_col_constraint, enable_virtual_col,
                           enable_custom_virtual_count, enable_level,
                           virtual_count_v, virtual_count_h)
load_cloth_param()   # 返回 ClothParamHelper

# CPU 质量分级切换
switch_cpu_quality_lv(lv, relative_lv)
```

### 传送 / 朝向

```python
from debug.debug_tool import transport, set_char_euler_on_client

# 传送（自动判断私服/GM指令）
transport(x, y, z)

# 设置角色朝向
set_char_euler_on_client(euler_y)
```

### 其他调试工具

```python
# 显示网格测量辅助线
switch_show_measure_grid()

# 显示死亡区域信息
get_all_dead_region()

# 显示附近采集资源信息
show_nearby_collect_res()
show_nearby_ent()

# 获取主角附近可采集资源（含服务端+客户端信息）
res = get_nearby_collect_res()

# 显示 DCS Entity 状态
show_dcs_entity()

# 显示 Head UI 状态
show_head_ui()

# 创建单位（基于 prefab 数据）
create_on_prefab(prefabID='xxxx', activeAI=True, abs_x=0, abs_z=5)

# 查询射线碰撞组
query_col_group(start_pos3=(x,y,z), end_pos3=(x2,y2,z2))

# 被弹测试（压力测试）
be_hit_test(x, z, count=1)

# 显示击杀信息（UI测试）
show_kill_info(name='BINGO', name2='target', kill_type=3)
```

---

## debug/fast_debug.py

**位置**: `G:/trunk/client/script/debug/fast_debug.py`  
**用途**: `FastDebug` 工具类，封装常用的快速调试操作  
**适用进程**: 客户端

> ⚠️ 以下仅列出通过 Hunter 推送后**实际可用**的方法。以下方法已排除：
> - 依赖 VisualDebug.draw_line / engine_fast_query(CAM_*) 的特效/射线相关（`create_sfx`、`destroy_sfx`、`set_sfx`、`hit_by_ray`、`ray_collision`、`debug_cam_random_angle`）
> - 依赖 `uc`（UnitControl）的朝向控制（`debug_turn`、`debug_turn2`、`debug_turn3`、`debug_monster_turn`）
> - 依赖 `VisualProxyMgr._engine_proxy.camera` 的摄像机调试（`debug_camera_zoom`、`debug_camera_zoom_recover`、`cal_camera_info`）
> - 方法体为空/全注释（`open_hit_dir_debug`、`test_bgm`、`debug_change_mesh`、`_test_socket`）
> - 内部引用不存在的方法（`switch_gun` 调 `bind_to_bag` 未定义、`aim_assist_params` 调 `get_aim_assist_params` 未定义）
> - 能量子弹业务专用（`add_energy_gun`、`check_pick_up`、`pick_up_energy`、`pick_up`、`destroy_cube`、`create_energy_bullet_tower`）

### 导入

```python
from debug.fast_debug import fast_debug
# fast_debug 是 FastDebug() 的全局单例
```

### Buff 操作（已验证可用）

```python
# 给玩家加 buff
fast_debug.create_buff(buffid=403131600, bufflv=1, player=True)

# 给最近怪物加 buff
fast_debug.create_buff(buffid=403131600, bufflv=1, player=False)

# 移除玩家 buff
fast_debug.destroy_buff(buffid=403131600, bufflv=1, player=True)

# 移除怪物 buff
fast_debug.destroy_buff(buffid=403131600, bufflv=1, player=False)
```

### Holder 状态查询

```python
# 通过 uid 字符串查询 Holder 属性
holder = fast_debug.get_holder(target_uid='xxxx')

# 查询玩家/Entity 的状态机 state_map（打印到 console）
fast_debug.get_holder_state(uid='xxxx')

# 向服务端发送 DEBUG_PLAYER_SHOOT 指令（服务端 Holder 调试）
fast_debug.debug_server_holder(uid='xxxx')
```

### 行为/状态事件

```python
# 向服务端推送行为事件
fast_debug.debug_cast_behavior_player(behavior_name='xxx')

# 推送 STATE_EVENT（process_action）
fast_debug.process_action(act_type=1)

# 推送 STATE_EVENT（break_state）
fast_debug.break_state(st_type=1)
```

### 射击调试

```python
# 开启射击相关组件的 debug log（CompShootClient 等）
fast_debug.open_shoot_debug()

# 开启换手（hold change）调试 log
fast_debug.hold_change_debug()

# 切换弹孔 decal Y 比例（影响弹孔形变）
fast_debug.decal_rate(value=3)

# 切换射击点显示（Debug Draw）
fast_debug.shoot_point(switch=True, radius=None)  # radius 如 0.1
```

### 物品/背包/UI

```python
# 打开枪械背包 UI
fast_debug.gun_bag()

# 查询背包内指定物品的数量（打印）
fast_debug.get_bag_item(item_no=30900007)

# 标记物品为已购买状态（调试用）
fast_debug.set_item_bought(item_id=xxxxx)
```

### 模型可见性

```python
# 强制显示主手持枪模型（resident obj）
fast_debug.set_resident_obj_visible()
```

### 飞行特效速度

```python
# 修改当前飞行特效速度参数
fast_debug.fly_sfx_speed(speed=50)
```

---

## debug/debug_methods/GMCommon.py

**位置**: `G:/trunk/client/script/debug/debug_methods/GMCommon.py`  
**用途**: 调试面板上的快捷 GM 命令（通过 `call_gm_cmd` 调用服务端 GM 接口）  
**调用方式**: 函数签名为 `func(dirty_index, params)`，Hunter 直接调用时传 `(0, [])` 即可

> ⚠️ 这些函数设计为调试面板按钮的回调，Hunter 调用时格式：
> ```python
> from debug.debug_methods.GMCommon import revive
> revive(0, [])
> ```
> 或者直接调用底层 GM 命令（推荐方式，见下方）。

### 推荐的底层 GM 调用方式

```python
from entities.ClientAvatar import ClientAvatar
avt = ClientAvatar.get_instance()

# 复活
avt.call_gm_cmd('revive')

# 无敌切换
avt.call_gm_cmd('whosyourdaddy')

# 传送
avt.call_gm_cmd('transport', x, y, z)

# 添加物品
avt.call_gm_cmd('add_item', item_no, count)

# 添加所有 perk（技能库）
avt.call_gm_cmd('add_all_perks_test')

# 清空技能库
avt.call_gm_cmd('remove_all_perk_test')

# 解锁摇篮超控
avt.call_gm_cmd('unlock_override_all')

# 添加一键初始化物品
avt.add_init_bag_items_req()

# 清空背包
avt.restore_init_bag_items_req()

# 重置领地回收时间戳
avt.call_gm_cmd('reset_ter_recycle_timestamp')

# 添加水分
avt.call_gm_cmd('health_event', 'add_water', 1000)

# 添加食物
avt.call_gm_cmd('health_event', 'add_food', 1000)

# 一键解锁建筑皮肤（墙纸+外观）
avt.call_gm_cmd('one_key_unlock_skin_group')
```

### 无敌模式（精确控制）

```python
from entities.ClientAvatar import ClientAvatar
from dcs_extend.const.avoid_be_hit_reason import AvoidBeHitReason
from dcs_extend.const.cmd_const import Cmd
from dcs_core.Env import Env

ClientAvatar.get_instance().call_dcs_cmd_in_gm(
    Env.PLAYER_UID, Cmd.AVOID_BE_HIT,
    {'reason': AvoidBeHitReason.GM, 'force': True, 'state': 2}  # state: 0=不无敌, 1=一档, 2=二档
)
```

### 私服模式下的 GM 传送

```python
from entities.ClientAvatar import ClientAvatar
avt = ClientAvatar.get_instance()
if avt.is_private_server_manager_gm_auth():
    avt.call_private_server_gm_cmd('transport', x, y, z)
else:
    avt.call_gm_cmd('transport', x, y, z)
```

### 调试面板命令（直接调用 GMCommon 函数）

| 函数名 | 功能 | 调用示例 |
|--------|------|---------|
| `revive` | 复活 | `revive(0, [])` |
| `swtich_wd` | 切换无敌 | `swtich_wd(0, [])` |
| `take_damage` | 自杀 | `take_damage(0, [])` |
| `add_init_bag_item_test` | 一键添加初始化物品 | `add_init_bag_item_test(0, [])` |
| `add_init_skill_bag_test` | 一键添加技能库 | `add_init_skill_bag_test(0, [])` |
| `remove_skill_bag_test` | 清空技能库 | `remove_skill_bag_test(0, [])` |
| `clear_bag_item` | 清空背包 | `clear_bag_item(0, [])` |
| `override_debug_switch` | 一键解锁摇篮超控 | `override_debug_switch(0, [])` |
| `screen_cut` | 客户端截图 | `screen_cut(0, [])` |
| `renderdoc_capture_save` | RenderDoc截帧 | `renderdoc_capture_save(0, [])` |
| `switch_to_collect_png` | 开启UI资源收集 | `switch_to_collect_png(0, [True])` |
| `hide_show_all_ui` | 销毁所有UI（重置） | `hide_show_all_ui(0, [])` |
| `show_entity_state` | 显/隐所有 Entity 状态 | `show_entity_state(0, [])` |
| `draw_temp_control_radiation_range` | 绘制温控塔范围 | `draw_temp_control_radiation_range(0, [])` |

### 性能/画质类

```python
# 切换 CPU 画质分级（影响逻辑剔除）
from debug.debug_tool import switch_cpu_quality_lv  # debug/debug_tool.py 中
switch_cpu_quality_lv(lv=3, relative_lv=2)

# 禁用/启用 UI 渲染（GPU/CPU 分级）
from debug.debug_tool import set_enable_ui
set_enable_ui(value=True, lv=1)   # lv=1:active(CPU+GPU), 2:enable(CPU), 3:visible(GPU)

# Python 内存追踪
import tracemalloc
tracemalloc.start()

# RenderDoc 自动截帧（GPUBound 触发）
import game3d
game3d.renderdoc_auto_capture(1, 2.0)  # 截帧次数, Bound阈值
```

---

## Hunter 调用方式总结

### 调用 GMCommon 里的函数

```python
# 方式1: 直接调用 GMCommon 函数（注意 dirty_index 和 params 参数）
hunter.script(r"from debug.debug_methods.GMCommon import revive; revive(0, [])")

# 方式2: 调用底层 GM 命令（更推荐）
hunter.script(r"from entities.ClientAvatar import ClientAvatar; ClientAvatar.get_instance().call_gm_cmd('revive')")
```

### 调用 debug_tool（客户端）

```python
# 传送到指定坐标（自动判断私服/GM）
hunter.script(r"from debug.debug_tool import transport; transport(1000, 50, -2000)")

# 获取玩家当前坐标（调试用）
hunter.script(r"from debug.debug_tool import p; print(p.pos2, p.height)")

# 查看附近采集资源
hunter.script(r"from debug.debug_tool import show_nearby_collect_res; show_nearby_collect_res()")

# 暂停所有 NPC AI
hunter.script(r"import debug_tool; debug_tool.stop_all_npcs_ai()")
```

### 调用 fast_debug

```python
# 创建/销毁 buff
hunter.script(r"from debug.fast_debug import fast_debug; fast_debug.create_buff(5, 1)")
hunter.script(r"from debug.fast_debug import fast_debug; fast_debug.destroy_buff(5, 1)")

# 打开枪械背包
hunter.script(r"from debug.fast_debug import fast_debug; fast_debug.gun_bag()")
```

### 调用 debug_tool.py（根级，Entity/性能工具）

> ⚠️ 根级 `debug_tool.py` 设计为服务端进程使用，客户端 hunter 推送时注意 import 路径：

```python
# 通过 GameWorldMgr 等客户端路径确认后再使用
hunter.script(r"from debug_tool import get_entities_by_class_name; print(get_entities_by_class_name('Avatar'))")
```

---

## 常见组合示例

### 给玩家补满状态 + 无敌

```python
hunter.script(r"""
from entities.ClientAvatar import ClientAvatar
avt = ClientAvatar.get_instance()
avt.call_gm_cmd('revive')
avt.call_gm_cmd('health_event', 'add_water', 10000)
avt.call_gm_cmd('health_event', 'add_food', 10000)
avt.call_gm_cmd('whosyourdaddy')
""")
```

### 传送 + 补状态（QA用）

```python
hunter.script(r"""
from debug.debug_tool import transport
from entities.ClientAvatar import ClientAvatar
transport(1500.0, 80.0, -3200.0)
avt = ClientAvatar.get_instance()
avt.call_gm_cmd('revive')
""")
```

### 查看玩家当前位置和 Entity 信息

```python
hunter.script(r"""
from debug.debug_tool import p, get_monster
print('player pos:', p.pos2, 'height:', p.height)
m = get_monster()
if m:
    print('monster uid:', m.uid, 'pos:', m.pos2)
""")
```

### 截图并保存

```python
hunter.script(r"""
from debug.debug_methods.GMCommon import screen_cut
screen_cut(0, [])
""")
```
