# Tasks 详细用法参考

## 目录
1. [移动类](#移动类)
2. [传送类](#传送类)
3. [等待类](#等待类)
4. [战斗类](#战斗类)
5. [采集类](#采集类)
6. [装备/制造类](#装备制造类)
7. [UI交互类](#ui交互类)
8. [镜头类](#镜头类)
9. [其他工具类](#其他工具类)

---

## 移动类

### TaskMoveTo
```python
from debug.qa_debug.Automation.Tasks.TaskMoveTo import TaskMoveTo
from debug.qa_debug.Automation.common.BaseApi import BaseApi

# ⚠️ 实际签名：(start_point, end_point, stop_threshold, stop_cb=None)
# ⚠️ end_point 必须传 list [x,y,z]，不能传 math3d.vector
#    （源码 while 循环内有 self._end_point[0] 下标访问，传 vector 会报 TypeError）

cur = BaseApi.get_player_pos()
for _ in TaskMoveTo([cur.x, cur.y, cur.z], [x, y, z], 2.0):
    yield
```

### TaskMove
```python
from debug.qa_debug.Automation.Tasks.TaskMove import TaskMove
# 按方向持续移动
for _ in TaskMove(direction=math3d.vector(1, 0, 0), duration=3.0):
    yield
```

### TaskAutoMove (SmokeTest)
```python
from debug.qa_debug.Automation.Tasks.SmokeTestTask.TaskAutoMove import TaskAutoMove
# AUTO_MOVE 组件寻路，更接近真实寻路
for _ in TaskAutoMove(target_pos=math3d.vector(x, y, z), stop_distance=2.0, timeout=60):
    yield
```

### TaskNavigateTo
```python
from debug.qa_debug.Automation.Tasks.TaskNavigateTo import TaskNavigateTo
# 导航寻路到目标
for _ in TaskNavigateTo(target_pos=math3d.vector(x, y, z)):
    yield
```

### TaskMoveToYawDrive
```python
from debug.qa_debug.Automation.Tasks.TaskMoveToYawDrive import TaskMoveToYawDrive
# 偏航驱动移动（模拟摇杆/键盘方向移动）
for _ in TaskMoveToYawDrive(target_pos=math3d.vector(x, y, z), stop_dist=2.0):
    yield
```

### TaskMoveToYawDriveWaypoints
```python
from debug.qa_debug.Automation.Tasks.TaskMoveToYawDriveWaypoints import TaskMoveToYawDriveWaypoints
# 按路径点依次移动
waypoints = [math3d.vector(x1,y1,z1), math3d.vector(x2,y2,z2)]
for _ in TaskMoveToYawDriveWaypoints(waypoints=waypoints):
    yield
```

### TaskFollow
```python
from debug.qa_debug.Automation.Tasks.TaskFollow import TaskFollow
# 跟随目标实体
for _ in TaskFollow(target_uid=some_uid, distance=3.0):
    yield
```

### TaskJump
```python
from debug.qa_debug.Automation.Tasks.TaskJump import TaskJump
for _ in TaskJump():
    yield
```

### Shift奔跑（手动实现）
```python
# 按住Shift奔跑，每帧发送 PRESSED 保持
from neox.input.InputMgr import InputMgr
import game
InputMgr.process_input(game.VK_LSHIFT, msg=game.MSG_KEY_DOWN)
while moving:
    InputMgr.process_input(game.VK_LSHIFT, msg=game.MSG_KEY_PRESSED)
    yield
InputMgr.process_input(game.VK_LSHIFT, msg=game.MSG_KEY_UP)
```

---

## 传送类

### TaskTransport
```python
from debug.qa_debug.Automation.Tasks.TaskTransport import TaskTransport
import math3d
# 传送到坐标，等待加载完成
for _ in TaskTransport(pos=math3d.vector(x, y, z), euler=math3d.vector(0, 0, 0), tolerance=10):
    yield
```

### TaskTransportStable
```python
from debug.qa_debug.Automation.Tasks.TaskTransport import TaskTransportStable
# 传送两次，防止穿地
for _ in TaskTransportStable(pos=math3d.vector(x, y, z), euler=math3d.vector(0,0,0), tolerance=2):
    yield
```

### TaskSimpleTransport
```python
from debug.qa_debug.Automation.Tasks.TaskTransport import TaskSimpleTransport
# 简单传送（teleport_player）
for _ in TaskSimpleTransport(target_pos=math3d.vector(x, y, z)):
    yield
```

---

## 等待类

### TimeWaiter（分帧等待，推荐）
```python
from debug.qa_debug.Automation.Tasks.TaskTimeOut import TimeWaiter
# 在协程内等待 N 秒（不阻塞主线程）
for _ in TimeWaiter(2.0):
    yield
```

### TaskWaitForSeconds
```python
from debug.qa_debug.Automation.Tasks.TaskWaitForSeconds import TaskWaitForSeconds
for _ in TaskWaitForSeconds(seconds=3.0):
    yield
```

### TaskWaitForLoad
```python
from debug.qa_debug.Automation.Tasks.TaskWaitForLoad import TaskWaitForLoad
# 等待场景加载完成
for _ in TaskWaitForLoad():
    yield
```

### TaskWaitForCondition (SmokeTest)
```python
from debug.qa_debug.Automation.Tasks.SmokeTestTask.TaskWaitForCondition import TaskWaitForCondition
# 等待 lambda 条件满足，超时则继续
for _ in TaskWaitForCondition(lambda: some_state == target, timeout=30):
    yield
```

### TaskWhile
```python
from debug.qa_debug.Automation.Tasks.TaskWhile import TaskWhile
# 持续执行子任务直到条件满足
for _ in TaskWhile(condition=lambda: not done, task=SomeTask()):
    yield
```

---

## 战斗类

### TaskAutoAttack
```python
from debug.qa_debug.Automation.Tasks.TaskAutoAttack import TaskAutoAttack
# 自动近战攻击附近怪物
for _ in TaskAutoAttack():
    yield
```

### TaskAutoShoot
```python
from debug.qa_debug.Automation.Tasks.TaskAutoShoot import TaskAutoShoot
for _ in TaskAutoShoot():
    yield
```

### TaskKillNearMonsterUsingGun
```python
from debug.qa_debug.Automation.Tasks.TaskKillNearMonsterUsingGun import TaskKillNearMonsterUsingGun
for _ in TaskKillNearMonsterUsingGun():
    yield
```

### TaskMonsterCombat
```python
from debug.qa_debug.Automation.Tasks.TaskMonsterCombat import TaskMonsterCombat
for _ in TaskMonsterCombat(target_pos=math3d.vector(x, y, z)):
    yield
```

### TaskCreateMonster
```python
from debug.qa_debug.Automation.Tasks.TaskCreateMonster import TaskCreateMonster
for _ in TaskCreateMonster(monster_id=12345, pos=math3d.vector(x, y, z)):
    yield
```

---

## 采集类

### TaskCollect
```python
from debug.qa_debug.Automation.Tasks.TaskCollect import TaskCollect
for _ in TaskCollect(target_pos=math3d.vector(x, y, z)):
    yield
```

### TaskCollectNormal
```python
from debug.qa_debug.Automation.Tasks.TaskCollectNormal import TaskCollectNormal
for _ in TaskCollectNormal(target_pos=math3d.vector(x, y, z)):
    yield
```

### TaskCollectWater
```python
from debug.qa_debug.Automation.Tasks.TaskCollectWater import TaskCollectWater
for _ in TaskCollectWater():
    yield
```

### TaskCollectAnimal
```python
from debug.qa_debug.Automation.Tasks.TaskCollectAnimal import TaskCollectAnimal
for _ in TaskCollectAnimal(target_pos=math3d.vector(x, y, z)):
    yield
```

### TaskCollectInACirCle
```python
from debug.qa_debug.Automation.Tasks.TaskCollectInACircle import TaskCollectInACirCle
# 在圆形区域内采集
for _ in TaskCollectInACirCle(center=math3d.vector(x,y,z), radius=10.0):
    yield
```

---

## 装备/制造类

### TaskEquipWeaponAndMod
```python
from debug.qa_debug.Automation.Tasks.TaskEquipWeaponAndMod import TaskEquipWeaponAndMod
for _ in TaskEquipWeaponAndMod(weapon_id=30001001):
    yield
```

### TaskEquipArmorAndMod
```python
from debug.qa_debug.Automation.Tasks.TaskEquipArmorAndMod import TaskEquipArmorAndMod
for _ in TaskEquipArmorAndMod(armor_id=20001001):
    yield
```

### TaskPutOnEquip
```python
from debug.qa_debug.Automation.Tasks.TaskPutOnEquip import TaskPutOnEquip
for _ in TaskPutOnEquip(equip_id=xxxxx):
    yield
```

### TaskMakeWeapon / TaskMakeArmor / TaskMakeTool
```python
from debug.qa_debug.Automation.Tasks.TaskMakeWeapon import TaskMakeWeapon
for _ in TaskMakeWeapon(item_id=xxxxx):
    yield
```

---

## UI交互类

### TaskPressFUnitlPanelShow
```python
from debug.qa_debug.Automation.Tasks.TaskPressFUntilPanelShow import TaskPressFUnitlPanelShow
# 持续按F直到目标Panel出现
for _ in TaskPressFUnitlPanelShow(panel_name='PanelInteract', timeout=10):
    yield
```

### 键盘输入（直接调用）
```python
from neox_editor.EditorInput import on_key_event
import game
# 单次按键
on_key_event(game.MSG_KEY_DOWN, game.VK_F)
on_key_event(game.MSG_KEY_UP, game.VK_F)

# 长按（在yield循环内）
on_key_event(game.MSG_KEY_DOWN, game.VK_F)
for _ in TimeWaiter(1.5):
    yield
on_key_event(game.MSG_KEY_UP, game.VK_F)
```

### TaskPlayCutScene
```python
from debug.qa_debug.Automation.Tasks.TaskPlayCutScene import TaskPlayCutScene
for _ in TaskPlayCutScene(cutscene_id=xxxxx):
    yield
```

### TaskTakePicture（截图）
```python
from debug.qa_debug.Automation.Tasks.TaskTakePicture import TaskTakePicture
for _ in TaskTakePicture(filename='screenshot.png'):
    yield
```

---

## 镜头类

### TaskCameraToPos
```python
from debug.qa_debug.Automation.Tasks.TaskCameraToPos import TaskCameraToPos
for _ in TaskCameraToPos(target_pos=math3d.vector(x, y, z)):
    yield
```

### TaskLookAt
```python
from debug.qa_debug.Automation.Tasks.TaskLookAt import TaskLookAt
for _ in TaskLookAt(target_pos=math3d.vector(x, y, z)):
    yield
```

---

## 其他工具类

### TaskTimeOut
```python
from debug.qa_debug.Automation.Tasks.TaskTimeOut import TaskTimeOut
# 超时后执行回调
timer = TaskTimeOut(timeout_sec=30, callback=lambda: print('timeout'))
```

### TaskLogin
```python
from debug.qa_debug.Automation.Tasks.TaskLogin import TaskLogin
for _ in TaskLogin(account='xxx', password='yyy'):
    yield
```

### TaskDrawCircle
```python
from debug.qa_debug.Automation.Tasks.TaskDrawCircle import TaskDrawCircle
# 在地图上画圆（调试辅助）
for _ in TaskDrawCircle(center=math3d.vector(x,y,z), radius=5.0):
    yield
```

### TaskBuild
```python
from debug.qa_debug.Automation.Tasks.TaskBuild import TaskBuild
# 建造操作
for _ in TaskBuild(build_id=xxxxx, pos=math3d.vector(x,y,z)):
    yield
```
