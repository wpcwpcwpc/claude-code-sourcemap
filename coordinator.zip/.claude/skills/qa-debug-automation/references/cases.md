# Cases 详细说明

## 目录
1. [世界石系列](#世界石系列)
2. [登录系列](#登录系列)
3. [战斗系列](#战斗系列)
4. [路径录制/回放系列](#路径录制回放系列)
5. [数据有效性检查系列](#数据有效性检查系列)
6. [冒烟测试](#冒烟测试)
7. [Voxel系列](#voxel系列)
8. [其他](#其他)

---

## 世界石系列

### CaseUnlockWorldStone
**文件**: `Cases/CaseUnlockWorldStone.py`  
**功能**: 完整的世界石解锁自动化用例

**流程**:
1. 前置准备（补水 `set_water(10000)`）
2. AUTO_MOVE + Shift奔跑到最近世界石
3. 调整角色朝向世界石（`set_char_euler_on_client`）
4. 循环长按F直到 `WorldStoneState.ACTIVATED`
5. 五项验证：模型存在 / 浮空 / 解锁持久化 / 地图标记 / 传送塔点位

**输出格式**:
```
{scene}剧本、{prefab}prefab内，{stone_name}世界石，{check_name}：成功/失败
```

**依赖**:
- `CaseTransportTower.get_nearest_world_stone_pos()` 获取最近世界石坐标
- `WorldStoneHelper` 获取世界石配置
- `dcs_utils.get_transporter_info()` 获取传送塔激活状态

---

## 登录系列

### CaseLogin
**文件**: `Cases/CaseLogin.py`  
**功能**: 标准登录流程（旧版）

### CaseLoginNew
**文件**: `Cases/CaseLoginNew.py`  
**功能**: 新版登录流程

### CaseLoginNewV2
**文件**: `Cases/CaseLoginNewV2.py`  
**功能**: V2版登录流程，支持角色创建和新手流程

---

## 战斗系列

### CaseTransportBattle
**文件**: `Cases/CaseTransportBattle.py`  
**功能**: 传送到战斗点 → 执行战斗测试

### CaseTransportBattleT1
**文件**: `Cases/CaseTransportBattleT1.py`  
**功能**: T1层级战斗传送测试

### CaseMapCombat
**文件**: `Cases/CaseMapCombat.py`  
**功能**: 地图上的战斗测试

### CaseEndowTest
**文件**: `Cases/CaseEndowTest.py`  
**功能**: 赋能/加持系统测试

---

## 路径录制/回放系列

### CasePathRecorder
**文件**: `Cases/CasePathRecorder.py`  
**功能**: 录制玩家移动路径，保存为文件

### CasePathReplayer
**文件**: `Cases/CasePathReplayer.py`  
**功能**: 回放已录制的移动路径

### CasePathReplayerVehicle
**文件**: `Cases/CasePathReplayerVehicle.py`  
**功能**: 载具路径回放

### CasePathReplayerVehicleForPerf
**文件**: `Cases/CasePathReplayerVehicleForPerf.py`  
**功能**: 载具路径回放（性能测试版）

### CaseVoxelRecorder / CaseVoxelReplayer
**文件**: `Cases/CaseVoxelRecorder.py`, `Cases/CaseVoxelReplayer.py`  
**功能**: Voxel场景路径录制/回放

---

## 数据有效性检查系列

这类 Case 遍历游戏数据，检查各类实体的有效性。

### CaseCheckAllNpcValid
检查所有NPC数据的有效性（位置、模型、配置等）

### CaseCheckBoxValid
检查箱子/宝箱实体有效性

### CaseCheckFogValid
检查雾区/禁区有效性

### CaseCheckFoodRecipeValid
检查食物配方数据有效性

### CaseCheckResourceValid
检查资源点有效性

### CaseCheckRiftAnchorValid
检查裂缝锚点有效性

### CaseCheckTaskNpcValid
检查任务NPC有效性

### CaseCheckTransportTowerValid
检查传送塔数据有效性（位置、激活状态）

### CaseCheckTreasureMonsterValid
检查宝藏怪物有效性

### CheckCollectableResourceValid
检查可采集资源有效性

---

## 冒烟测试

### CaseTrunkSmokeTest
**文件**: `Cases/CaseTrunkSmokeTest.py`  
**功能**: 主干冒烟测试，覆盖登录、移动、战斗、UI等核心流程

### CaseShaderCacheMissTest
**文件**: `Cases/CaseShaderCacheMissTest.py`  
**功能**: Shader缓存缺失测试

### SmokeTestCases/ 目录下的 Case（按功能分）

| Case | 功能 |
|------|------|
| `CaseMovementTest` | 移动系统测试 |
| `CaseKillMonsterMelee` | 近战杀怪 |
| `CaseKillMonsterShoot` | 射击杀怪 |
| `CaseCollectFunctionalityTest` | 采集功能测试 |
| `CaseFashionFunctionalityTest` | 时装功能测试 |
| `CaseFashionSystemTest` | 时装系统测试 |
| `CaseEquipmentUITest` | 装备UI测试 |
| `CaseShootFunctionalityTest` | 射击功能测试 |
| `CaseInteractionFunctionalityTest` | 交互功能测试 |
| `CaseItemFunctionalityTest` | 物品功能测试 |
| `CaseShoppingMallFunctionalityTest` | 商城功能测试 |
| `CaseBuildTerritory` / `CaseBuildTerritoryNew` | 领地建造测试 |
| `CaseDungeonEnterExitTest` | 副本进出测试 |
| `CaseNeverlandEnterExitTest` | 永恒之境进出测试 |
| `CaseAutoNavigation*` | 各区域自动寻路导航测试 |
| `CaseNoviceProcess` | 新手流程 |
| `CasePsePerfTest` | PSE性能测试 |
| `CaseCharacterFaceAdjustmentTest` | 角色捏脸测试 |
| `CaseMainHudUITest` | 主界面HUD测试 |
| `CaseTestBuildModeUI` | 建造模式UI测试 |

---

## Voxel系列

### CaseVoxelEnterNeverLand
**文件**: `Cases/CaseVoxelEnterNeverLand.py`  
**功能**: 进入/离开Voxel永恒之境

---

## 其他

### CaseOpenShop
**文件**: `Cases/CaseOpenShop.py`  
**功能**: 打开商店并验证UI

### CaseAutoBDPrepare / CaseAutoBDTest / CaseAutoBDCleanup
**文件**: `Cases/CaseAutoBD*.py`  
**功能**: 大世界数据自动化测试的准备/执行/清理三段式

### move_to_world_stone
**文件**: `Cases/move_to_world_stone.py`  
**功能**: 简单移动到世界石的辅助函数（被 `CaseUnlockWorldStone` 使用）
