# BaseApi 完整方法参考

## 目录
1. [感知层 API（Hunter 闭环查询专用）](#感知层-api)
2. [UI Panel 操作层](#ui-panel-操作层)
3. [玩家属性（写操作）](#玩家属性)
4. [位置与传送](#位置与传送)
5. [朝向与摄像机](#朝向与摄像机)
6. [物品与货币](#物品与货币)
7. [制造系统](#制造系统)
8. [UI操作](#ui操作)
9. [对话系统](#对话系统)
10. [任务系统](#任务系统)
11. [场景查询](#场景查询)

---

## 感知层 API

> 感知层 = **只读查询**，专门用于 hunter-runner 闭环控制中的 `check_fn`。
> 所有函数通过 `hunter.script(..., need_reply=True)` 调用，返回值须可 JSON 序列化。

### 玩家状态感知

```python
# 当前坐标 → 须在脚本内转为 list（vector 不可序列化）
"\nfrom debug.qa_debug.Automation.common.BaseApi import BaseApi"
"\npos = BaseApi.get_player_pos()"
"\nreturn [pos.x, pos.y, pos.z]"

# 当前血量 → 返回 float
"\nreturn BaseApi.get_hp()"
# 实现：holder.hp

# 最大血量 → 返回 float（取决于角色等级/配置）
"\nreturn BaseApi.get_max_hp()"
# 实现：holder.max_hp

# 血量百分比 → 返回 float（0~100，保留2位小数）
"\nreturn BaseApi.get_hp_percentage()"
# 实现：round((holder.hp / holder.max_hp) * 100, 2)，max_hp=0 时返回 0

# 详细血量状态 → 返回 dict（一次性获取全部血量信息，推荐替代多次查询）
"\nreturn BaseApi.get_hp_status()"
# 返回结构：
# {
#   "current_hp":    float,   # 当前血量
#   "max_hp":        float,   # 最大血量
#   "percentage":    float,   # 百分比（0~100）
#   "is_full_health": bool,   # current_hp >= max_hp
#   "is_low_health":  bool,   # percentage < 25
#   "is_critical":    bool,   # percentage < 10
#   "missing_hp":    float,   # 缺少的血量
# }

# 当前水值 → 返回 float（上限同样取决于配置，不可硬编码阈值）
"\nreturn BaseApi.get_water()"
# 实现：holder.water

# 当前食物值 → 返回 float（同上）
"\nreturn BaseApi.get_food()"
# 实现：holder.food

# 当前理智值 → 返回 float（同上）
"\nreturn BaseApi.get_san()"
# 实现：holder.san

# 玩家是否存活 → 返回 bool
# set_healthy() 执行后验证生效的推荐接口，不依赖具体数值上限
"\nreturn BaseApi.is_alive()"
# 实现：not holder.state_map.get(StateType.DEAD, False)
```

### UI 面板状态感知

```python
# 检查指定 Panel 是否显示 → 返回 bool
"\nreturn BaseApi.is_ui_showing('PanelXxx')"
# 实现：UIUtils.is_ui_show(ui_name)

# 获取当前所有已显示的 Panel 列表 → 返回 list[str]
# 注意：PanelHud 会额外展开其活动 Part，格式为 "PanelHud.PartName"
"\nreturn BaseApi.get_open_panels()"

# 获取指定面板的所有活动 Part 名列表 → 返回 list（part 键，可能是 str 或 int）
"\nreturn BaseApi.get_panel_parts('PanelHud')"

# 检查指定面板的特定 Part 是否活动 → 返回 bool
"\nreturn BaseApi.is_panel_part_active('PanelHud', 'HudInteractBase')"

# 获取当前对话类型 → 返回 str: '对话' | '提示' | None
"\nreturn BaseApi.get_dialog_type()"
# 实现：检查 UIManager.panels 中是否有 PanelDialog / PanelCollectableTextInfo

# 获取对话选项列表 → 返回 list[str]
"\nreturn BaseApi.get_dialog_options()"

# 获取对话/提示文本 → 返回 dict {'title': ..., 'content': ...}
"\nreturn BaseApi.get_dialog_text()"

# 获取指定 UI 控件的文本内容 → 返回 str 或 None
"\nreturn BaseApi.get_ui_text('PanelDialog', 'label_title')"
# 实现：依次尝试 widget.text → widget.text_component.text → NodeHelper.get_node_text

# 获取当前场景类型 → 返回 str: '过场动画' | '对话动画' | '普通场景'
"\nreturn BaseApi.get_scene()"
```

### 交互目标感知

```python
# 获取玩家范围内所有可交互物体 → 返回 dict
# 包含：world_interactables（世界交互）、ui_interactables（HUD交互）、nearest_world_interactable
# has_interactables: bool，可直接用于 check_fn
"\nreturn BaseApi.get_nearby_interactables(radius=5.0)"
# 返回结构：
# {
#   "has_interactables": bool,
#   "total_world_interactables": int,
#   "world_interactables": [{"name", "distance", "position", "interact_type", "entity_id"}, ...],
#   "ui_interactables": [{"type", "part_id", "panel_path"}, ...],
#   "nearest_world_interactable": {"name", "distance", ...} | None
# }
# ⚠️ object 字段不可序列化，need_reply 调用时已过滤

# 获取当前系统锁定的交互目标（最直接） → 返回 dict
"\nreturn BaseApi.get_current_interact_target()"
# 返回结构：
# {"has_target": bool, "target": {"name", "distance", "position", "interact_type", "can_interact"} | None}

# 获取当前 HUD 上显示的交互提示（F键提示等） → 返回 dict
# has_prompts: bool，表示玩家当前站在可交互位置
"\nreturn BaseApi.get_interact_prompts()"
# 返回结构：
# {"has_prompts": bool, "total_prompts": int, "prompts": [{"part_id", "object_type", "key_events", "recommended_method"}, ...]}
```

### 任务状态感知

```python
# 当前追踪任务名 → 返回 str
"\nreturn BaseApi.get_cur_task_name()"

# 当前追踪任务 trigger ID → 返回 int/str
"\nreturn BaseApi.get_cur_track_trigger()"

# 当前任务目标坐标列表 → 须在脚本内转换（vector 不可序列化）
"\npos_list = BaseApi.get_cur_task_pos()"
"\nreturn [[p.x, p.y, p.z] for p in pos_list]"
```

### Case 执行状态感知

```python
# ⚠️ 仍缺失：get_case_status(case_name) → str: 'running'|'passed'|'failed'|'finished'
# run_case 启动后无法通过 BaseApi 查询执行进度，需在 main 模块补充此函数
```

### 感知层缺失函数（仍需实现）

| 函数签名 | 用途 | 返回类型 |
|---------|------|----------|
| `get_case_status(case_name)` | Case 执行状态（main 模块） | `str` |

---

## UI Panel 操作层

> 这组函数用于**探索和操控 UI Panel 内部结构**，主要用于调试和自动化交互触发。

### 面板结构探索

```python
# 获取面板所有 Part 的详细调试信息（含 active 状态、类型、类名）
BaseApi.debug_panel_parts_info(panel_name='PanelHud')
# 返回 dict：{panel_name, total_parts, active_parts, inactive_parts, part_details}

# 探索面板的完整层级结构（递归，默认3层）
BaseApi.explore_panel_hierarchy(panel_name, max_depth=3)
# 返回 dict：{panel_name, total_main_parts, hierarchy}

# 获取面板中所有数字键 Part（快速版）
BaseApi.get_panel_numeric_parts(panel_name)
# 返回 dict：{total_numeric_parts, numeric_parts, active_numeric_keys, all_numeric_keys}

# 列出面板中所有数字键 Part（深度搜索，默认5层）
BaseApi.list_all_numeric_parts(panel_name, max_depth=5)
# 返回 dict：{total_numeric_parts, numeric_parts, active_numeric_parts, all_numeric_keys}

# 深度搜索面板中的特定 Part（含所有容器，默认5层）
BaseApi.find_part_in_panel_deep(panel_name, target_key, max_depth=5)
# 返回 dict：{total_found, found_items}（每项含 path, object_type, depth）
```

### 事件查询

```python
# 获取指定 Part 的事件处理方法（点击/按键/交互分类）
BaseApi.get_panel_part_events(panel_name, part_key)
# 返回 dict：{click_events, key_events, ui_events, interaction_methods, all_methods}
# part_key 支持 str 或 int，数字字符串会自动转 int

# 获取指定 Part 的按键事件列表（按优先级排序）
BaseApi.get_part_key_events(panel_name, part_key)
# 返回 dict：{key_events, recommended_method, has_key_events}
```

### 事件触发

```python
# 触发面板 Part 的点击事件（自动尝试常见点击方法）
BaseApi.trigger_panel_part_click(panel_name, part_key, method_name=None)
# method_name 不填时自动尝试：on_click, on_btn_click, click, on_interact...
# 返回 dict：{success, method, params} 或 {success, error}

# 触发面板 Part 的按键/交互事件（自动尝试常见方法）
BaseApi.trigger_part_key_event(panel_name, part_key)
# 自动尝试：on_interact, on_key_press, on_click, execute...
# 返回 dict：{success, method, part_key}

# 触发面板 Part 的指定方法
BaseApi.trigger_specific_key_event(panel_name, part_key, method_name)
# 尝试顺序：method()、method(None)、method(None, None)
# 返回 dict：{success, method, part_key, params}

# 向指定 Part 发送 UI 事件（先查 _ui_events，再 fallback 到全局 bubble）
BaseApi.send_ui_event_to_part(panel_name, part_key, event_name, event_data=None)
# 返回 dict：{success, event, handler/method}

# 模拟按键事件（通过 InputAction 映射）
BaseApi.simulate_key_press(key_name)
# 支持的 key_name：'F'(交互), 'Space'(跳跃), 'M'(地图), 'I'(背包), 'B'(建造), 'Escape' 等
# 返回 dict：{success, key, action}
```

---

## 玩家属性

```python
# 获取玩家 Holder（底层数据持有者）
holder = BaseApi.get_player_holder()

# 获取 ClientAvatar 实例
avt = BaseApi.get_avatar()

# 获取玩家 UID
uid = BaseApi.get_uid()

# ---- 状态恢复 ----
BaseApi.set_healthy()           # 满血+满水+满食物+复活
BaseApi.revive()                # 仅复活
BaseApi.set_hp(10000)           # 设置血量
BaseApi.set_water(10000)        # 补满水值（脱水扣HP用）
BaseApi.set_food(10000)         # 补满食物值
BaseApi.set_san()               # 恢复理智值

# ---- 无敌模式 ----
BaseApi.set_invincible_level_1()   # 一档无敌（有受击动画）
BaseApi.set_invincible_level_2()   # 二档无敌（无受击）
```

---

## 位置与传送

```python
# 获取当前坐标（返回 math3d.vector）
pos = BaseApi.get_player_pos()

# 传送（GM指令，可能有加载等待）
BaseApi.teleport_player(x, y, z)

# 传送（低层 debug_tool，速度快）
BaseApi.transport(x, y, z)
```

---

## 朝向与摄像机

```python
# 设置角色朝向（yaw 角度，不影响摄像机）
BaseApi.set_char_euler_on_client(yaw_degrees)

# 设置摄像机欧拉角
BaseApi.set_camera_euler(x, y, z, angle_mode=False)

# 设置摄像机俯仰/偏航
BaseApi.set_cam_hpb_angle(pitch, yaw, roll=0)

# 摄像机对准目标坐标（返回yaw值）
yaw = BaseApi.set_collection_camera(target_pos)
```

---

## 物品与货币

```python
# 添加物品
BaseApi.add_item(item_id=30001001, count=10)

# 按名称查物品ID
item_id = BaseApi.get_item_id_by_name('木头')

# 查物品配置
info = BaseApi.get_item_info(item_id)

# 添加货币
BaseApi.add_money(coin_type=1, coin_num=9999)
```

---

## 制造系统

```python
# 查制造配方树（递归依赖）
forge_map = BaseApi.get_forge_map_tool(item_id)

# 获取需要采集的材料清单
find_map = BaseApi.get_find_map(forge_map, item_id, count)

# 获取制造顺序列表
make_order = BaseApi.get_make_order(forge_map, item_id, count)

# RPC制造工具
BaseApi.make_tool_by_rpc(args)

# RPC制造武器
BaseApi.make_weapon_by_rpc(args)

# RPC制造防具
BaseApi.make_armor_by_rpc(args)

# 领取完成的物品
BaseApi.rec_tool_by_rpc(args)
```

---

## UI操作

```python
# 按F触发交互
BaseApi.open_interact_ui()

# 检查Panel是否显示
is_shown = BaseApi.is_ui_showing('PanelBigMap')

# 显示/隐藏UI
BaseApi.show_ui('PanelXxx')
BaseApi.hide_ui('PanelXxx')

# 显示提示文字
BaseApi.show_hint('提示内容')

# 切换建造标签
BaseApi.switch_tab(main_tab_id=1, second_tab_id=0)

# 输入密码（数字序列）
BaseApi.input_password('1234')
```

---

## 对话系统

```python
# 获取当前对话类型（'对话' | '提示' | None）
dialog_type = BaseApi.get_dialog_type()

# 获取NPC提示 → {'title': ..., 'content': ...}
prompt = BaseApi.get_npc_prompt()

# 获取建造提示
prompt = BaseApi.get_build_prompt()

# 获取对话选项列表
options = BaseApi.get_dialog_options()    # ['选项1', '选项2', ...]

# 选择指定对话选项
BaseApi.dialog_select_option('我想交易')

# 获取提示文本框内容
text = BaseApi.get_dialog_text()    # {'title': ..., 'content': ...}
```

---

## 任务系统

```python
# 获取当前追踪任务ID
trigger_id = BaseApi.get_cur_track_trigger()

# 获取当前任务名称
name = BaseApi.get_cur_task_name()

# 获取当前任务目标坐标列表
pos_list = BaseApi.get_cur_task_pos()   # [vector, ...]

# 重置新手任务（解锁摇篮）
BaseApi.reset_newbie()
```

---

## 场景查询

```python
# 获取当前场景类型 → '过场动画' | '对话动画' | '普通场景'
scene = BaseApi.get_scene()

# 当前提示信息（NPC或建造）
prompt_str = BaseApi.get_prompt()
```
