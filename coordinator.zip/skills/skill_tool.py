"""
QA Agent System — Skill Tool

Converts SkillDefinitions into Agno @tool functions that, when called,
expand the SKILL.md prompt and return it as a string for the Agent to act on.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable, List

from agno.tools import tool

from skills.expander import expand_skill_prompt
from skills.loader import SkillDefinition

logger = logging.getLogger(__name__)


def make_skill_tool(skill: SkillDefinition) -> Callable:
    """Create an Agno @tool function from a SkillDefinition.

    The returned tool, when called by the Agent:
    1. Expands the SKILL.md prompt (variable substitution + shell commands)
    2. Returns the expanded prompt as a string
    3. The Agent receives this as tool output and continues acting on it

    Args:
        skill: A loaded SkillDefinition.

    Returns:
        A decorated Agno tool function.
    """
    skill_name = skill.name
    skill_desc = skill.description
    when_to_use = skill.when_to_use

    # Build LLM-visible description
    tool_description = skill_desc
    if when_to_use:
        tool_description += f"\n\n何时使用: {when_to_use}"
    if skill.args:
        tool_description += f"\n\n参数: {', '.join(skill.args)}"

    @tool(
        name=skill.tool_name,
        description=tool_description,
    )
    def skill_tool_fn(arguments: str = "") -> str:
        """Execute the skill and return the expanded prompt.

        Args:
            arguments: Space-separated arguments for the skill
                       (mapped to args defined in Frontmatter).

        Returns:
            Expanded prompt content for the Agent to act on.
        """
        logger.info("Executing skill '%s' (arguments=%r)", skill_name, arguments)

        expanded = expand_skill_prompt(
            template=skill.prompt_template,
            base_dir=skill.base_dir,
            args=skill.args,
            arguments=arguments,
        )

        logger.debug(
            "Skill '%s' expanded prompt (%d chars)",
            skill_name, len(expanded),
        )

        return expanded

    return skill_tool_fn


def build_skill_tools(skills: List[SkillDefinition]) -> List[Callable]:
    """Convert a list of SkillDefinitions into Agno tool functions.

    Args:
        skills: List of loaded SkillDefinition objects.

    Returns:
        List of Agno @tool functions, one per skill.
    """
    tool_fns = []
    for skill in skills:
        try:
            fn = make_skill_tool(skill)
            tool_fns.append(fn)
            logger.debug("Created skill tool: %s", skill.tool_name)
        except Exception:
            logger.exception("Failed to create tool for skill '%s'", skill.name)

    logger.info("Built %d skill tool(s)", len(tool_fns))
    return tool_fns
