"""
QA Agent System — Skill Loader

Scans project-level (.claude/skills/) and user-level (~/.qa-agent/skills/)
directories for SKILL.md files and returns parsed SkillDefinition objects.
Uses python-frontmatter for YAML Frontmatter parsing.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import frontmatter

logger = logging.getLogger(__name__)


@dataclass
class SkillDefinition:
    """Parsed definition of a single Skill from SKILL.md."""
    name: str                          # Directory name, used as tool identifier
    description: str                   # Required Frontmatter field
    prompt_template: str               # Markdown body (the expandable prompt)
    base_dir: Path                     # Absolute path to the Skill directory

    # Optional Frontmatter fields
    tools: List[str] = field(default_factory=list)
    agent: Optional[str] = None        # Bound Agent name
    paths: List[str] = field(default_factory=list)
    args: List[str] = field(default_factory=list)
    effort: int = 1                    # 1-5 scale
    when_to_use: str = ""

    @property
    def tool_name(self) -> str:
        """Agno tool name: skill__<skill-name>"""
        return f"skill__{self.name.replace('-', '_')}"


class SkillLoader:
    """Loads and indexes Skills from one or more directories.

    Skill discovery order (later entries shadow earlier on name conflict):
    1. User-level: ~/.qa-agent/skills/<name>/SKILL.md
    2. Project-level: .claude/skills/<name>/SKILL.md  ← highest priority
    """

    def __init__(self) -> None:
        self._skills: Dict[str, SkillDefinition] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_from_dirs(self, dirs: List[Path]) -> None:
        """Scan the given directories and load all valid Skills.

        Args:
            dirs: Ordered list of directories to scan (later dirs take priority).
        """
        for base in dirs:
            self._scan_directory(base)

        logger.info("Loaded %d skills from %d directories", len(self._skills), len(dirs))

    def get(self, name: str) -> Optional[SkillDefinition]:
        """Return a SkillDefinition by name, or None."""
        return self._skills.get(name)

    def all(self) -> List[SkillDefinition]:
        """Return all loaded SkillDefinitions."""
        return list(self._skills.values())

    def to_api_list(self) -> List[Dict]:
        """Return a JSON-serializable list for GET /skills."""
        return [
            {
                "name": s.name,
                "tool_name": s.tool_name,
                "description": s.description,
                "when_to_use": s.when_to_use,
                "tools": s.tools,
                "args": s.args,
                "effort": s.effort,
                "agent": s.agent,
            }
            for s in self._skills.values()
        ]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _scan_directory(self, base: Path) -> None:
        """Scan a single root directory for skill subdirectories."""
        if not base.exists() or not base.is_dir():
            logger.debug("Skill directory does not exist, skipping: %s", base)
            return

        for skill_dir in sorted(base.iterdir()):
            if not skill_dir.is_dir():
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                logger.warning("Skill dir '%s' has no SKILL.md, skipping", skill_dir.name)
                continue
            skill = self._parse_skill(skill_dir, skill_md)
            if skill is not None:
                self._skills[skill.name] = skill  # later dirs override earlier

    def _parse_skill(self, skill_dir: Path, skill_md: Path) -> Optional[SkillDefinition]:
        """Parse a SKILL.md file into a SkillDefinition."""
        try:
            post = frontmatter.load(str(skill_md))
        except Exception as e:
            logger.error("Failed to parse SKILL.md at %s: %s", skill_md, e)
            return None

        metadata = post.metadata
        description = metadata.get("description", "").strip()
        if not description:
            logger.error("Skill '%s' missing required 'description' field — skipped", skill_dir.name)
            return None

        # Validate effort
        effort = metadata.get("effort", 1)
        if not isinstance(effort, int) or not (1 <= effort <= 5):
            effort = 1

        skill = SkillDefinition(
            name=skill_dir.name,
            description=description,
            prompt_template=post.content,
            base_dir=skill_dir.resolve(),
            tools=metadata.get("tools", []) or [],
            agent=metadata.get("agent"),
            paths=metadata.get("paths", []) or [],
            args=metadata.get("args", []) or [],
            effort=effort,
            when_to_use=metadata.get("when_to_use", ""),
        )

        logger.debug(
            "Loaded skill '%s' (args=%s, effort=%d, bound_agent=%s)",
            skill.name, skill.args, skill.effort, skill.agent,
        )
        return skill


def load_skills(
    project_skills_dir: str = ".claude/skills",
    user_skills_dir: str = "~/.qa-agent/skills",
) -> SkillLoader:
    """Convenience function: create a SkillLoader with standard dirs."""
    loader = SkillLoader()
    dirs = [
        Path(user_skills_dir).expanduser(),
        Path(project_skills_dir),
    ]
    loader.load_from_dirs(dirs)
    return loader
