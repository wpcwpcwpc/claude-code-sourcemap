"""Tests for tools/bash_classifier.py"""

import pytest
from tools.bash_classifier import (
    CommandCategory,
    classify_command,
    is_read_only_command,
    split_pipeline,
    detect_sed_inplace,
)


# ═══════════════════════════════════════════════════════════════════════
# split_pipeline
# ═══════════════════════════════════════════════════════════════════════

class TestSplitPipeline:
    def test_single_command(self):
        assert split_pipeline("grep foo") == ["grep foo"]

    def test_pipe(self):
        assert split_pipeline("grep foo | sort | head -5") == ["grep foo", "sort", "head -5"]

    def test_and_operator(self):
        assert split_pipeline("cmd_a && cmd_b") == ["cmd_a", "cmd_b"]

    def test_or_operator(self):
        assert split_pipeline("cmd_a || cmd_b") == ["cmd_a", "cmd_b"]

    def test_semicolon(self):
        assert split_pipeline("cmd_a ; cmd_b") == ["cmd_a", "cmd_b"]

    def test_mixed_operators(self):
        result = split_pipeline("cmd_a | cmd_b && cmd_c || cmd_d ; cmd_e")
        assert result == ["cmd_a", "cmd_b", "cmd_c", "cmd_d", "cmd_e"]

    def test_quoted_pipe_not_split(self):
        result = split_pipeline('echo "a | b" && grep c')
        assert result == ['echo "a | b"', 'grep c']

    def test_single_quoted_pipe_not_split(self):
        result = split_pipeline("echo 'a | b' | grep c")
        assert result == ["echo 'a | b'", "grep c"]

    def test_empty_command(self):
        assert split_pipeline("") == []

    def test_escaped_characters(self):
        result = split_pipeline("echo \\| real_pipe | grep x")
        assert len(result) == 2


# ═══════════════════════════════════════════════════════════════════════
# classify_command
# ═══════════════════════════════════════════════════════════════════════

class TestClassifyCommand:
    # SEARCH
    @pytest.mark.parametrize("cmd", [
        "grep -r 'def test_' .",
        "find . -name '*.py'",
        "rg pattern",
        "ag 'function'",
        "locate config.py",
        "which python",
    ])
    def test_search_commands(self, cmd):
        assert classify_command(cmd) == CommandCategory.SEARCH

    # READ
    @pytest.mark.parametrize("cmd", [
        "cat config.py",
        "head -20 log.txt",
        "tail -f output.log",
        "wc -l *.py",
        "jq '.name' config.json",
        "sort data.csv",
        "diff a.txt b.txt",
    ])
    def test_read_commands(self, cmd):
        assert classify_command(cmd) == CommandCategory.READ

    # LIST
    @pytest.mark.parametrize("cmd", [
        "ls -la",
        "tree src/",
        "du -sh *",
    ])
    def test_list_commands(self, cmd):
        assert classify_command(cmd) == CommandCategory.LIST

    # NEUTRAL
    @pytest.mark.parametrize("cmd", [
        "echo 'hello'",
        "printf '%s' var",
        "true",
    ])
    def test_neutral_commands(self, cmd):
        assert classify_command(cmd) == CommandCategory.NEUTRAL

    # SILENT
    @pytest.mark.parametrize("cmd", [
        "mkdir -p /tmp/test",
        "cp a.txt b.txt",
        "chmod 755 script.sh",
        "touch newfile.txt",
        "rm old.log",
    ])
    def test_silent_commands(self, cmd):
        assert classify_command(cmd) == CommandCategory.SILENT

    # WRITE (default)
    @pytest.mark.parametrize("cmd", [
        "python run.py",
        "npm install",
        "pip install requests",
        "gcc main.c -o main",
        "pytest tests/",
    ])
    def test_write_commands(self, cmd):
        assert classify_command(cmd) == CommandCategory.WRITE

    # Pipeline classification
    def test_pipeline_last_meaningful(self):
        # grep (SEARCH) | sort (READ) | head (READ) → READ
        assert classify_command("grep foo | sort | head -5") == CommandCategory.READ

    def test_pipeline_with_neutral(self):
        # echo (NEUTRAL) | grep (SEARCH) → SEARCH
        assert classify_command("echo 'test' | grep foo") == CommandCategory.SEARCH

    # Wrapper commands
    def test_sudo_unwrapped(self):
        assert classify_command("sudo grep -r pattern .") == CommandCategory.SEARCH

    def test_env_unwrapped(self):
        assert classify_command("env LANG=C grep foo") == CommandCategory.SEARCH

    def test_path_qualified_command(self):
        assert classify_command("/usr/bin/grep pattern .") == CommandCategory.SEARCH

    def test_windows_exe_suffix(self):
        assert classify_command("grep.exe pattern .") == CommandCategory.SEARCH


# ═══════════════════════════════════════════════════════════════════════
# is_read_only_command
# ═══════════════════════════════════════════════════════════════════════

class TestIsReadOnly:
    # Read-only
    @pytest.mark.parametrize("cmd", [
        "grep 'pattern' file.txt",
        "grep 'pattern' file.txt | sort | head -5",
        "cat file.txt",
        "ls -la",
        "find . -name '*.py'",
        "echo 'hello'",
        "echo 'start' && grep -r 'test' . && echo 'done'",
    ])
    def test_read_only(self, cmd):
        assert is_read_only_command(cmd) is True

    # Not read-only
    @pytest.mark.parametrize("cmd", [
        "grep 'pattern' file.txt | xargs rm",
        "python run.py",
        "npm install",
        "mkdir -p /tmp/test",
        "cp a.txt b.txt",
    ])
    def test_not_read_only(self, cmd):
        assert is_read_only_command(cmd) is False

    # Redirect detection
    def test_redirect_to_file(self):
        assert is_read_only_command("grep 'pattern' file.txt > output.txt") is False

    def test_append_redirect(self):
        assert is_read_only_command("echo 'log' >> logfile.txt") is False

    def test_redirect_inside_quotes_ignored(self):
        # The > inside quotes should NOT make this non-read-only
        assert is_read_only_command("echo 'a > b'") is True


# ═══════════════════════════════════════════════════════════════════════
# detect_sed_inplace
# ═══════════════════════════════════════════════════════════════════════

class TestDetectSedInplace:
    def test_basic_sed_i(self):
        result = detect_sed_inplace("sed -i 's/old/new/g' config.py")
        assert result is not None
        file_path, old_pat, new_pat = result
        assert file_path == "config.py"
        assert old_pat == "old"
        assert new_pat == "new"

    def test_sed_in_place_long_flag(self):
        result = detect_sed_inplace("sed --in-place 's/foo/bar/' test.txt")
        assert result is not None

    def test_no_sed(self):
        assert detect_sed_inplace("grep pattern file.txt") is None

    def test_sed_without_i(self):
        """sed without -i is read-only (stdout only) — should return None."""
        assert detect_sed_inplace("sed 's/old/new/g' input.txt") is None

    def test_sed_pipe(self):
        """sed in a pipe (no -i) should return None."""
        assert detect_sed_inplace("cat file.txt | sed 's/old/new/'") is None
