"""
Tests for skills/loader.py and skills/expander.py
"""

import sys
from pathlib import Path

import pytest


# ======================================================================
# SkillLoader
# ======================================================================

class TestSkillLoader:

    def _write_skill(self, tmp_path: Path, name: str, description: str,
                     body: str = "Test prompt", extra_meta: str = "") -> Path:
        """Helper: write a SKILL.md in a tmp skills directory."""
        skill_dir = tmp_path / name
        skill_dir.mkdir(parents=True)
        md_content = f"---\ndescription: \"{description}\"\n{extra_meta}---\n\n{body}"
        (skill_dir / "SKILL.md").write_text(md_content, encoding="utf-8")
        return skill_dir

    def test_load_valid_skill(self, tmp_path):
        from skills.loader import SkillLoader

        self._write_skill(tmp_path, "my-skill", "Does something useful")
        loader = SkillLoader()
        loader.load_from_dirs([tmp_path])
        assert "my-skill" in [s.name for s in loader.all()]

    def test_missing_description_skipped(self, tmp_path):
        from skills.loader import SkillLoader

        skill_dir = tmp_path / "bad-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("---\neffort: 2\n---\n\nSome body", encoding="utf-8")

        loader = SkillLoader()
        loader.load_from_dirs([tmp_path])
        assert len(loader.all()) == 0

    def test_missing_skill_md_skipped(self, tmp_path):
        from skills.loader import SkillLoader

        # Directory without SKILL.md
        (tmp_path / "empty-skill").mkdir()

        loader = SkillLoader()
        loader.load_from_dirs([tmp_path])
        assert len(loader.all()) == 0

    def test_frontmatter_fields_parsed(self, tmp_path):
        from skills.loader import SkillLoader

        meta = (
            "tools:\n  - hunter_execute\n  - bash\n"
            "args:\n  - scenario\n  - platform\n"
            "effort: 3\n"
            "when_to_use: \"Use when testing on device\"\n"
            "agent: qa-automation-agent\n"
        )
        self._write_skill(tmp_path, "test-skill", "A test skill", "The body", extra_meta=meta)

        loader = SkillLoader()
        loader.load_from_dirs([tmp_path])

        skill = loader.get("test-skill")
        assert skill is not None
        assert skill.tools == ["hunter_execute", "bash"]
        assert skill.args == ["scenario", "platform"]
        assert skill.effort == 3
        assert skill.when_to_use == "Use when testing on device"
        assert skill.agent == "qa-automation-agent"

    def test_tool_name_format(self, tmp_path):
        from skills.loader import SkillLoader

        self._write_skill(tmp_path, "qa-debug-automation", "QA automation skill")
        loader = SkillLoader()
        loader.load_from_dirs([tmp_path])

        skill = loader.get("qa-debug-automation")
        assert skill.tool_name == "skill__qa_debug_automation"

    def test_later_dirs_override_earlier(self, tmp_path):
        """Project-level skills override user-level skills with same name."""
        from skills.loader import SkillLoader

        user_dir = tmp_path / "user"
        project_dir = tmp_path / "project"
        user_dir.mkdir()
        project_dir.mkdir()

        self._write_skill(user_dir, "shared-skill", "User version")
        self._write_skill(project_dir, "shared-skill", "Project version")

        loader = SkillLoader()
        loader.load_from_dirs([user_dir, project_dir])  # project dir last → wins

        skill = loader.get("shared-skill")
        assert skill.description == "Project version"

    def test_nonexistent_dir_skipped_gracefully(self):
        from skills.loader import SkillLoader

        loader = SkillLoader()
        loader.load_from_dirs([Path("/nonexistent/path/abc123")])
        assert len(loader.all()) == 0

    def test_to_api_list(self, tmp_path):
        from skills.loader import SkillLoader

        self._write_skill(tmp_path, "s1", "Skill one")
        self._write_skill(tmp_path, "s2", "Skill two")
        loader = SkillLoader()
        loader.load_from_dirs([tmp_path])

        api_list = loader.to_api_list()
        assert len(api_list) == 2
        names = {item["name"] for item in api_list}
        assert names == {"s1", "s2"}
        # All required fields present
        for item in api_list:
            assert "name" in item
            assert "tool_name" in item
            assert "description" in item


# ======================================================================
# SkillExpander
# ======================================================================

class TestSkillExpander:

    def test_arguments_substitution(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="Test: $ARGUMENTS done",
            base_dir=tmp_path,
            args=[],
            arguments="iOS 登录",
        )
        assert result == "Test: iOS 登录 done"

    def test_named_args_substitution(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="场景: $scenario, 平台: $platform",
            base_dir=tmp_path,
            args=["scenario", "platform"],
            arguments="战斗测试 Android",
        )
        assert "战斗测试" in result
        assert "Android" in result

    def test_last_arg_gets_remainder(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="第一: $first, 其余: $rest",
            base_dir=tmp_path,
            args=["first", "rest"],
            arguments="A B C D",
        )
        assert "A" in result
        assert "B C D" in result

    def test_skill_dir_variable(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="Dir: ${CLAUDE_SKILL_DIR}/scan.py",
            base_dir=tmp_path,
            args=[],
        )
        expected_dir = str(tmp_path).replace("\\", "/")
        assert expected_dir in result

    def test_unknown_variable_kept(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="Value: $unknown_var",
            base_dir=tmp_path,
            args=[],
        )
        # Unknown variables remain unchanged
        assert "$unknown_var" in result

    def test_shell_command_success(self, tmp_path):
        from skills.expander import expand_skill_prompt

        if sys.platform == "win32":
            cmd = "echo hello"
        else:
            cmd = "echo hello"

        result = expand_skill_prompt(
            template=f"Output: !`{cmd}`",
            base_dir=tmp_path,
            args=[],
        )
        assert "hello" in result
        assert "!`" not in result

    def test_shell_command_failure(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="Output: !`nonexistent_command_xyz_abc`",
            base_dir=tmp_path,
            args=[],
        )
        # Should contain failure placeholder, not raise
        assert "命令执行失败" in result or "命令执行错误" in result

    def test_no_args_provided(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="Args: $ARGUMENTS",
            base_dir=tmp_path,
            args=[],
            arguments="",
        )
        assert result == "Args: "

    def test_named_values_override(self, tmp_path):
        from skills.expander import expand_skill_prompt

        result = expand_skill_prompt(
            template="Scenario: $scenario",
            base_dir=tmp_path,
            args=["scenario"],
            arguments="original",
            named_values={"scenario": "override_value"},
        )
        assert "override_value" in result
