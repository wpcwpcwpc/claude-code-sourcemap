"""Tests for tools/semantic_params.py"""

import logging
import pytest
from tools.semantic_params import semantic_bool, semantic_int, semantic_float, strip_unknown_params


class TestSemanticBool:
    """semantic_bool: LLM string variants → Python bool."""

    @pytest.mark.parametrize("value", [True, "true", "True", "TRUE", "yes", "Yes", "1", "on", "y", "t"])
    def test_truthy_values(self, value):
        assert semantic_bool(value) is True

    @pytest.mark.parametrize("value", [False, "false", "False", "FALSE", "no", "No", "0", "off", "n", "f", "", "none", "null"])
    def test_falsy_values(self, value):
        assert semantic_bool(value) is False

    def test_int_truthy(self):
        assert semantic_bool(1) is True
        assert semantic_bool(42) is True

    def test_int_falsy(self):
        assert semantic_bool(0) is False

    def test_none_with_default(self):
        assert semantic_bool(None, default=True) is True
        assert semantic_bool(None, default=False) is False

    def test_none_without_default_raises(self):
        with pytest.raises(ValueError, match="Cannot parse None"):
            semantic_bool(None)

    def test_unparseable_raises(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            semantic_bool("maybe")

    def test_whitespace_stripped(self):
        assert semantic_bool("  true  ") is True
        assert semantic_bool(" false ") is False


class TestSemanticInt:
    """semantic_int: LLM string numbers → Python int."""

    def test_int_passthrough(self):
        assert semantic_int(42) == 42
        assert semantic_int(0) == 0
        assert semantic_int(-5) == -5

    def test_string_number(self):
        assert semantic_int("30") == 30
        assert semantic_int(" 100 ") == 100
        assert semantic_int("-7") == -7

    def test_string_float_lossless(self):
        assert semantic_int("30.0") == 30

    def test_float_lossless(self):
        assert semantic_int(30.0) == 30

    def test_float_lossy_raises(self):
        with pytest.raises(ValueError, match="losslessly"):
            semantic_int(30.5)

    def test_bool_excluded(self):
        # bool is subclass of int in Python; semantic_int should not accept True/False
        with pytest.raises((ValueError, TypeError)):
            semantic_int(True)

    def test_none_with_default(self):
        assert semantic_int(None, default=60) == 60

    def test_none_without_default_raises(self):
        with pytest.raises(ValueError):
            semantic_int(None)

    def test_unparseable_raises(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            semantic_int("thirty")


class TestSemanticFloat:
    """semantic_float: LLM string numbers → Python float."""

    def test_float_passthrough(self):
        assert semantic_float(3.14) == 3.14

    def test_int_to_float(self):
        assert semantic_float(42) == 42.0

    def test_string_float(self):
        assert semantic_float("3.14") == 3.14
        assert semantic_float(" 0.5 ") == 0.5

    def test_none_with_default(self):
        assert semantic_float(None, default=1.0) == 1.0

    def test_unparseable_raises(self):
        with pytest.raises(ValueError):
            semantic_float("pi")


class TestStripUnknownParams:
    """strip_unknown_params: filter out unexpected tool call arguments."""

    def test_all_known(self):
        result = strip_unknown_params(
            {"path": "a.py", "limit": 100},
            {"path", "limit", "offset"},
            tool_name="file_read",
        )
        assert result == {"path": "a.py", "limit": 100}

    def test_unknown_removed(self):
        result = strip_unknown_params(
            {"path": "a.py", "verbose": True, "debug": "yes"},
            {"path", "limit"},
            tool_name="file_read",
        )
        assert result == {"path": "a.py"}

    def test_unknown_logs_warning(self, caplog):
        with caplog.at_level(logging.WARNING):
            strip_unknown_params(
                {"path": "a.py", "extra": 1},
                {"path"},
                tool_name="test_tool",
            )
        assert "Ignoring unknown parameters" in caplog.text
        assert "extra" in caplog.text

    def test_empty_params(self):
        result = strip_unknown_params({}, {"path"}, tool_name="test")
        assert result == {}
