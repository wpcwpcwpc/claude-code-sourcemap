"""
Tests for memory system:
- memory/embedder.py   (zero vector fallback)
- memory/milvus_client.py (degraded mode)
- memory/conclusion_writer.py (human_confirmed guard)
- memory/distiller.py  (_parse_summary)
- memory/injector.py   (degraded mode returns empty string)
"""

import pytest


# ======================================================================
# Embedder — degraded mode (no real API in tests)
# ======================================================================

class TestEmbedder:

    @pytest.mark.asyncio
    async def test_zero_vector_on_api_failure(self):
        """Without a real API key, embed should return a zero vector."""
        from memory.embedder import Embedder, EMBEDDING_DIM

        embedder = Embedder(
            model="text-embedding-3-small",
            api_key="invalid-key",
            base_url="http://localhost:99999",  # unreachable
        )
        vector = await embedder.embed("test text")
        assert len(vector) == EMBEDDING_DIM
        assert all(v == 0.0 for v in vector)

    @pytest.mark.asyncio
    async def test_embed_batch_returns_correct_count(self):
        from memory.embedder import Embedder

        embedder = Embedder(api_key="invalid", base_url="http://localhost:99999")
        texts = ["text one", "text two", "text three"]
        results = await embedder.embed_batch(texts)
        assert len(results) == 3

    def test_zero_vector_dimension(self):
        from memory.embedder import Embedder, EMBEDDING_DIM
        vec = Embedder._zero_vector()
        assert len(vec) == EMBEDDING_DIM
        assert all(isinstance(v, float) for v in vec)


# ======================================================================
# MilvusClient — disabled/degraded mode
# ======================================================================

class TestMilvusClientDegraded:

    def test_disabled_client_not_available(self):
        from memory.milvus_client import MilvusClient
        client = MilvusClient(enabled=False)
        client.connect()
        assert client.is_available is False

    @pytest.mark.asyncio
    async def test_insert_returns_false_when_degraded(self):
        from memory.milvus_client import MilvusClient
        client = MilvusClient(enabled=False)
        client.connect()
        result = await client.insert("qa_execution_log", {"field": [1]})
        assert result is False

    @pytest.mark.asyncio
    async def test_search_returns_empty_when_degraded(self):
        from memory.milvus_client import MilvusClient
        client = MilvusClient(enabled=False)
        client.connect()
        result = await client.search(
            collection_name="qa_execution_log",
            vector=[0.0] * 1536,
        )
        assert result == []

    def test_collection_exists_returns_false_when_degraded(self):
        from memory.milvus_client import MilvusClient
        client = MilvusClient(enabled=False)
        client.connect()
        assert client.collection_exists("qa_execution_log") is False

    def test_unavailable_milvus_connect_fails_gracefully(self):
        """Connection to unreachable host should degrade gracefully."""
        from memory.milvus_client import MilvusClient
        client = MilvusClient(host="127.0.0.1", port=19999, enabled=True)
        result = client.connect()
        assert result is False
        assert client.is_available is False


# ======================================================================
# Conclusion Writer — human_confirmed guard
# ======================================================================

class TestConclusionWriter:

    @pytest.mark.asyncio
    async def test_raises_if_not_human_confirmed(self):
        from memory.conclusion_writer import write_conclusion, UnconfirmedConclusionError

        with pytest.raises(UnconfirmedConclusionError):
            await write_conclusion({
                "session_id": "test-123",
                "verdict": "pass",
                "human_confirmed": False,  # ← should raise
                "key_findings": "All tests passed",
                "bugs_found": "None",
            })

    @pytest.mark.asyncio
    async def test_raises_if_human_confirmed_missing(self):
        from memory.conclusion_writer import write_conclusion, UnconfirmedConclusionError

        with pytest.raises(UnconfirmedConclusionError):
            await write_conclusion({
                "session_id": "test-456",
                "verdict": "fail",
                # human_confirmed not set → defaults to False
            })

    @pytest.mark.asyncio
    async def test_returns_false_when_milvus_unavailable(self):
        """With Milvus disabled, should return False (not raise)."""
        from memory.conclusion_writer import write_conclusion
        from unittest.mock import AsyncMock, patch, MagicMock

        # Mock the milvus client to be unavailable
        mock_client = MagicMock()
        mock_client.is_available = False

        with patch("memory.conclusion_writer.get_milvus_client", return_value=mock_client):
            result = await write_conclusion({
                "session_id": "test-789",
                "verdict": "pass",
                "human_confirmed": True,
                "confirmed_by": "tester_01",
                "key_findings": "All good",
                "bugs_found": "None",
                "game_version": "v2.4",
                "module": "combat",
            })
            assert result is False


# ======================================================================
# Distiller — _parse_summary
# ======================================================================

class TestDistiller:

    def test_parse_valid_json(self):
        from memory.distiller import _parse_summary

        raw = '''{
  "completed_steps": "步骤1\\n步骤2",
  "pending_steps": "步骤3\\n步骤4",
  "findings": "发现BUG-001",
  "context_coverage": "战斗系统基础测试"
}'''
        result = _parse_summary(raw)
        assert result is not None
        assert "步骤1" in result["completed_steps"]
        assert "步骤3" in result["pending_steps"]
        assert "BUG-001" in result["findings"]
        assert result["context_coverage"] == "战斗系统基础测试"

    def test_parse_json_with_code_fence(self):
        from memory.distiller import _parse_summary

        raw = '''```json
{"completed_steps": "done", "pending_steps": "todo", "findings": "ok", "context_coverage": "test"}
```'''
        result = _parse_summary(raw)
        assert result is not None
        assert result["completed_steps"] == "done"

    def test_parse_invalid_json_fallback(self):
        from memory.distiller import _parse_summary

        raw = "这是一段普通文本，不是JSON"
        result = _parse_summary(raw)
        assert result is not None
        # Falls back to raw text in pending_steps
        assert "普通文本" in result["pending_steps"]
        assert "解析失败" in result["context_coverage"]


# ======================================================================
# Injector — degraded mode
# ======================================================================

class TestInjector:

    @pytest.mark.asyncio
    async def test_returns_empty_when_milvus_unavailable(self):
        from memory.injector import inject_historical_context
        from unittest.mock import MagicMock, patch

        mock_client = MagicMock()
        mock_client.is_available = False

        with patch("memory.injector.get_milvus_client", return_value=mock_client):
            result = await inject_historical_context("测试战斗系统伤害计算")
            assert result == ""

    @pytest.mark.asyncio
    async def test_returns_formatted_context_when_hits_found(self):
        from memory.injector import inject_historical_context
        from unittest.mock import AsyncMock, MagicMock, patch

        mock_client = MagicMock()
        mock_client.is_available = True
        mock_client.search = AsyncMock(side_effect=[
            # Knowledge hits
            [{
                "_distance": 0.1,
                "_id": 1,
                "completed_steps": "完成步骤A",
                "pending_steps": "待续步骤B",
                "findings": "发现问题X",
                "module": "combat",
                "game_version": "v2.4",
            }],
            # Execution log hits
            [{
                "_distance": 0.2,
                "_id": 2,
                "tool_used": "bash",
                "result_summary": "执行成功",
                "module": "combat",
                "game_version": "v2.4",
                "step_no": 1,
            }],
        ])

        mock_embedder = MagicMock()
        mock_embedder.embed = AsyncMock(return_value=[0.0] * 1536)

        with patch("memory.injector.get_milvus_client", return_value=mock_client), \
             patch("memory.injector.get_embedder", return_value=mock_embedder):
            result = await inject_historical_context("测试战斗系统", module="combat")

        assert "Related Historical Knowledge" in result
        assert "待续步骤B" in result
        assert "发现问题X" in result
