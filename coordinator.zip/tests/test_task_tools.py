"""Tests for tools/task_tools.py — task_list and task_update tools."""

import json
import pytest
from dataclasses import dataclass, field
from typing import Optional, Dict

from tools.task_tools import task_list, task_update, NO_PLAN_GUIDE
from core.task_plan import TaskPlan


# ── Fake agent with session_state ──────────────────────────────────


@dataclass
class FakeSessionState:
    task_plan: Optional[Dict] = None
    session_id: str = "test-session"


class FakeAgent:
    def __init__(self, plan_dict: Optional[Dict] = None):
        self.session_state = FakeSessionState(task_plan=plan_dict)


def _create_plan_json(
    goal: str = "Test goal",
    strategy: str = "Test strategy",
    tasks: list = None,
) -> str:
    return json.dumps({
        "goal": goal,
        "strategy": strategy,
        "tasks": tasks or ["Step 1", "Step 2", "Step 3"],
    })


# ═══════════════════════════════════════════════════════════════════
# task_list tests
# ═══════════════════════════════════════════════════════════════════


class TestTaskList:
    def test_no_plan_returns_guide(self):
        agent = FakeAgent()
        result = task_list(agent)
        assert "No task plan yet" in result
        assert "task_update" in result

    def test_with_plan_returns_summary(self):
        plan = TaskPlan.from_create_json({
            "goal": "Test combat",
            "strategy": "Read and verify",
            "tasks": ["Read config", "Write script", "Execute"],
        })
        agent = FakeAgent(plan_dict=plan.to_dict())
        result = task_list(agent)
        assert "Test combat" in result
        assert "Read config" in result
        assert "0/3" in result or "Progress" in result


# ═══════════════════════════════════════════════════════════════════
# task_update — Create plan
# ═══════════════════════════════════════════════════════════════════


class TestTaskUpdateCreate:
    def test_create_plan_success(self):
        agent = FakeAgent()
        summary = _create_plan_json()
        result = task_update(agent, task_id=0, status="create", summary=summary)
        assert "Task plan created" in result
        assert agent.session_state.task_plan is not None
        plan = TaskPlan.from_dict(agent.session_state.task_plan)
        assert plan.goal == "Test goal"
        assert len(plan.tasks) == 3
        assert plan.tasks[0].status == "active"

    def test_create_plan_empty_summary(self):
        agent = FakeAgent()
        result = task_update(agent, task_id=0, status="create", summary="")
        assert "summary parameter is required" in result

    def test_create_plan_invalid_json(self):
        agent = FakeAgent()
        result = task_update(agent, task_id=0, status="create", summary="not json")
        assert "Failed to parse" in result
        assert "Expected JSON format" in result

    def test_create_plan_missing_goal(self):
        agent = FakeAgent()
        summary = json.dumps({"tasks": ["x", "y", "z"]})
        result = task_update(agent, task_id=0, status="create", summary=summary)
        assert "goal" in result.lower()

    def test_create_plan_too_few_tasks(self):
        agent = FakeAgent()
        summary = json.dumps({"goal": "x", "strategy": "y", "tasks": ["only one"]})
        result = task_update(agent, task_id=0, status="create", summary=summary)
        assert "1 task" in result

    def test_create_plan_too_many_tasks(self):
        agent = FakeAgent()
        tasks = [f"step {i}" for i in range(20)]
        summary = json.dumps({"goal": "x", "strategy": "y", "tasks": tasks})
        result = task_update(agent, task_id=0, status="create", summary=summary)
        assert "too many" in result.lower()

    def test_create_plan_blocks_if_active_plan_exists(self):
        # Create initial plan
        plan = TaskPlan.from_create_json({
            "goal": "Existing", "strategy": "s", "tasks": ["a", "b", "c"],
        })
        agent = FakeAgent(plan_dict=plan.to_dict())

        # Try to create another
        result = task_update(agent, task_id=0, status="create", summary=_create_plan_json())
        assert "already exists" in result

    def test_create_plan_allowed_if_previous_complete(self):
        # Create and complete a plan
        plan = TaskPlan.from_create_json({
            "goal": "Done", "strategy": "s", "tasks": ["a", "b"],
        })
        plan.mark_task(1, "done")
        plan.mark_task(2, "done")
        agent = FakeAgent(plan_dict=plan.to_dict())

        # Should allow creating new plan
        result = task_update(agent, task_id=0, status="create", summary=_create_plan_json())
        assert "Task plan created" in result


# ═══════════════════════════════════════════════════════════════════
# task_update — Update tasks
# ═══════════════════════════════════════════════════════════════════


class TestTaskUpdateStatus:
    def _agent_with_plan(self) -> FakeAgent:
        plan = TaskPlan.from_create_json({
            "goal": "Test", "strategy": "Run tests",
            "tasks": ["Read files", "Write tests", "Execute"],
        })
        return FakeAgent(plan_dict=plan.to_dict())

    def test_mark_done(self):
        agent = self._agent_with_plan()
        result = task_update(agent, task_id=1, status="done", summary="Read 5 files")
        assert "marked as done" in result
        assert "Read 5 files" in result

        plan = TaskPlan.from_dict(agent.session_state.task_plan)
        assert plan.tasks[0].status == "done"
        assert plan.tasks[1].status == "active"  # auto-advanced

    def test_mark_failed(self):
        agent = self._agent_with_plan()
        result = task_update(agent, task_id=1, status="failed", summary="Timeout")
        assert "marked as failed" in result
        plan = TaskPlan.from_dict(agent.session_state.task_plan)
        assert plan.tasks[0].status == "failed"
        assert plan.tasks[1].status == "active"

    def test_mark_skipped(self):
        agent = self._agent_with_plan()
        result = task_update(agent, task_id=1, status="skipped", summary="N/A")
        assert "marked as skipped" in result

    def test_all_tasks_complete(self):
        agent = self._agent_with_plan()
        task_update(agent, task_id=1, status="done")
        task_update(agent, task_id=2, status="done")
        result = task_update(agent, task_id=3, status="done")
        assert "All tasks complete" in result

    def test_invalid_task_id(self):
        agent = self._agent_with_plan()
        result = task_update(agent, task_id=99, status="done")
        assert "Task ID 99 not found" in result
        assert "task_list()" in result

    def test_invalid_status(self):
        agent = self._agent_with_plan()
        result = task_update(agent, task_id=1, status="invalid_status")
        assert "Invalid status" in result

    def test_no_plan_returns_guidance(self):
        agent = FakeAgent()
        result = task_update(agent, task_id=1, status="done")
        assert "No task plan exists" in result

    def test_create_with_wrong_task_id(self):
        agent = FakeAgent()
        result = task_update(agent, task_id=5, status="create")
        assert "task_id=0" in result
