"""Tests for tools/bash_tool.py (v3)"""

import sys
import pytest
from unittest.mock import patch, MagicMock
from tools.bash_tool import bash


class TestSedInterception:
    """sed -i commands should be intercepted and guided to file_edit."""

    def test_sed_i_intercepted(self):
        result = bash(command="sed -i 's/old/new/g' config.py")
        assert "file_edit" in result
        assert "Instead of sed -i" in result

    def test_sed_without_i_allowed(self):
        """sed without -i is read-only and should execute normally."""
        result = bash(command="echo 'hello' | sed 's/hello/world/'")
        # Should actually execute, not intercept
        assert "file_edit" not in result


class TestBlacklist:
    def test_dangerous_command_blocked(self):
        result = bash(command="rm -rf /")
        assert "blocked" in result.lower() or "Error" in result

    def test_mkfs_blocked(self):
        result = bash(command="mkfs.ext4 /dev/sda1")
        assert "blocked" in result.lower() or "Error" in result

    def test_safe_rm_allowed(self):
        """rm of specific file should NOT be blocked."""
        # This will fail because file doesn't exist, but should not be blocked
        result = bash(command="rm nonexistent_file_12345.txt")
        assert "blocked" not in result.lower()


class TestEmptyCommand:
    def test_empty_string(self):
        result = bash(command="")
        assert "Error" in result
        assert "Empty command" in result

    def test_whitespace_only(self):
        result = bash(command="   ")
        assert "Error" in result


class TestSilentCommand:
    @pytest.mark.skipif(sys.platform == "win32", reason="mkdir -p is Unix")
    def test_mkdir_no_output_ok(self, tmp_path):
        result = bash(command=f"mkdir -p {tmp_path}/test_dir_bash_tool")
        assert "completed successfully" in result

    def test_echo_has_output(self):
        result = bash(command="echo hello_from_bash_test")
        assert "hello_from_bash_test" in result


class TestBackgroundExecution:
    def test_explicit_background(self):
        result = bash(command="echo bg_test", run_in_background=True)
        assert "background" in result.lower()
        assert "Task ID:" in result

    def test_bg_status_query(self):
        # Start a task first
        result1 = bash(command="echo bg_status_test", run_in_background=True)
        # Extract task ID
        for line in result1.split("\n"):
            if "Task ID:" in line:
                task_id = line.split("Task ID:")[1].strip()
                break
        else:
            pytest.skip("Could not extract task ID")

        # Query status
        import time
        time.sleep(0.5)  # Let it complete
        result2 = bash(command=f"bg_status {task_id}")
        assert "Status:" in result2
        assert task_id in result2

    def test_bg_status_nonexistent(self):
        result = bash(command="bg_status nonexistent_id")
        assert "Error" in result
        assert "No background task" in result


class TestExitCodeSemantics:
    """Known exit codes should get helpful annotations."""

    @pytest.mark.skipif(sys.platform == "win32", reason="grep not available on Windows")
    def test_grep_no_match_not_error(self):
        result = bash(command="grep 'zzz_impossible_pattern_zzz' /dev/null")
        # grep returns 1 for no match — should NOT be formatted as error
        assert "not an error" in result.lower() or "No matches found" in result

    def test_echo_exit_0(self):
        result = bash(command="echo success_test")
        assert "success_test" in result
        assert "Exit code" not in result  # exit 0 should not show exit code


class TestTimeoutBehavior:
    def test_user_timeout_overrides(self):
        """User-specified timeout should be respected."""
        # This should complete within the timeout
        result = bash(command="echo fast", timeout=60)
        assert "fast" in result

    def test_description_in_logging(self):
        """description field should not affect execution."""
        result = bash(
            command="echo desc_test",
            description="Testing description field",
        )
        assert "desc_test" in result


class TestGuidedErrors:
    @pytest.mark.skipif(sys.platform == "win32", reason="command_not_exists behavior differs")
    def test_command_not_found(self):
        result = bash(command="zzz_nonexistent_command_zzz")
        # Should get a helpful error
        assert "Error" in result or "not found" in result.lower()
