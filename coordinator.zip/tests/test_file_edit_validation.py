"""Tests for file_edit validateInput chain (Task 2.4)"""

import time
from pathlib import Path

import pytest
from tools.file_tools import file_read, file_edit
from tools.file_state_cache import get_file_state_cache


@pytest.fixture(autouse=True)
def fresh_cache():
    cache = get_file_state_cache()
    cache.clear()
    yield cache


@pytest.fixture
def sample_file(tmp_path):
    f = tmp_path / "sample.py"
    f.write_text("def hello():\n    print('hello')\n    return True\n", encoding="utf-8")
    return f


@pytest.fixture
def read_sample(sample_file):
    """Read the sample file first (required before editing)."""
    file_read(str(sample_file))
    return sample_file


class TestFileEditValidation:
    """Validation chain scenarios from spec."""

    def test_no_op_detection(self, read_sample):
        result = file_edit(
            file_path=str(read_sample),
            old_string="print('hello')",
            new_string="print('hello')",  # Same!
        )
        assert "Validation error" in result
        assert "identical" in result

    def test_read_before_write_enforced(self, sample_file):
        """Must read file before editing — no prior file_read."""
        result = file_edit(
            file_path=str(sample_file),
            old_string="print('hello')",
            new_string="print('world')",
        )
        assert "Validation error" in result
        assert "must read the file" in result.lower()

    def test_external_modification_detected(self, read_sample):
        # Modify file externally after read
        time.sleep(0.05)
        read_sample.write_text("modified externally\n", encoding="utf-8")

        result = file_edit(
            file_path=str(read_sample),
            old_string="print('hello')",
            new_string="print('world')",
        )
        assert "Validation error" in result
        assert "modified since" in result.lower()

    def test_old_string_not_found(self, read_sample):
        result = file_edit(
            file_path=str(read_sample),
            old_string="this text does not exist in the file",
            new_string="replacement",
        )
        assert "Validation error" in result
        assert "not found" in result.lower()

    def test_old_string_whitespace_mismatch_hint(self, read_sample):
        """When old_string differs only in whitespace, give a helpful hint."""
        result = file_edit(
            file_path=str(read_sample),
            old_string="def hello( ):\nprint('hello')",  # wrong indentation
            new_string="replacement",
        )
        assert "Validation error" in result
        # Should suggest whitespace issue or not found
        assert "not found" in result.lower() or "whitespace" in result.lower()

    def test_multiple_matches_rejected(self, tmp_path):
        f = tmp_path / "multi.py"
        f.write_text("x = 1\nx = 1\nx = 1\n", encoding="utf-8")
        file_read(str(f))

        result = file_edit(
            file_path=str(f),
            old_string="x = 1",
            new_string="x = 2",
        )
        assert "Validation error" in result
        assert "3 matches" in result

    def test_multiple_matches_with_replace_all(self, tmp_path):
        f = tmp_path / "multi.py"
        f.write_text("x = 1\nx = 1\nx = 1\n", encoding="utf-8")
        file_read(str(f))

        result = file_edit(
            file_path=str(f),
            old_string="x = 1",
            new_string="x = 2",
            replace_all=True,
        )
        assert "Successfully edited" in result
        assert "3 occurrences" in result
        assert f.read_text() == "x = 2\nx = 2\nx = 2\n"

    def test_create_new_file(self, tmp_path):
        new_file = tmp_path / "brand_new.py"
        result = file_edit(
            file_path=str(new_file),
            old_string="",
            new_string="# new file\nprint('created')\n",
        )
        assert "Created new file" in result
        assert new_file.exists()
        assert "print('created')" in new_file.read_text()

    def test_create_file_already_exists_rejected(self, read_sample):
        result = file_edit(
            file_path=str(read_sample),
            old_string="",
            new_string="overwrite attempt",
        )
        assert "Validation error" in result
        assert "already exists" in result.lower()

    def test_file_not_found(self):
        result = file_edit(
            file_path="/nonexistent/path/file.py",
            old_string="some text",
            new_string="replacement",
        )
        assert "Validation error" in result
        assert "not found" in result.lower()


class TestFileEditExecution:
    """Successful edit scenarios."""

    def test_single_replacement(self, read_sample):
        result = file_edit(
            file_path=str(read_sample),
            old_string="print('hello')",
            new_string="print('world')",
        )
        assert "Successfully edited" in result
        content = read_sample.read_text()
        assert "print('world')" in content
        assert "print('hello')" not in content

    def test_multiline_replacement(self, read_sample):
        result = file_edit(
            file_path=str(read_sample),
            old_string="    print('hello')\n    return True",
            new_string="    print('goodbye')\n    logging.info('done')\n    return False",
        )
        assert "Successfully edited" in result
        content = read_sample.read_text()
        assert "print('goodbye')" in content
        assert "logging.info('done')" in content

    def test_cache_updated_after_edit(self, read_sample):
        """After edit, the cache should be updated so subsequent edits work."""
        file_edit(
            file_path=str(read_sample),
            old_string="print('hello')",
            new_string="print('world')",
        )
        # Second edit should work without re-reading
        result = file_edit(
            file_path=str(read_sample),
            old_string="print('world')",
            new_string="print('universe')",
        )
        assert "Successfully edited" in result
        assert "print('universe')" in read_sample.read_text()


class TestFileReadCacheIntegration:
    """file_read → ReadFileStateCache recording."""

    def test_file_read_records_state(self, sample_file):
        cache = get_file_state_cache()
        assert cache.get_record(str(sample_file)) is None

        file_read(str(sample_file))

        record = cache.get_record(str(sample_file))
        assert record is not None
        assert record.mtime > 0

    def test_partial_read_recorded(self, sample_file):
        cache = get_file_state_cache()
        file_read(str(sample_file), offset=1, limit=1)

        record = cache.get_record(str(sample_file))
        assert record is not None
        assert record.is_partial is True
