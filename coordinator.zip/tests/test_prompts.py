"""Tests for core/prompts.py — System Prompt tool usage section."""

import pytest
from core.prompts import (
    get_tool_usage_section,
    get_coordinator_tool_section,
    get_task_management_section,
    build_system_prompt,
    PLAN_FIRST_INSTRUCTIONS,
    TOOL_ANTI_PATTERNS,
)


class TestGetToolUsageSection:
    """get_tool_usage_section generates correct tool guidance."""

    def test_contains_file_read_guidance(self):
        section = get_tool_usage_section()
        assert "file_read" in section
        assert "cat" in section  # "instead of cat"

    def test_contains_file_edit_guidance(self):
        section = get_tool_usage_section()
        assert "file_edit" in section
        assert "sed" in section  # "instead of sed"

    def test_contains_grep_guidance(self):
        section = get_tool_usage_section()
        assert "grep" in section

    def test_contains_glob_guidance(self):
        section = get_tool_usage_section()
        assert "glob_search" in section
        assert "find" in section  # "instead of find"

    def test_contains_bash_reservation(self):
        section = get_tool_usage_section()
        assert "Reserve" in section or "exclusively" in section

    def test_contains_read_before_edit(self):
        section = get_tool_usage_section()
        assert "measure twice" in section.lower() or "ALWAYS read" in section

    def test_contains_parallel_guidance(self):
        section = get_tool_usage_section()
        assert "parallel" in section.lower()

    def test_contains_work_approach(self):
        section = get_tool_usage_section()
        assert "Explore first" in section
        assert "Plan" in section
        assert "Verify" in section

    def test_respects_enabled_tools(self):
        """When only specific tools enabled, only relevant guidance appears."""
        section = get_tool_usage_section(enabled_tools={"file_read", "bash"})
        assert "file_read" in section
        # file_edit is not enabled, so its section should not appear
        assert "search/replace" not in section

    def test_no_bash_no_antipatterns(self):
        """When bash is not in enabled_tools, no 'instead of bash' rules."""
        section = get_tool_usage_section(enabled_tools={"file_read", "file_edit"})
        assert "instead of bash" not in section


class TestGetCoordinatorToolSection:
    def test_contains_coordinator_identity(self):
        section = get_coordinator_tool_section()
        assert "Coordinator" in section
        assert "orchestrator" in section

    def test_contains_only_three_tools(self):
        section = get_coordinator_tool_section()
        assert "agent_spawn" in section
        assert "send_message" in section
        assert "task_stop" in section

    def test_contains_four_phases(self):
        section = get_coordinator_tool_section()
        assert "RESEARCH" in section
        assert "SYNTHESIS" in section
        assert "IMPLEMENTATION" in section
        assert "VERIFICATION" in section

    def test_contains_anti_vague_instructions(self):
        section = get_coordinator_tool_section()
        assert "DO NOT give vague" in section or "DO NOT" in section


class TestBuildSystemPrompt:
    def test_includes_agent_instructions(self):
        prompt = build_system_prompt(
            agent_instructions="You are a QA expert."
        )
        assert "You are a QA expert." in prompt

    def test_includes_tool_usage(self):
        prompt = build_system_prompt()
        assert "Using your tools" in prompt

    def test_coordinator_mode(self):
        prompt = build_system_prompt(is_coordinator=True)
        assert "Coordinator" in prompt
        assert "agent_spawn" in prompt

    def test_includes_memory_section(self):
        prompt = build_system_prompt(memory_section="# Memory\nRemember this.")
        assert "Remember this." in prompt

    def test_includes_env_info(self):
        prompt = build_system_prompt(env_info="# Environment\nPython 3.11")
        assert "Python 3.11" in prompt


class TestGetTaskManagementSection:
    """get_task_management_section generates task management guidance."""

    def test_contains_task_list_instruction(self):
        section = get_task_management_section()
        assert "task_list()" in section

    def test_contains_task_update_instruction(self):
        section = get_task_management_section()
        assert "task_update" in section

    def test_contains_create_instruction(self):
        section = get_task_management_section()
        assert "create" in section.lower()

    def test_contains_goal_strategy_tasks(self):
        section = get_task_management_section()
        assert "goal" in section
        assert "strategy" in section
        assert "tasks" in section

    def test_contains_status_done(self):
        section = get_task_management_section()
        assert '"done"' in section

    def test_contains_status_failed(self):
        section = get_task_management_section()
        assert '"failed"' in section

    def test_contains_task_management_header(self):
        section = get_task_management_section()
        assert "## Task Management" in section


class TestBackwardCompatExports:
    """PLAN_FIRST_INSTRUCTIONS and TOOL_ANTI_PATTERNS used by core/engine.py."""

    def test_plan_first_exists(self):
        assert "Plan first" in PLAN_FIRST_INSTRUCTIONS or "Explore first" in PLAN_FIRST_INSTRUCTIONS

    def test_tool_anti_patterns_exists(self):
        assert "file_read" in TOOL_ANTI_PATTERNS
        assert "file_edit" in TOOL_ANTI_PATTERNS
        assert "bash" in TOOL_ANTI_PATTERNS
        assert "measure twice" in TOOL_ANTI_PATTERNS
