"""
Tests for tools/base.py, tools/registry.py, and built-in tools.
"""

import pytest


# ======================================================================
# Tool Metadata (tools/base.py)
# ======================================================================

class TestToolMeta:

    def test_permission_level_enum(self):
        from tools.base import PermissionLevel
        assert PermissionLevel.L1_AUTO == 1
        assert PermissionLevel.L2_CONFIRM == 2
        assert PermissionLevel.L3_VERIFY == 3
        assert PermissionLevel.L4_HUMAN_ONLY == 4

    def test_readonly_meta_template(self):
        from tools.base import readonly_meta, PermissionLevel
        meta = readonly_meta("Read a file", "file")
        assert meta["permission_level"] == PermissionLevel.L1_AUTO
        assert meta["is_read_only"] is True
        assert meta["is_concurrency_safe"] is True
        assert meta["is_destructive"] is False
        assert meta["category"] == "file"

    def test_sideeffect_meta_template(self):
        from tools.base import sideeffect_meta, PermissionLevel
        meta = sideeffect_meta("Execute bash", "execution")
        assert meta["permission_level"] == PermissionLevel.L2_CONFIRM
        assert meta["is_read_only"] is False
        assert meta["is_concurrency_safe"] is False

    def test_destructive_meta_template(self):
        from tools.base import destructive_meta, PermissionLevel
        meta = destructive_meta("Delete files", "file")
        assert meta["permission_level"] == PermissionLevel.L2_CONFIRM
        assert meta["is_destructive"] is True


# ======================================================================
# Tool Registry (tools/registry.py)
# ======================================================================

class TestToolRegistry:

    def _make_registry(self):
        from tools.registry import ToolRegistry
        from tools.base import readonly_meta, sideeffect_meta
        reg = ToolRegistry()

        def _dummy_read():
            pass

        def _dummy_bash():
            pass

        def _dummy_spawn():
            pass

        reg.register("file_read", _dummy_read, readonly_meta("Read file", "file"))
        reg.register("bash", _dummy_bash, sideeffect_meta("Shell", "execution"))
        reg.register("agent_spawn", _dummy_spawn, readonly_meta("Spawn agent", "orchestration"),
                      coordinator_visible=True)
        return reg

    def test_register_and_len(self):
        reg = self._make_registry()
        assert len(reg) == 3
        assert "file_read" in reg
        assert "nonexistent" not in reg

    def test_get_tools_normal(self):
        reg = self._make_registry()
        tools = reg.get_tools(agent_type="normal")
        assert len(tools) == 3

    def test_get_tools_coordinator(self):
        reg = self._make_registry()
        tools = reg.get_tools(agent_type="coordinator")
        assert len(tools) == 1  # only agent_spawn

    def test_get_meta(self):
        from tools.base import PermissionLevel
        reg = self._make_registry()
        meta = reg.get_meta("bash")
        assert meta is not None
        assert meta["permission_level"] == PermissionLevel.L2_CONFIRM

    def test_get_meta_missing(self):
        reg = self._make_registry()
        assert reg.get_meta("nonexistent") is None

    def test_get_permission_level(self):
        from tools.base import PermissionLevel
        reg = self._make_registry()
        assert reg.get_permission_level("file_read") == PermissionLevel.L1_AUTO
        assert reg.get_permission_level("bash") == PermissionLevel.L2_CONFIRM
        # Unknown tool defaults to L1
        assert reg.get_permission_level("unknown") == PermissionLevel.L1_AUTO

    def test_is_concurrency_safe(self):
        reg = self._make_registry()
        assert reg.is_concurrency_safe("file_read") is True
        assert reg.is_concurrency_safe("bash") is False

    def test_list_tools(self):
        reg = self._make_registry()
        listing = reg.list_tools()
        assert len(listing) == 3
        names = {t["name"] for t in listing}
        assert names == {"file_read", "bash", "agent_spawn"}

    def test_get_tools_by_names(self):
        reg = self._make_registry()
        tools = reg.get_tools_by_names(["file_read", "bash", "nonexistent"])
        assert len(tools) == 2  # nonexistent is skipped

    def test_register_batch(self):
        from tools.registry import ToolRegistry
        from tools.base import readonly_meta
        reg = ToolRegistry()

        def _a(): pass
        def _b(): pass

        reg.register_batch([
            ("a", _a, readonly_meta("Tool A")),
            ("b", _b, readonly_meta("Tool B")),
        ])
        assert len(reg) == 2


# ======================================================================
# Bash Tool — blacklist checking
# ======================================================================

class TestBashBlacklist:

    def test_dangerous_command_blocked(self):
        from tools.bash_tool import _is_command_blocked
        assert _is_command_blocked("rm -rf /") is not None
        assert _is_command_blocked("shutdown -h now") is not None
        assert _is_command_blocked("mkfs.ext4 /dev/sda") is not None

    def test_safe_command_allowed(self):
        from tools.bash_tool import _is_command_blocked
        assert _is_command_blocked("ls -la") is None
        assert _is_command_blocked("echo hello") is None
        assert _is_command_blocked("python --version") is None
        assert _is_command_blocked("rm test.txt") is None  # not rm -rf /


# ======================================================================
# File Tools — basic functionality
# ======================================================================

class TestFileTools:

    def test_file_read_nonexistent(self):
        from tools.file_tools import file_read
        result = file_read.entrypoint(path="nonexistent_file_abc123.txt")
        assert "Error" in result

    def test_glob_search_nonexistent_dir(self):
        from tools.file_tools import glob_search
        result = glob_search.entrypoint(pattern="*.py", base_dir="nonexistent_dir_xyz")
        assert "Error" in result

    def test_file_read_and_edit(self, tmp_path):
        from tools.file_tools import file_read, file_edit

        test_file = str(tmp_path / "test.txt")
        # Write
        result = file_edit.entrypoint(path=test_file, content="line1\nline2\nline3\n")
        assert "Successfully wrote" in result

        # Read
        result = file_read.entrypoint(path=test_file)
        assert "line1" in result
        assert "line2" in result

    def test_glob_search(self, tmp_path):
        from tools.file_tools import glob_search, file_edit

        # Create some files
        (tmp_path / "a.py").write_text("hello")
        (tmp_path / "b.txt").write_text("world")
        (tmp_path / "sub").mkdir()
        (tmp_path / "sub" / "c.py").write_text("nested")

        result = glob_search.entrypoint(pattern="**/*.py", base_dir=str(tmp_path))
        assert "a.py" in result
        assert "c.py" in result
        assert "b.txt" not in result


# ======================================================================
# Search Tools — grep
# ======================================================================

class TestGrepTool:

    def test_grep_finds_matches(self, tmp_path):
        from tools.search_tools import grep

        (tmp_path / "test.py").write_text("def hello():\n    return 'world'\n")
        result = grep.entrypoint(pattern="hello", path=str(tmp_path))
        assert "test.py:1:" in result
        assert "hello" in result

    def test_grep_no_matches(self, tmp_path):
        from tools.search_tools import grep

        (tmp_path / "test.py").write_text("some content\n")
        result = grep.entrypoint(pattern="nonexistent_pattern_xyz", path=str(tmp_path))
        assert "No matches found" in result

    def test_grep_invalid_regex(self):
        from tools.search_tools import grep
        result = grep.entrypoint(pattern="[invalid", path=".")
        assert "Error" in result

    def test_grep_file_pattern_filter(self, tmp_path):
        from tools.search_tools import grep

        (tmp_path / "a.py").write_text("target_word\n")
        (tmp_path / "b.txt").write_text("target_word\n")

        result = grep.entrypoint(pattern="target_word", path=str(tmp_path), file_pattern="*.py")
        assert "a.py" in result
        assert "b.txt" not in result
