"""
Tests for hooks/interrupt_manager.py, hooks/permission_hook.py,
hooks/result_verify_hook.py
"""

import asyncio
import pytest


# ======================================================================
# InterruptManager
# ======================================================================

class TestInterruptManager:

    def _make_manager(self, timeout_minutes: int = 1) -> "InterruptManager":
        from hooks.interrupt_manager import InterruptManager
        return InterruptManager(timeout_minutes=timeout_minutes)

    @pytest.mark.asyncio
    async def test_request_and_resolve_confirm(self):
        from hooks.interrupt_manager import InterruptType

        mgr = self._make_manager()

        # Schedule resolution after a short delay
        async def _resolve():
            await asyncio.sleep(0.05)
            mgr.resolve_interrupt("sess-1", action="confirm", notes="LGTM")

        asyncio.create_task(_resolve())

        record = await mgr.request_interrupt(
            session_id="sess-1",
            interrupt_type=InterruptType.PREVIEW_CONFIRM,
            payload={"tool_name": "bash", "preview": "echo hello"},
        )

        assert record.action == "confirm"
        assert record.notes == "LGTM"
        assert record.is_resolved is True

    @pytest.mark.asyncio
    async def test_request_and_resolve_cancel(self):
        from hooks.interrupt_manager import InterruptType

        mgr = self._make_manager()

        async def _resolve():
            await asyncio.sleep(0.05)
            mgr.resolve_interrupt("sess-2", action="cancel")

        asyncio.create_task(_resolve())

        record = await mgr.request_interrupt(
            session_id="sess-2",
            interrupt_type=InterruptType.PREVIEW_CONFIRM,
            payload={"tool_name": "bash"},
        )
        assert record.action == "cancel"

    @pytest.mark.asyncio
    async def test_resolve_nonexistent_session(self):
        mgr = self._make_manager()
        result = mgr.resolve_interrupt("nonexistent-sess", action="confirm")
        assert result is False

    @pytest.mark.asyncio
    async def test_has_pending(self):
        from hooks.interrupt_manager import InterruptType

        mgr = self._make_manager()
        assert mgr.has_pending("sess-3") is False

        # Start an interrupt (don't await it)
        task = asyncio.create_task(
            mgr.request_interrupt(
                session_id="sess-3",
                interrupt_type=InterruptType.PREVIEW_CONFIRM,
                payload={},
            )
        )

        # Give event loop a tick to register the pending record
        await asyncio.sleep(0.01)
        assert mgr.has_pending("sess-3") is True

        # Resolve and clean up
        mgr.resolve_interrupt("sess-3", action="confirm")
        await task

    @pytest.mark.asyncio
    async def test_pending_payload(self):
        from hooks.interrupt_manager import InterruptType

        mgr = self._make_manager()

        task = asyncio.create_task(
            mgr.request_interrupt(
                session_id="sess-4",
                interrupt_type=InterruptType.RESULT_VERIFY,
                payload={"result_summary": "All tests passed"},
            )
        )
        await asyncio.sleep(0.01)

        payload = mgr.pending_payload("sess-4")
        assert payload is not None
        assert payload["interrupt_type"] == "result_verify"
        assert "pass" in payload["actions"]

        mgr.resolve_interrupt("sess-4", action="pass")
        await task

    @pytest.mark.asyncio
    async def test_modify_action(self):
        from hooks.interrupt_manager import InterruptType

        mgr = self._make_manager()

        async def _resolve():
            await asyncio.sleep(0.05)
            mgr.resolve_interrupt("sess-5", action="modify", modified_content="echo modified")

        asyncio.create_task(_resolve())

        record = await mgr.request_interrupt(
            session_id="sess-5",
            interrupt_type=InterruptType.PREVIEW_CONFIRM,
            payload={"tool_name": "bash", "preview": "echo original"},
        )
        assert record.action == "modify"
        assert record.modified_content == "echo modified"

    def test_allowed_actions_preview(self):
        from hooks.interrupt_manager import InterruptManager, InterruptType
        actions = InterruptManager._allowed_actions(InterruptType.PREVIEW_CONFIRM)
        assert "confirm" in actions
        assert "cancel" in actions
        assert "modify" in actions

    def test_allowed_actions_result_verify(self):
        from hooks.interrupt_manager import InterruptManager, InterruptType
        actions = InterruptManager._allowed_actions(InterruptType.RESULT_VERIFY)
        assert "pass" in actions
        assert "fail" in actions
        assert "rerun" in actions
        assert "investigate" in actions


# ======================================================================
# Permission Hook
# ======================================================================

class MockAgent:
    """Minimal mock for Agno Agent with session_state."""

    def __init__(self, session_id: str = "test-sess", permission_mode: str = "default"):
        from core.session_state import QASessionState
        self.session_state = QASessionState(
            session_id=session_id,
            permission_mode=permission_mode,
        )
        self.session_id = session_id


class TestPermissionHook:

    @pytest.mark.asyncio
    async def test_bypass_mode_skips_interrupt(self):
        from hooks.permission_hook import l2_pre_hook

        agent = MockAgent(session_id="bypass-sess", permission_mode="bypass")
        result = await l2_pre_hook(
            tool_name="bash",
            tool_args={"command": "echo hello"},
            agent=agent,
        )
        # bypass returns None (proceed without interrupt)
        assert result is None

    @pytest.mark.asyncio
    async def test_no_session_id_skips_interrupt(self):
        from hooks.permission_hook import l2_pre_hook

        agent = MockAgent(session_id="", permission_mode="default")
        result = await l2_pre_hook(
            tool_name="bash",
            tool_args={"command": "echo hello"},
            agent=agent,
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_confirm_proceeds(self):
        from hooks.interrupt_manager import interrupt_manager
        from hooks.permission_hook import l2_pre_hook

        agent = MockAgent(session_id="confirm-sess", permission_mode="default")

        async def _resolve():
            await asyncio.sleep(0.05)
            interrupt_manager.resolve_interrupt("confirm-sess", action="confirm")

        asyncio.create_task(_resolve())

        result = await l2_pre_hook(
            tool_name="bash",
            tool_args={"command": "echo hello"},
            agent=agent,
        )
        assert result is None  # confirmed, proceed with original args

    @pytest.mark.asyncio
    async def test_cancel_raises_error(self):
        from hooks.interrupt_manager import interrupt_manager
        from hooks.permission_hook import l2_pre_hook, ToolCancelledError

        agent = MockAgent(session_id="cancel-sess", permission_mode="default")

        async def _resolve():
            await asyncio.sleep(0.05)
            interrupt_manager.resolve_interrupt("cancel-sess", action="cancel")

        asyncio.create_task(_resolve())

        with pytest.raises(ToolCancelledError):
            await l2_pre_hook(
                tool_name="bash",
                tool_args={"command": "echo hello"},
                agent=agent,
            )

    @pytest.mark.asyncio
    async def test_modify_returns_new_args(self):
        from hooks.interrupt_manager import interrupt_manager
        from hooks.permission_hook import l2_pre_hook

        agent = MockAgent(session_id="modify-sess", permission_mode="default")

        async def _resolve():
            await asyncio.sleep(0.05)
            interrupt_manager.resolve_interrupt(
                "modify-sess",
                action="modify",
                modified_content="echo modified_command",
            )

        asyncio.create_task(_resolve())

        result = await l2_pre_hook(
            tool_name="bash",
            tool_args={"command": "echo original"},
            agent=agent,
        )
        assert result is not None
        assert result["command"] == "echo modified_command"


# ======================================================================
# Result Verify Hook
# ======================================================================

class TestResultVerifyHook:

    @pytest.mark.asyncio
    async def test_coordinator_skipped(self):
        """Coordinator agent_type should NOT trigger result_verify."""
        from hooks.result_verify_hook import result_verify_post_hook

        agent = MockAgent(session_id="coord-sess", permission_mode="default")
        agent.session_state.agent_type = "coordinator"

        class FakeResponse:
            content = "Coordinator summary"

        # Should return immediately without blocking
        await result_verify_post_hook(agent, FakeResponse())

    @pytest.mark.asyncio
    async def test_empty_response_skipped(self):
        """Empty response should skip L3 verification."""
        from hooks.result_verify_hook import result_verify_post_hook

        agent = MockAgent(session_id="empty-sess", permission_mode="default")

        await result_verify_post_hook(agent, None)

    @pytest.mark.asyncio
    async def test_pass_verdict_stored(self):
        from hooks.interrupt_manager import interrupt_manager
        from hooks.result_verify_hook import result_verify_post_hook

        agent = MockAgent(session_id="verify-sess", permission_mode="default")

        class FakeResponse:
            content = "测试结果：战斗系统伤害计算正常，无异常"

        async def _resolve():
            await asyncio.sleep(0.05)
            interrupt_manager.resolve_interrupt("verify-sess", action="pass", notes="看起来没问题")

        asyncio.create_task(_resolve())

        await result_verify_post_hook(agent, FakeResponse())

        assert agent.session_state.__dict__.get("_last_verdict") == "pass"
        assert "没问题" in (agent.session_state.__dict__.get("_last_verdict_notes") or "")
