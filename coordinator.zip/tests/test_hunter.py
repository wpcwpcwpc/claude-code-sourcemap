"""
Tests for tools/hunter_execute_tool.py — degraded mode and error handling.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch


class TestHunterExecuteTool:

    @pytest.mark.asyncio
    async def test_sdk_not_installed_returns_error_message(self):
        """When Hunter2 SDK is not installed, return clear error (no raise)."""
        from tools.hunter_execute_tool import hunter_execute

        # Patch importlib.import_module to simulate missing SDK
        with patch("importlib.import_module", side_effect=ImportError("No module named 'hunter2'")):
            result = await hunter_execute.entrypoint(
                script="print('hello')",
                device_ip="192.168.1.100",
            )

        assert "Error" in result
        assert "Hunter2 SDK" in result or "hunter2" in result.lower()

    @pytest.mark.asyncio
    async def test_successful_execution_returns_output(self):
        """Mock a successful Hunter2 execution."""
        from tools.hunter_execute_tool import _execute_via_hunter2

        # Mock the Hunter2 SDK module
        mock_hunter = MagicMock()
        mock_client = MagicMock()
        mock_hunter.Client.return_value = mock_client
        mock_client.execute.return_value = "Test passed: 5/5 assertions OK"

        with patch("importlib.import_module", return_value=mock_hunter):
            result = await _execute_via_hunter2(
                script="run_case(CombatCase001)",
                device_ip="192.168.1.100",
                token_id="test-token",
                group_name="qa-group",
                timeout=30,
            )

        assert "Test passed" in result
        mock_client.connect.assert_called_once_with("192.168.1.100")
        mock_client.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_connection_error_returns_error_message(self):
        """Hunter2 connection failure returns error message (no raise)."""
        from tools.hunter_execute_tool import hunter_execute, HunterConnectionError

        mock_hunter = MagicMock()
        mock_client = MagicMock()
        mock_hunter.Client.return_value = mock_client
        mock_hunter.ConnectionError = ConnectionError
        mock_client.connect.side_effect = ConnectionError("Device unreachable")

        with patch("importlib.import_module", return_value=mock_hunter):
            result = await hunter_execute.entrypoint(
                script="print('hello')",
                device_ip="192.168.1.999",
            )

        assert "Error" in result

    @pytest.mark.asyncio
    async def test_tool_name_and_description(self):
        """Verify tool is properly decorated with name and description."""
        from tools.hunter_execute_tool import hunter_execute

        # Agno @tool sets name on the function
        assert getattr(hunter_execute, "name", None) == "hunter_execute" or \
               "hunter_execute" in str(hunter_execute)

    @pytest.mark.asyncio
    async def test_empty_device_ip_uses_config_default(self):
        """Empty device_ip falls back to settings.hunter_device_ip."""
        from tools.hunter_execute_tool import _execute_via_hunter2

        mock_hunter = MagicMock()
        mock_client = MagicMock()
        mock_hunter.Client.return_value = mock_client
        mock_client.execute.return_value = "OK"

        with patch("importlib.import_module", return_value=mock_hunter):
            result = await _execute_via_hunter2(
                script="print('ok')",
                device_ip="",  # empty → no connect() call
                token_id="",
                group_name="",
                timeout=30,
            )

        # When device_ip is empty, connect() should not be called
        mock_client.connect.assert_not_called()
        assert result == "OK"


class TestHunterToolRegistration:

    def test_hunter_meta_in_registry_after_registration(self):
        """After registering hunter_execute, it should appear in tool registry."""
        from tools.registry import tool_registry
        from tools.base import PermissionLevel, sideeffect_meta
        from tools.hunter_execute_tool import hunter_execute

        # Manually register (normally done at startup)
        tool_registry.register(
            "hunter_execute",
            hunter_execute,
            sideeffect_meta("Execute script via Hunter2", "execution"),
        )

        assert "hunter_execute" in tool_registry
        assert tool_registry.get_permission_level("hunter_execute") == PermissionLevel.L2_CONFIRM
        assert tool_registry.is_concurrency_safe("hunter_execute") is False
