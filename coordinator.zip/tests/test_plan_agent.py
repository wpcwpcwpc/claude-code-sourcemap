"""Tests for agents/builtin/plan_agent.py — PlanAgent definition and output parser."""

import pytest
from agents.builtin.plan_agent import (
    PlanAgentDefinition,
    PLAN_AGENT_SYSTEM_PROMPT,
    parse_plan_output,
)


# ═══════════════════════════════════════════════════════════════════
# PlanAgentDefinition field validation
# ═══════════════════════════════════════════════════════════════════


class TestPlanAgentDefinition:
    def test_name(self):
        assert PlanAgentDefinition.name == "PlanAgent"

    def test_agent_type(self):
        assert PlanAgentDefinition.agent_type == "worker"

    def test_tools_are_read_only(self):
        tools = PlanAgentDefinition.tool_names
        assert "file_read" in tools
        assert "grep" in tools
        assert "glob_search" in tools
        assert "bash" in tools
        # Must NOT include write tools
        assert "file_edit" not in tools
        assert "hunter_execute" not in tools
        assert "agent_spawn" not in tools

    def test_max_turns(self):
        assert PlanAgentDefinition.max_turns == 15

    def test_inject_history(self):
        assert PlanAgentDefinition.inject_history is True

    def test_system_prompt_contains_read_only(self):
        assert "READ-ONLY" in PLAN_AGENT_SYSTEM_PROMPT

    def test_system_prompt_contains_output_format(self):
        assert "Implementation Strategy" in PLAN_AGENT_SYSTEM_PROMPT
        assert "Step-by-Step Tasks" in PLAN_AGENT_SYSTEM_PROMPT
        assert "Trade-offs" in PLAN_AGENT_SYSTEM_PROMPT
        assert "Risks" in PLAN_AGENT_SYSTEM_PROMPT

    def test_system_prompt_contains_task_rules(self):
        assert "3 tasks" in PLAN_AGENT_SYSTEM_PROMPT or "Minimum 3" in PLAN_AGENT_SYSTEM_PROMPT
        assert "10 tasks" in PLAN_AGENT_SYSTEM_PROMPT or "maximum 10" in PLAN_AGENT_SYSTEM_PROMPT


# ═══════════════════════════════════════════════════════════════════
# parse_plan_output
# ═══════════════════════════════════════════════════════════════════

SAMPLE_PLAN_OUTPUT = """\
### Implementation Strategy

We will verify the combat damage formula by reading the config tables,
writing a verification script, and executing it through Hunter.

This approach ensures we test the actual game logic against expected values.

### Key Files
- `configs/combat/damage.xlsx` — Damage formula parameters
- `scripts/verify_damage.py` — Verification script to write

### Step-by-Step Tasks

1. **Read combat config tables** — Open damage.xlsx and extract formula parameters
2. **Identify edge cases** — Find boundary values and special modifiers
3. **Write verification script** — Create Python script that calculates expected damage
4. **Execute via Hunter** — Push script to device and run tests
5. **Analyze results** — Compare actual vs expected values, identify discrepancies
6. **Generate report** — Produce structured test report with findings

### Trade-offs
- Manual formula check vs automated: chose automated for repeatability

### Risks
- Config table format may have changed → Mitigation: read actual file first
- Hunter connection may be unstable → Mitigation: add retry logic
"""


class TestParsePlanOutput:
    def test_normal_parse(self):
        plan = parse_plan_output(SAMPLE_PLAN_OUTPUT)
        assert plan is not None
        assert len(plan.tasks) == 6
        assert "combat config" in plan.tasks[0].description.lower() or "Read" in plan.tasks[0].description
        assert plan.tasks[0].status == "active"  # auto-activated
        assert plan.current_task_id == 1

    def test_goal_extracted(self):
        plan = parse_plan_output(SAMPLE_PLAN_OUTPUT)
        assert plan is not None
        assert len(plan.goal) > 10
        assert "combat" in plan.goal.lower() or "damage" in plan.goal.lower() or "verify" in plan.goal.lower()

    def test_strategy_extracted(self):
        plan = parse_plan_output(SAMPLE_PLAN_OUTPUT)
        assert plan is not None
        assert len(plan.strategy) > 10

    def test_empty_input_returns_none(self):
        assert parse_plan_output("") is None
        assert parse_plan_output(None) is None

    def test_whitespace_only_returns_none(self):
        assert parse_plan_output("   \n\n  ") is None

    def test_no_tasks_returns_none(self):
        text = "### Implementation Strategy\nSome strategy.\n### Key Files\n- file.py"
        assert parse_plan_output(text) is None

    def test_minimal_numbered_list(self):
        text = """\
### Implementation Strategy
Do the thing.

### Step-by-Step Tasks
1. First step of the plan
2. Second step of the plan
3. Third step of the plan
"""
        plan = parse_plan_output(text)
        assert plan is not None
        assert len(plan.tasks) == 3

    def test_bullet_list_fallback(self):
        text = """\
### Implementation Strategy
Do the thing.

### Step-by-Step Tasks
- First step of the plan
- Second step of the plan
- Third step of the plan
"""
        plan = parse_plan_output(text)
        assert plan is not None
        assert len(plan.tasks) == 3

    def test_bold_title_format(self):
        text = """\
### Implementation Strategy
Plan overview here.

### Step-by-Step Tasks
1. **Read config files** — Open and parse the configuration
2. **Write test script** — Create verification logic
3. **Execute and verify** — Run tests and check results
"""
        plan = parse_plan_output(text)
        assert plan is not None
        assert len(plan.tasks) == 3
        assert "Read config" in plan.tasks[0].description or "config" in plan.tasks[0].description
