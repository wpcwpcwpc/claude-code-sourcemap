"""Tests for tools/file_state_cache.py"""

import os
import tempfile
import time
from pathlib import Path

import pytest
from tools.file_state_cache import ReadFileStateCache, FileReadRecord, get_file_state_cache


@pytest.fixture(autouse=True)
def fresh_cache():
    """Reset the singleton cache before each test."""
    cache = get_file_state_cache()
    cache.clear()
    yield cache


@pytest.fixture
def tmp_file(tmp_path):
    """Create a temporary file with known content."""
    f = tmp_path / "test.py"
    f.write_text("line1\nline2\nline3\nline4\nline5\n", encoding="utf-8")
    return f


class TestRecordRead:
    def test_record_creates_entry(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        record = fresh_cache.record_read(str(tmp_file), content)

        assert record.path == str(tmp_file.resolve())
        assert record.mtime > 0
        assert len(record.content_hash) == 64  # SHA-256 hex
        assert record.offset == 0
        assert record.limit == 500
        assert record.is_partial is False

    def test_record_partial_read(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        record = fresh_cache.record_read(
            str(tmp_file), content,
            offset=2, limit=2, total_lines=5,
        )
        assert record.is_partial is True
        assert record.offset == 2
        assert record.limit == 2

    def test_record_full_read_not_partial(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        record = fresh_cache.record_read(
            str(tmp_file), content,
            offset=0, limit=500, total_lines=5,
        )
        assert record.is_partial is False

    def test_record_bytes_content(self, fresh_cache, tmp_file):
        content = tmp_file.read_bytes()
        record = fresh_cache.record_read(str(tmp_file), content)
        assert len(record.content_hash) == 64


class TestGetRecord:
    def test_get_existing_record(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)

        record = fresh_cache.get_record(str(tmp_file))
        assert record is not None
        assert record.path == str(tmp_file.resolve())

    def test_get_nonexistent_returns_none(self, fresh_cache):
        assert fresh_cache.get_record("/nonexistent/file.py") is None


class TestIsStale:
    def test_never_read_is_stale(self, fresh_cache):
        assert fresh_cache.is_stale("/some/file.py") is True

    def test_just_read_not_stale(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)

        assert fresh_cache.is_stale(str(tmp_file)) is False

    def test_modified_after_read_is_stale(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)

        # Modify the file externally
        time.sleep(0.05)  # Ensure mtime changes
        tmp_file.write_text("modified content\n", encoding="utf-8")

        assert fresh_cache.is_stale(str(tmp_file)) is True

    def test_mtime_change_but_same_content_not_stale(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)

        # Touch the file without changing content
        time.sleep(0.05)
        tmp_file.write_text(content, encoding="utf-8")  # Same content, new mtime

        assert fresh_cache.is_stale(str(tmp_file)) is False

    def test_deleted_file_is_stale(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)

        tmp_file.unlink()
        assert fresh_cache.is_stale(str(tmp_file)) is True


class TestCacheOperations:
    def test_remove_record(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)
        assert len(fresh_cache) == 1

        fresh_cache.remove(str(tmp_file))
        assert len(fresh_cache) == 0
        assert fresh_cache.get_record(str(tmp_file)) is None

    def test_clear(self, fresh_cache, tmp_file):
        content = tmp_file.read_text()
        fresh_cache.record_read(str(tmp_file), content)
        fresh_cache.record_read("/fake/path", "content")

        fresh_cache.clear()
        assert len(fresh_cache) == 0

    def test_singleton(self):
        a = get_file_state_cache()
        b = get_file_state_cache()
        assert a is b
