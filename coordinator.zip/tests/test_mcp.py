"""
Tests for mcp/loader.py — config loading, permission tagging, degraded mode.
"""

import json
import pytest
from pathlib import Path


class TestMCPConfigLoading:

    def test_load_valid_config(self, tmp_path):
        from mcp.loader import load_mcp_config

        config = {
            "servers": {
                "server_a": {"transport": "stdio", "command": "python", "args": []},
                "server_b": {"transport": "sse", "url": "http://localhost:8080/sse"},
            }
        }
        config_file = tmp_path / "mcp.json"
        config_file.write_text(json.dumps(config), encoding="utf-8")

        result = load_mcp_config(str(config_file))
        assert len(result) == 2
        assert "server_a" in result
        assert "server_b" in result

    def test_missing_config_returns_empty(self, tmp_path):
        from mcp.loader import load_mcp_config

        result = load_mcp_config(str(tmp_path / "nonexistent.json"))
        assert result == {}

    def test_malformed_json_returns_empty(self, tmp_path):
        from mcp.loader import load_mcp_config

        bad_file = tmp_path / "mcp.json"
        bad_file.write_text("{ invalid json }", encoding="utf-8")

        result = load_mcp_config(str(bad_file))
        assert result == {}

    def test_missing_servers_key_returns_empty(self, tmp_path):
        from mcp.loader import load_mcp_config

        config_file = tmp_path / "mcp.json"
        config_file.write_text(json.dumps({"other_key": {}}), encoding="utf-8")

        result = load_mcp_config(str(config_file))
        assert result == {}


class TestMCPPermissionTagging:

    def test_l2_pattern_detection(self):
        """Tools with L2 name patterns should be tagged as L2."""
        from mcp.loader import _L2_TOOL_PATTERNS

        l2_names = ["send_gm_cmd", "repl_execute", "bash", "execute_script", "run_test"]
        for name in l2_names:
            matched = any(p in name.lower() for p in _L2_TOOL_PATTERNS)
            assert matched, f"Expected '{name}' to match L2 pattern"

    def test_l1_pattern_not_matched(self):
        """Read-only tool names should NOT match L2 patterns."""
        from mcp.loader import _L2_TOOL_PATTERNS

        l1_names = ["list_gm_categories", "search_gm_by_intent", "get_status"]
        for name in l1_names:
            matched = any(p in name.lower() for p in _L2_TOOL_PATTERNS)
            assert not matched, f"Expected '{name}' NOT to match L2 pattern"


class TestMCPToolsLoadDegradation:

    @pytest.mark.asyncio
    async def test_failed_server_returns_empty(self, tmp_path):
        """Connection failure to MCP server should return empty tools list."""
        from mcp.loader import _load_server_tools

        config = {
            "transport": "stdio",
            "command": "nonexistent_command_xyz",
            "args": [],
        }

        # Should not raise, just return empty
        tools = await _load_server_tools("test_server", config)
        assert tools == []

    @pytest.mark.asyncio
    async def test_unknown_transport_returns_empty(self):
        from mcp.loader import _load_server_tools

        config = {"transport": "websocket"}
        tools = await _load_server_tools("test_server", config)
        assert tools == []

    @pytest.mark.asyncio
    async def test_load_mcp_tools_no_config(self, tmp_path):
        """No config file → empty tool list, no errors."""
        from mcp.loader import load_mcp_tools

        tools = await load_mcp_tools(str(tmp_path / "nonexistent.json"))
        assert tools == []


class TestCreateDefaultMCPConfig:

    def test_creates_file(self, tmp_path):
        from mcp.loader import create_default_mcp_config

        output = str(tmp_path / "output" / "mcp.json")
        create_default_mcp_config(output)

        path = Path(output)
        assert path.exists()

        data = json.loads(path.read_text())
        assert "servers" in data
        assert "game_debug_mcp" in data["servers"]
        assert data["servers"]["game_debug_mcp"]["transport"] == "stdio"
