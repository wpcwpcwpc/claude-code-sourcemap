"""Tests for tools/background_tasks.py"""

import time
import sys
import pytest
from tools.background_tasks import BackgroundTaskManager, TaskStatus


@pytest.fixture
def manager():
    return BackgroundTaskManager(default_timeout=10)


class TestStartTask:
    def test_returns_task_id(self, manager):
        task_id = manager.start_task("echo hello", description="test echo")
        assert isinstance(task_id, str)
        assert len(task_id) == 8

    def test_task_registered(self, manager):
        task_id = manager.start_task("echo hello")
        assert len(manager) == 1
        status = manager.get_status(task_id)
        assert status is not None
        assert status["command"] == "echo hello"


class TestGetStatus:
    def test_nonexistent_task(self, manager):
        assert manager.get_status("no-such-id") is None

    def test_completed_task(self, manager):
        cmd = "echo hello_world" if sys.platform != "win32" else "echo hello_world"
        task_id = manager.start_task(cmd, description="echo test")

        # Wait for completion
        for _ in range(50):
            status = manager.get_status(task_id)
            if status and status["status"] != "running":
                break
            time.sleep(0.1)

        status = manager.get_status(task_id)
        assert status is not None
        assert status["status"] == "completed"
        assert "hello_world" in status["output"]
        assert status["exit_code"] == 0
        assert status["elapsed_s"] > 0

    def test_failed_task(self, manager):
        # Command that will fail
        cmd = "exit 42" if sys.platform != "win32" else "cmd /c exit 42"
        task_id = manager.start_task(cmd if sys.platform != "win32" else "cmd /c exit 42")

        for _ in range(50):
            status = manager.get_status(task_id)
            if status and status["status"] != "running":
                break
            time.sleep(0.1)

        status = manager.get_status(task_id)
        assert status is not None
        assert status["status"] == "failed"


class TestTimeout:
    def test_task_timeout(self, manager):
        # Use a very short timeout
        mgr = BackgroundTaskManager(default_timeout=1)
        cmd = "sleep 30" if sys.platform != "win32" else "ping -n 30 127.0.0.1"
        task_id = mgr.start_task(cmd, timeout=1, description="should timeout")

        # Wait for timeout to trigger
        for _ in range(40):
            status = mgr.get_status(task_id)
            if status and status["status"] != "running":
                break
            time.sleep(0.2)

        status = mgr.get_status(task_id)
        assert status is not None
        assert status["status"] == "timeout"


class TestCleanup:
    def test_cleanup_expired(self, manager):
        cmd = "echo cleanup_test"
        task_id = manager.start_task(cmd)

        # Wait for completion
        for _ in range(50):
            status = manager.get_status(task_id)
            if status and status["status"] != "running":
                break
            time.sleep(0.1)

        # Not old enough → no cleanup
        assert manager.cleanup_expired(max_age_s=600) == 0
        assert len(manager) == 1

        # Force cleanup with 0 age threshold
        assert manager.cleanup_expired(max_age_s=0) == 1
        assert len(manager) == 0


class TestCanAutoBackground:
    def test_normal_command_can_auto_bg(self, manager):
        assert manager.can_auto_background("npm install") is True
        assert manager.can_auto_background("python test.py") is True

    def test_sleep_cannot_auto_bg(self, manager):
        assert manager.can_auto_background("sleep 30") is False
        assert manager.can_auto_background("sleep 30 && echo done") is False

    def test_watch_cannot_auto_bg(self, manager):
        assert manager.can_auto_background("watch -n1 ls") is False

    def test_top_cannot_auto_bg(self, manager):
        assert manager.can_auto_background("top") is False
        assert manager.can_auto_background("htop") is False
