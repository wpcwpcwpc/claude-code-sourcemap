"""
Tests for core/engine.py, core/models.py, core/storage.py, core/memory_setup.py
"""

import pytest


class TestGetModel:
    def test_creates_openai_chat(self):
        from core.config import QAAgentSettings
        from core.models import get_model

        cfg = QAAgentSettings(
            _env_file=None,
            llm_model="gpt-4o-mini",
            llm_base_url="https://test.api/v1",
            llm_api_key="sk-test",
        )
        model = get_model(cfg)
        assert model.id == "gpt-4o-mini"


class TestGetStorage:
    def test_sqlite_default(self, tmp_path):
        from core.config import QAAgentSettings
        from core.storage import get_storage

        cfg = QAAgentSettings(
            _env_file=None,
            storage_backend="sqlite",
            sqlite_path=str(tmp_path / "test.db"),
        )
        storage = get_storage(cfg)
        assert storage is not None


class TestGetMemory:
    def test_creates_memory(self):
        from core.memory_setup import get_memory
        mem = get_memory()
        assert mem is not None


class TestCreateNormalAgent:
    def test_creates_agent_with_defaults(self, tmp_path):
        from core.config import QAAgentSettings
        from core.engine import create_normal_agent

        cfg = QAAgentSettings(
            _env_file=None,
            llm_api_key="sk-test",
            sqlite_path=str(tmp_path / "test.db"),
        )
        agent = create_normal_agent(
            config=cfg,
            session_id="test-session-001",
            agent_name="TestAgent",
        )
        assert agent is not None
        assert agent.name == "TestAgent"
        assert agent.session_id == "test-session-001"

    def test_session_state_attached(self, tmp_path):
        from core.config import QAAgentSettings
        from core.engine import create_normal_agent
        from core.session_state import QASessionState

        cfg = QAAgentSettings(
            _env_file=None,
            llm_api_key="sk-test",
            sqlite_path=str(tmp_path / "test.db"),
            default_max_turns=10,
        )
        agent = create_normal_agent(
            config=cfg,
            permission_mode="bypass",
            game_version="v2.4",
            module="combat",
        )
        state = agent.session_state
        assert isinstance(state, QASessionState)
        assert state.max_turns == 10
        assert state.permission_mode == "bypass"
        assert state.agent_type == "normal"
        assert state.game_version == "v2.4"
        assert state.module == "combat"

    def test_extra_instructions_appended(self, tmp_path):
        from core.config import QAAgentSettings
        from core.engine import create_normal_agent

        cfg = QAAgentSettings(
            _env_file=None,
            llm_api_key="sk-test",
            sqlite_path=str(tmp_path / "test.db"),
        )
        agent = create_normal_agent(
            config=cfg,
            extra_instructions="Focus on combat damage calculation.",
        )
        assert "combat damage calculation" in agent.instructions


class TestInstructions:
    def test_normal_instructions_content(self):
        from core.instructions import NORMAL_AGENT_INSTRUCTIONS
        assert "AI 辅助人工" in NORMAL_AGENT_INSTRUCTIONS
        assert "L1" in NORMAL_AGENT_INSTRUCTIONS
        assert "L2" in NORMAL_AGENT_INSTRUCTIONS

    def test_coordinator_instructions_content(self):
        from core.instructions import COORDINATOR_LEADER_INSTRUCTIONS
        assert "并行" in COORDINATOR_LEADER_INSTRUCTIONS
        assert "Worker" in COORDINATOR_LEADER_INSTRUCTIONS
        assert "综合" in COORDINATOR_LEADER_INSTRUCTIONS
