"""Tests for core/task_plan.py — TaskItem and TaskPlan lifecycle."""

import time
import pytest
from core.task_plan import TaskItem, TaskPlan, TERMINAL_STATUSES


# ═══════════════════════════════════════════════════════════════════
# TaskItem
# ═══════════════════════════════════════════════════════════════════


class TestTaskItem:
    def test_default_status_is_pending(self):
        item = TaskItem(id=1, description="Step 1")
        assert item.status == "pending"
        assert not item.is_terminal

    def test_terminal_statuses(self):
        for status in ("done", "failed", "skipped"):
            item = TaskItem(id=1, description="x", status=status)
            assert item.is_terminal

    def test_non_terminal_statuses(self):
        for status in ("pending", "active"):
            item = TaskItem(id=1, description="x", status=status)
            assert not item.is_terminal

    def test_to_dict_round_trip(self):
        item = TaskItem(
            id=3, description="Run tests", status="done",
            result_summary="All passed", tools_used=["bash", "hunter_execute"],
            started_at=100.0, completed_at=200.0,
        )
        d = item.to_dict()
        restored = TaskItem.from_dict(d)
        assert restored.id == 3
        assert restored.description == "Run tests"
        assert restored.status == "done"
        assert restored.result_summary == "All passed"
        assert restored.tools_used == ["bash", "hunter_execute"]
        assert restored.started_at == 100.0
        assert restored.completed_at == 200.0

    def test_from_dict_defaults(self):
        """Missing optional fields get defaults."""
        item = TaskItem.from_dict({"id": 1, "description": "x"})
        assert item.status == "pending"
        assert item.result_summary == ""
        assert item.tools_used == []
        assert item.started_at is None


# ═══════════════════════════════════════════════════════════════════
# TaskPlan — Lifecycle
# ═══════════════════════════════════════════════════════════════════


def _make_plan(n: int = 3) -> TaskPlan:
    """Helper: create a plan with n pending tasks."""
    tasks = [TaskItem(id=i, description=f"Task {i}") for i in range(1, n + 1)]
    return TaskPlan(goal="Test goal", strategy="Test strategy", tasks=tasks)


class TestTaskPlanLifecycle:
    def test_initial_state(self):
        plan = _make_plan()
        assert plan.current_task_id == 0
        assert not plan.is_complete
        assert plan.active_task is None

    def test_advance_to_next_activates_first(self):
        plan = _make_plan()
        activated = plan.advance_to_next()
        assert activated is not None
        assert activated.id == 1
        assert activated.status == "active"
        assert plan.current_task_id == 1

    def test_mark_done_auto_advances(self):
        plan = _make_plan()
        plan.advance_to_next()  # Task 1 active
        plan.mark_task(1, "done", "Completed")

        assert plan.tasks[0].status == "done"
        assert plan.tasks[0].result_summary == "Completed"
        assert plan.tasks[0].completed_at is not None
        # Should have auto-advanced to task 2
        assert plan.tasks[1].status == "active"
        assert plan.current_task_id == 2

    def test_mark_failed_auto_advances(self):
        plan = _make_plan()
        plan.advance_to_next()
        plan.mark_task(1, "failed", "Connection error")

        assert plan.tasks[0].status == "failed"
        assert plan.tasks[1].status == "active"
        assert plan.current_task_id == 2

    def test_mark_skipped_auto_advances(self):
        plan = _make_plan()
        plan.advance_to_next()
        plan.mark_task(1, "skipped", "Not applicable")

        assert plan.tasks[0].status == "skipped"
        assert plan.tasks[1].status == "active"

    def test_is_complete_all_done(self):
        plan = _make_plan(2)
        plan.advance_to_next()
        plan.mark_task(1, "done", "ok")
        plan.mark_task(2, "done", "ok")
        assert plan.is_complete

    def test_is_complete_mixed_terminal(self):
        plan = _make_plan(3)
        plan.advance_to_next()
        plan.mark_task(1, "done", "ok")
        plan.mark_task(2, "failed", "error")
        plan.mark_task(3, "skipped", "n/a")
        assert plan.is_complete

    def test_progress(self):
        plan = _make_plan(5)
        plan.advance_to_next()
        plan.mark_task(1, "done")
        plan.mark_task(2, "done")
        done, total = plan.progress
        assert done == 2
        assert total == 5

    def test_invalid_task_id_raises(self):
        plan = _make_plan()
        with pytest.raises(KeyError, match="Task ID 99"):
            plan.mark_task(99, "done")

    def test_empty_plan_is_complete(self):
        plan = TaskPlan(goal="x", strategy="y", tasks=[])
        assert plan.is_complete

    def test_advance_when_all_terminal(self):
        plan = _make_plan(1)
        plan.advance_to_next()
        plan.mark_task(1, "done")
        result = plan.advance_to_next()
        assert result is None
        assert plan.current_task_id == 0


# ═══════════════════════════════════════════════════════════════════
# TaskPlan — Prompt Context Generation
# ═══════════════════════════════════════════════════════════════════


class TestTaskPlanPromptContext:
    def test_empty_plan_returns_empty(self):
        plan = TaskPlan(goal="x", strategy="y", tasks=[])
        assert plan.to_prompt_context() == ""

    def test_contains_goal_and_strategy(self):
        plan = _make_plan()
        plan.advance_to_next()
        ctx = plan.to_prompt_context()
        assert "Test goal" in ctx
        assert "Test strategy" in ctx

    def test_contains_progress(self):
        plan = _make_plan(3)
        plan.advance_to_next()
        plan.mark_task(1, "done")
        ctx = plan.to_prompt_context()
        assert "1/3 tasks complete" in ctx

    def test_active_task_marked_you_are_here(self):
        plan = _make_plan()
        plan.advance_to_next()
        ctx = plan.to_prompt_context()
        assert "← YOU ARE HERE" in ctx
        assert "[>]" in ctx

    def test_done_tasks_show_checkmark(self):
        plan = _make_plan()
        plan.advance_to_next()
        plan.mark_task(1, "done")
        ctx = plan.to_prompt_context()
        assert "[x]" in ctx

    def test_pending_tasks_show_empty(self):
        plan = _make_plan()
        plan.advance_to_next()
        ctx = plan.to_prompt_context()
        assert "[ ]" in ctx

    def test_failed_tasks_show_marker(self):
        plan = _make_plan()
        plan.advance_to_next()
        plan.mark_task(1, "failed", "timeout")
        ctx = plan.to_prompt_context()
        assert "[!]" in ctx
        assert "FAILED" in ctx

    def test_complete_plan_shows_summary_prompt(self):
        plan = _make_plan(1)
        plan.advance_to_next()
        plan.mark_task(1, "done")
        ctx = plan.to_prompt_context()
        assert "All tasks complete" in ctx

    def test_active_plan_shows_focus_hint(self):
        plan = _make_plan()
        plan.advance_to_next()
        ctx = plan.to_prompt_context()
        assert "Focus on task" in ctx
        assert "task_update()" in ctx


# ═══════════════════════════════════════════════════════════════════
# TaskPlan — Serialization
# ═══════════════════════════════════════════════════════════════════


class TestTaskPlanSerialization:
    def test_to_dict_round_trip(self):
        plan = _make_plan(3)
        plan.advance_to_next()
        plan.mark_task(1, "done", "ok")

        d = plan.to_dict()
        restored = TaskPlan.from_dict(d)

        assert restored.goal == plan.goal
        assert restored.strategy == plan.strategy
        assert len(restored.tasks) == 3
        assert restored.tasks[0].status == "done"
        assert restored.tasks[1].status == "active"
        assert restored.current_task_id == plan.current_task_id

    def test_from_create_json_simple(self):
        data = {
            "goal": "Test combat system",
            "strategy": "Read configs then verify",
            "tasks": ["Read config", "Write script", "Execute test"],
        }
        plan = TaskPlan.from_create_json(data)

        assert plan.goal == "Test combat system"
        assert len(plan.tasks) == 3
        assert plan.tasks[0].id == 1
        assert plan.tasks[0].description == "Read config"
        # First task should be auto-activated
        assert plan.tasks[0].status == "active"
        assert plan.tasks[1].status == "pending"
        assert plan.current_task_id == 1

    def test_from_create_json_dict_tasks(self):
        data = {
            "goal": "Test",
            "strategy": "Test",
            "tasks": [
                {"description": "Step 1"},
                {"description": "Step 2"},
            ],
        }
        plan = TaskPlan.from_create_json(data)
        assert plan.tasks[0].description == "Step 1"

    def test_from_create_json_missing_goal_raises(self):
        with pytest.raises(ValueError, match="goal"):
            TaskPlan.from_create_json({"tasks": ["x"]})

    def test_from_create_json_missing_tasks_raises(self):
        with pytest.raises(ValueError, match="tasks"):
            TaskPlan.from_create_json({"goal": "x", "strategy": "y", "tasks": []})

    def test_from_create_json_empty_goal_raises(self):
        with pytest.raises(ValueError, match="goal"):
            TaskPlan.from_create_json({"goal": "", "strategy": "y", "tasks": ["x"]})
