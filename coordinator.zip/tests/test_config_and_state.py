"""
Tests for core/config.py and core/session_state.py
"""

import os
import pytest


class TestQAAgentSettings:
    """Verify QAAgentSettings loads defaults and env overrides correctly."""

    def test_default_values(self):
        """All defaults should be set without any env vars."""
        # Import inside test to avoid polluting other tests with singleton
        from core.config import QAAgentSettings

        cfg = QAAgentSettings(
            _env_file=None,  # disable .env loading for test isolation
        )
        assert cfg.llm_model == "gpt-4o"
        assert cfg.llm_base_url == "https://api.openai.com/v1"
        assert cfg.milvus_host == "localhost"
        assert cfg.milvus_port == 19530
        assert cfg.milvus_enabled is True
        assert cfg.storage_backend.value == "sqlite"
        assert cfg.context_soft_threshold == 0.70
        assert cfg.context_hard_threshold == 0.85
        assert cfg.max_context_tokens == 128_000
        assert cfg.default_max_turns == 25
        assert cfg.default_permission_mode.value == "default"
        assert cfg.api_port == 8000
        assert cfg.interrupt_timeout_minutes == 30

    def test_env_override(self, monkeypatch):
        """Settings should pick up environment variable overrides."""
        from core.config import QAAgentSettings

        monkeypatch.setenv("LLM_MODEL", "gpt-4o-mini")
        monkeypatch.setenv("MILVUS_ENABLED", "false")
        monkeypatch.setenv("STORAGE_BACKEND", "postgres")
        monkeypatch.setenv("DEFAULT_PERMISSION_MODE", "bypass")
        monkeypatch.setenv("CONTEXT_SOFT_THRESHOLD", "0.60")
        monkeypatch.setenv("MAX_CONTEXT_TOKENS", "64000")

        cfg = QAAgentSettings(_env_file=None)
        assert cfg.llm_model == "gpt-4o-mini"
        assert cfg.milvus_enabled is False
        assert cfg.storage_backend.value == "postgres"
        assert cfg.default_permission_mode.value == "bypass"
        assert cfg.context_soft_threshold == 0.60
        assert cfg.max_context_tokens == 64_000

    def test_embedding_fallback(self):
        """Embedding API key/URL should fall back to LLM values."""
        from core.config import QAAgentSettings

        cfg = QAAgentSettings(
            _env_file=None,
            llm_api_key="sk-test-key",
            llm_base_url="https://custom.api/v1",
        )
        assert cfg.embedding_api_key_resolved == "sk-test-key"
        assert cfg.embedding_base_url_resolved == "https://custom.api/v1"

    def test_embedding_explicit(self):
        """Explicit embedding config should override LLM fallback."""
        from core.config import QAAgentSettings

        cfg = QAAgentSettings(
            _env_file=None,
            llm_api_key="sk-llm",
            embedding_api_key="sk-embed",
            embedding_base_url="https://embed.api/v1",
        )
        assert cfg.embedding_api_key_resolved == "sk-embed"
        assert cfg.embedding_base_url_resolved == "https://embed.api/v1"


class TestQASessionState:
    """Verify QASessionState initialization and helper methods."""

    def test_defaults(self):
        from core.session_state import QASessionState

        state = QASessionState()
        assert state.turn_count == 0
        assert state.stop_reason is None
        assert state.max_turns == 25
        assert state.current_context_tokens == 0
        assert state.max_context_tokens == 128_000
        assert state.permission_mode == "default"
        assert state.agent_type == "normal"
        assert state.session_id == ""
        assert state.worker_id is None
        assert state.compression_count == 0

    def test_custom_init(self):
        from core.session_state import QASessionState

        state = QASessionState(
            max_turns=10,
            permission_mode="bypass",
            agent_type="worker",
            session_id="test-123",
            game_version="v2.4",
            module="combat",
        )
        assert state.max_turns == 10
        assert state.permission_mode == "bypass"
        assert state.agent_type == "worker"
        assert state.session_id == "test-123"
        assert state.game_version == "v2.4"

    def test_context_usage_ratio(self):
        from core.session_state import QASessionState

        state = QASessionState(current_context_tokens=70_000, max_context_tokens=100_000)
        assert state.context_usage_ratio == pytest.approx(0.70)

    def test_context_usage_ratio_zero_max(self):
        from core.session_state import QASessionState

        state = QASessionState(max_context_tokens=0)
        assert state.context_usage_ratio == 0.0

    def test_increment_turn(self):
        from core.session_state import QASessionState

        state = QASessionState()
        state.increment_turn()
        state.increment_turn()
        assert state.turn_count == 2

    def test_threshold_checks(self):
        from core.session_state import QASessionState

        state = QASessionState(current_context_tokens=75_000, max_context_tokens=100_000)
        assert state.is_over_soft_threshold(0.70) is True
        assert state.is_over_hard_threshold(0.85) is False

        state.current_context_tokens = 90_000
        assert state.is_over_hard_threshold(0.85) is True

    def test_should_stop(self):
        from core.session_state import QASessionState

        state = QASessionState(max_turns=3)
        assert state.should_stop() is False
        state.turn_count = 3
        assert state.should_stop() is True
