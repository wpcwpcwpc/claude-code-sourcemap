# QA Agent System — 部署文档

## 目录

1. [系统要求](#系统要求)
2. [环境变量说明](#环境变量说明)
3. [快速启动（Docker Compose）](#快速启动)
4. [Milvus Collection 初始化](#milvus-collection-初始化)
5. [Skill 开发指南](#skill-开发指南)
6. [Agent 定义指南](#agent-定义指南)
7. [API 接口速查](#api-接口速查)
8. [权限系统说明](#权限系统说明)
9. [运维与监控](#运维与监控)

---

## 系统要求

| 组件 | 最低版本 | 说明 |
|------|---------|------|
| Python | 3.11+ | 运行时 |
| Docker | 24.0+ | 容器化部署 |
| Docker Compose | 2.20+ | 编排 |
| 内存 | 8 GB | Milvus 至少需要 4 GB |
| 磁盘 | 20 GB | 向量数据 + PostgreSQL 数据 |

---

## 环境变量说明

复制 `.env.example` 为 `.env` 后按需修改：

```bash
cp .env.example .env
```

### LLM 配置（必填）

| 变量 | 说明 | 示例 |
|------|------|------|
| `LLM_BASE_URL` | LLM API 基础 URL | `https://api.openai.com/v1` |
| `LLM_API_KEY` | API 密钥 | `sk-...` |
| `LLM_MODEL` | 使用的模型名 | `gpt-4o` |
| `EMBED_MODEL` | 嵌入模型名 | `text-embedding-3-small` |

### Milvus 配置

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `MILVUS_HOST` | `localhost` | Milvus 主机 |
| `MILVUS_PORT` | `19530` | Milvus 端口 |
| `MILVUS_ENABLED` | `true` | 是否启用长期记忆 |

> 若 `MILVUS_ENABLED=false` 或 Milvus 不可达，系统自动降级为"无长期记忆"模式，所有功能仍正常运行。

### Storage 配置

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `STORAGE_BACKEND` | `sqlite` | `sqlite` 或 `postgres` |
| `SQLITE_DB_PATH` | `./data/qa_agent.db` | SQLite 文件路径 |
| `POSTGRES_HOST` | `localhost` | PostgreSQL 主机 |
| `POSTGRES_PORT` | `5432` | PostgreSQL 端口 |
| `POSTGRES_DB` | `qa_agent` | 数据库名 |
| `POSTGRES_USER` | — | 数据库用户 |
| `POSTGRES_PASSWORD` | — | 数据库密码 |

### 权限与 HIL 配置

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `DEFAULT_PERMISSION_MODE` | `ask` | `ask` / `auto` / `safe` |
| `HIL_TIMEOUT_SECONDS` | `300` | 人工审核超时（秒） |
| `DEFAULT_MAX_TURNS` | `20` | Agent 最大轮次 |

### 应用服务配置

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `SERVER_HOST` | `0.0.0.0` | 监听地址 |
| `SERVER_PORT` | `8000` | 监听端口 |
| `LOG_LEVEL` | `info` | `debug` / `info` / `warning` |
| `DEBUG` | `false` | 开发模式（自动重载） |

### Skill / Agent 目录

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `PROJECT_SKILLS_DIR` | `./.claude/skills` | 项目级 Skill 目录 |
| `USER_SKILLS_DIR` | `~/.qa-agent/skills` | 用户级 Skill 目录 |
| `AGENTS_DIR` | `./.claude/agents` | 自定义 Agent 目录 |
| `MCP_CONFIG_PATH` | `./.claude/mcp.json` | MCP 服务器配置 |

---

## 快速启动

### 开发模式（本地）

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境
cp .env.example .env
# 编辑 .env，至少填写 LLM_BASE_URL 和 LLM_API_KEY

# 3. 仅启动基础设施（Milvus + PostgreSQL）
docker compose up -d postgres milvus-standalone

# 4. 启动服务（开发模式，自动重载）
DEBUG=true python main.py
```

### 生产模式（Docker Compose）

```bash
# 1. 配置环境变量
cp .env.example .env
# 必填: LLM_BASE_URL, LLM_API_KEY, POSTGRES_PASSWORD

# 2. 一键启动所有服务
docker compose up -d

# 3. 查看日志
docker compose logs -f qa-agent

# 4. 健康检查
curl http://localhost:8000/health
```

### 等待服务就绪

```bash
# 等待所有服务通过健康检查（约 60 秒）
docker compose ps

# 预期所有服务状态为 healthy
```

---

## Milvus Collection 初始化

Collection 在应用**首次启动时自动创建**，无需手动操作。

若需手动重建：

```python
# 在项目根目录执行
python -c "
from memory.milvus_client import get_milvus_client
from memory.collections import ensure_collections

client = get_milvus_client()
client.connect()
ensure_collections()
print('Collections ready')
"
```

### Collection 说明

| Collection | 用途 | 写入时机 |
|-----------|------|---------|
| `qa_memory` | QA 知识和会话蒸馏 | 上下文阈值触发 (>70%) 或会话结束 |
| `qa_session` | 会话摘要压缩历史 | 上下文阈值触发 (>70%) |

---

## Skill 开发指南

Skill 是 Markdown 文件（`SKILL.md`），包含 YAML Frontmatter 和提示模板。

### 文件位置

```
.claude/
  skills/
    my-skill/
      SKILL.md        # 必须
      helper.py       # 可选（被 !`cmd` 调用）
```

### SKILL.md 格式

```markdown
---
name: my-skill
description: 简短描述，Agent 用于判断何时调用该 Skill
version: "1.0"
author: your-name
args:
  - name: target
    description: 测试目标模块名
    required: true
  - name: depth
    description: 分析深度（1-3）
    required: false
    default: "2"
tags:
  - qa
  - automation
---

# My Skill

你是一个专业 QA 工程师，正在分析 $target 模块。

分析深度: $depth

## 当前项目状态

!`git log --oneline -5`

## 任务

请执行以下步骤：
1. 分析 $target 的相关配置
2. 列出潜在问题
3. 给出测试建议
```

### 变量替换

| 语法 | 说明 |
|------|------|
| `$ARGUMENTS` | 全部原始参数（位置参数时使用） |
| `$arg_name` | 具名参数值 |
| `${CLAUDE_SKILL_DIR}` | 当前 Skill 目录绝对路径 |
| `` !`cmd` `` | 执行 Shell 命令并内联输出（5 秒超时） |

### 调用方式

通过 API 发送消息，Agent 会自动识别并调用 Skill：

```
执行 my-skill，目标模块 combat，深度 3
```

---

## Agent 定义指南

自定义 Agent 使用 `AGENT.md` 格式（同 Claude Code 兼容）。

### 文件位置

```
.claude/
  agents/
    my-agent/
      AGENT.md
```

### AGENT.md 格式

```markdown
---
name: my-agent
description: 该 Agent 的用途描述，供 Coordinator 选择成员时使用
version: "1.0"
tools:
  - file_read
  - grep
  - bash
permission_mode: ask   # ask / auto / safe
model: gpt-4o          # 可覆盖全局 LLM 设置
---

# My Agent Instructions

你是一个专业的 H73 QA 测试工程师，专注于...

## 工作准则

1. 始终先分析再操作
2. 重要操作前等待人工确认
3. 测试结果必须记录
```

---

## API 接口速查

### 创建会话

```bash
curl -X POST http://localhost:8000/sessions \
  -H "Content-Type: application/json" \
  -d '{
    "agent_name": "qa_automation",
    "mode": "normal",
    "game_version": "1.0.0",
    "module": "combat"
  }'
```

### 发送消息（触发 Agent 执行）

```bash
curl -X POST http://localhost:8000/sessions/{session_id}/messages \
  -H "Content-Type: application/json" \
  -d '{"content": "请分析战斗模块伤害计算的配置表"}'
```

### WebSocket 接收事件流

```javascript
const ws = new WebSocket(`ws://localhost:8000/sessions/${sessionId}/stream`);

ws.onmessage = (msg) => {
  const event = JSON.parse(msg.data);
  switch (event.event_type) {
    case "token":
      process.stdout.write(event.content);
      break;
    case "interrupt_request":
      console.log("需要人工审核:", event.payload);
      break;
    case "run_complete":
      console.log("执行完成:", event.final_response);
      break;
  }
};
```

### 提交人工审核

```bash
# 批准
curl -X POST http://localhost:8000/sessions/{session_id}/review \
  -H "Content-Type: application/json" \
  -d '{"action": "approve"}'

# 拒绝（中止当前操作）
curl -X POST http://localhost:8000/sessions/{session_id}/review \
  -H "Content-Type: application/json" \
  -d '{"action": "reject", "notes": "该命令风险过高"}'

# 修改内容后批准
curl -X POST http://localhost:8000/sessions/{session_id}/review \
  -H "Content-Type: application/json" \
  -d '{"action": "approve", "modified_content": "修改后的内容"}'
```

### 查询状态

```bash
curl http://localhost:8000/sessions/{session_id}/status
```

---

## 权限系统说明

| 级别 | 名称 | 触发条件 | 默认行为 |
|------|------|---------|---------|
| L1 | 只读 | file_read, grep, glob_search | 自动执行，无需确认 |
| L2 | 副作用 | file_edit, bash, hunter_execute | 暂停等待人工审核 |
| L3 | 结果验收 | 每次 Agent 执行完成后 | 展示结果等待人工确认 |
| L4 | 危险操作 | 特定高风险命令 | 强制要求显式批准 |

### Permission Mode

- **`ask`**（推荐）：L2+ 操作均暂停等待人工，最安全
- **`auto`**：L1/L2 自动执行，仅 L3/L4 需人工确认，适合批量任务
- **`safe`**：仅允许 L1 操作，拒绝所有副作用操作，用于探索/分析场景

---

## 运维与监控

### 日志

```bash
# 实时日志
docker compose logs -f qa-agent

# 日志格式示例
2024-01-15 10:23:45 | INFO     | api.server — ✓ QA Agent System ready
2024-01-15 10:23:46 | INFO     | hooks.interrupt_manager — Interrupt requested (session=abc123, type=L2_TOOL)
```

### 健康检查端点

```bash
curl http://localhost:8000/health
# {"status": "ok", "milvus": "connected", "storage": "ok"}

# degraded 模式（Milvus 不可用但服务正常运行）
# {"status": "degraded", "milvus": "disconnected", "storage": "ok"}
```

### 清理过期会话

系统每 5 分钟自动清理超时的 HIL 等待会话。  
手动触发：重启服务即可（会话状态持久化在 PostgreSQL/SQLite 中）。

### 扩容说明

- **水平扩展**：由于使用 `asyncio.Event` 管理 HIL 状态，必须使用**单进程单实例**。
- **多实例部署**：需将 `asyncio.Event` 替换为 Redis 分布式锁（未来规划）。
- 推荐通过增加硬件垂直扩展单实例性能。
