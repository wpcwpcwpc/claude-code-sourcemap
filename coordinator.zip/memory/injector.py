"""
QA Agent System — Memory Injector

Retrieves historical context from Milvus at Worker startup
and formats it as additional instructions text.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from memory.collections import COL_EXECUTION_LOG, COL_KNOWLEDGE

logger = logging.getLogger(__name__)

# Number of historical records to retrieve per collection
TOP_K = 5


async def inject_historical_context(
    task_description: str,
    game_version: str = "",
    module: str = "",
) -> str:
    """Retrieve relevant historical context and format for Agent instructions.

    Searches both qa_execution_log (recent executions) and qa_knowledge
    (compressed summaries / pending_steps) for semantically similar records.

    Args:
        task_description: Description of the current task.
        game_version: Filter by game version (optional, for future use).
        module: Filter by module name (optional, for future use).

    Returns:
        Formatted string to append to Agent instructions, or empty string
        if Milvus is unavailable or no relevant history found.
    """
    from memory.embedder import get_embedder
    from memory.milvus_client import get_milvus_client

    client = get_milvus_client()
    if not client.is_available:
        logger.debug("Milvus not available — skipping historical context injection")
        return ""

    embedder = get_embedder()
    query_vector = await embedder.embed(task_description)

    # Search qa_knowledge (compressed summaries with pending_steps)
    knowledge_hits = await client.search(
        collection_name=COL_KNOWLEDGE,
        vector=query_vector,
        top_k=TOP_K,
        output_fields=["completed_steps", "pending_steps", "findings", "module", "game_version"],
    )

    # Search qa_execution_log (raw execution records)
    log_hits = await client.search(
        collection_name=COL_EXECUTION_LOG,
        vector=query_vector,
        top_k=TOP_K,
        output_fields=["tool_used", "result_summary", "module", "game_version", "step_no"],
    )

    if not knowledge_hits and not log_hits:
        logger.debug("No relevant historical context found for task: %s", task_description[:80])
        return ""

    sections: List[str] = ["## [Related Historical Knowledge]",
                            "_以下内容来自历史执行记忆，仅供参考，请结合当前任务判断是否适用_\n"]

    # Format knowledge summaries
    if knowledge_hits:
        sections.append("### 历史知识摘要")
        for i, hit in enumerate(knowledge_hits[:3], 1):
            pending = hit.get("pending_steps", "").strip()
            findings = hit.get("findings", "").strip()
            completed = hit.get("completed_steps", "").strip()
            module_name = hit.get("module", "")
            version = hit.get("game_version", "")

            parts = []
            if version or module_name:
                parts.append(f"**版本/模块**: {version} / {module_name}")
            if completed:
                parts.append(f"**已完成步骤**:\n{completed[:500]}")
            if pending:
                parts.append(f"**待续步骤（可续接）**:\n{pending[:500]}")
            if findings:
                parts.append(f"**关键发现**:\n{findings[:500]}")

            if parts:
                sections.append(f"\n**[知识 {i}]** (相似度: {1 - hit.get('_distance', 1):.2f})")
                sections.extend(parts)

    # Format execution log hits
    if log_hits:
        sections.append("\n### 相关执行记录")
        for i, hit in enumerate(log_hits[:3], 1):
            tool = hit.get("tool_used", "")
            result = hit.get("result_summary", "").strip()
            if tool and result:
                sections.append(
                    f"- **步骤{hit.get('step_no', '?')}** `{tool}`: {result[:200]}"
                )

    sections.append("\n---")

    injected = "\n".join(sections)
    logger.info(
        "Injected historical context (%d knowledge + %d log records) for task: %s",
        len(knowledge_hits), len(log_hits), task_description[:60],
    )
    return injected
