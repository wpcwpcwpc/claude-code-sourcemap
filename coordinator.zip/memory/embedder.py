"""
QA Agent System — Text Embedder

Wraps the OpenAI Embedding API to produce vectors for Milvus storage.
Supports fallback to zero vectors when API is unavailable (degraded mode).
"""

from __future__ import annotations

import asyncio
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

EMBEDDING_DIM = 1536  # text-embedding-3-small output dimension


class Embedder:
    """Async text embedder backed by OpenAI-compatible embedding API."""

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        api_key: str = "",
        base_url: str = "https://api.openai.com/v1",
    ) -> None:
        self._model = model
        self._api_key = api_key
        self._base_url = base_url
        self._client: Optional[object] = None

    def _get_client(self):
        """Lazy-initialize the OpenAI async client."""
        if self._client is None:
            try:
                from openai import AsyncOpenAI
                self._client = AsyncOpenAI(
                    api_key=self._api_key or None,
                    base_url=self._base_url,
                )
            except ImportError:
                logger.warning("openai package not available — embedder in degraded mode")
        return self._client

    async def embed(self, text: str) -> List[float]:
        """Embed a single text string.

        Args:
            text: The text to embed.

        Returns:
            A list of floats (length = EMBEDDING_DIM), or zero vector on failure.
        """
        client = self._get_client()
        if client is None:
            return self._zero_vector()

        try:
            # Truncate extremely long texts (API limits)
            truncated = text[:8000]
            response = await client.embeddings.create(
                model=self._model,
                input=truncated,
            )
            return response.data[0].embedding
        except Exception:
            logger.warning("Embedding API call failed — using zero vector", exc_info=True)
            return self._zero_vector()

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Embed multiple texts concurrently.

        Args:
            texts: List of texts to embed.

        Returns:
            List of embedding vectors, parallel to input texts.
        """
        tasks = [self.embed(t) for t in texts]
        return await asyncio.gather(*tasks)

    @staticmethod
    def _zero_vector() -> List[float]:
        """Return a zero vector of standard embedding dimension."""
        return [0.0] * EMBEDDING_DIM


# ---------------------------------------------------------------------------
# Module-level singleton (configured lazily from settings)
# ---------------------------------------------------------------------------
_embedder: Optional[Embedder] = None


def get_embedder() -> Embedder:
    """Return the global Embedder singleton, initializing from settings if needed."""
    global _embedder
    if _embedder is None:
        from core.config import settings
        _embedder = Embedder(
            model=settings.embedding_model,
            api_key=settings.embedding_api_key_resolved,
            base_url=settings.embedding_base_url_resolved,
        )
    return _embedder
