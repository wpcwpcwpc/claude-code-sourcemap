"""
Milvus collection schema definitions and initializer.

Collections
-----------
  qa_memory     — Long-term QA knowledge: test steps, bug reports, insights
  qa_session    — Compressed session summaries (per-session per-turn)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from memory.milvus_client import MilvusClient

logger = logging.getLogger(__name__)

# Collection dimension must match the embedding model used in milvus_client.py
EMBEDDING_DIM = 1536  # OpenAI text-embedding-3-small / compatible models

# Collection names
QA_MEMORY_COLLECTION = "qa_memory"
QA_SESSION_COLLECTION = "qa_session"


def ensure_collections() -> None:
    """Create Milvus collections if they do not already exist."""
    from memory.milvus_client import get_milvus_client

    client = get_milvus_client()
    if not client.is_available:
        logger.warning("Milvus unavailable — skipping collection setup")
        return

    _ensure_qa_memory(client)
    _ensure_qa_session(client)
    logger.info("✓ Milvus collections ready")


def _ensure_qa_memory(client: "MilvusClient") -> None:
    """
    qa_memory: stores semantic memories extracted from QA sessions.

    Fields
    ------
    id          PK (auto-increment)
    session_id  source session identifier
    module      H73 game module tag (e.g. "combat", "inventory")
    version     game version string
    content     raw text of the memory
    summary     LLM-generated summary (may equal content)
    embedding   vector representation
    created_at  Unix timestamp (int64)
    """
    schema = {
        "collection_name": QA_MEMORY_COLLECTION,
        "description": "Long-term QA knowledge and session distillations",
        "fields": [
            {"name": "id",         "dtype": "INT64",       "is_primary": True, "auto_id": True},
            {"name": "session_id", "dtype": "VARCHAR",     "max_length": 64},
            {"name": "module",     "dtype": "VARCHAR",     "max_length": 128},
            {"name": "version",    "dtype": "VARCHAR",     "max_length": 64},
            {"name": "content",    "dtype": "VARCHAR",     "max_length": 4096},
            {"name": "summary",    "dtype": "VARCHAR",     "max_length": 1024},
            {"name": "embedding",  "dtype": "FLOAT_VECTOR","dim": EMBEDDING_DIM},
            {"name": "created_at", "dtype": "INT64"},
        ],
        "index_params": {
            "field_name": "embedding",
            "index_type": "IVF_FLAT",
            "metric_type": "COSINE",
            "params": {"nlist": 128},
        },
    }
    client.ensure_collection(schema)


def _ensure_qa_session(client: "MilvusClient") -> None:
    """
    qa_session: stores per-session compressed history summaries.

    Fields
    ------
    id          PK (auto-increment)
    session_id  owner session
    turn        turn number when this summary was generated
    summary     compressed text of turns up to this point
    embedding   vector of the summary
    created_at  Unix timestamp (int64)
    """
    schema = {
        "collection_name": QA_SESSION_COLLECTION,
        "description": "Per-session compressed turn summaries",
        "fields": [
            {"name": "id",         "dtype": "INT64",       "is_primary": True, "auto_id": True},
            {"name": "session_id", "dtype": "VARCHAR",     "max_length": 64},
            {"name": "turn",       "dtype": "INT64"},
            {"name": "summary",    "dtype": "VARCHAR",     "max_length": 4096},
            {"name": "embedding",  "dtype": "FLOAT_VECTOR","dim": EMBEDDING_DIM},
            {"name": "created_at", "dtype": "INT64"},
        ],
        "index_params": {
            "field_name": "embedding",
            "index_type": "IVF_FLAT",
            "metric_type": "COSINE",
            "params": {"nlist": 64},
        },
    }
    client.ensure_collection(schema)