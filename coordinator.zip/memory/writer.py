"""
QA Agent System — Memory Writer

Provides async write functions for all three Milvus collections.
All writes are non-blocking (called via asyncio.create_task from hooks).
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from memory.collections import COL_EXECUTION_LOG, COL_KNOWLEDGE

logger = logging.getLogger(__name__)


async def write_execution_log(entry: Dict[str, Any]) -> bool:
    """Write a single tool execution record to qa_execution_log.

    Called from execution_log_post_hook via asyncio.create_task (fire-and-forget).

    Args:
        entry: Dict with fields matching the qa_execution_log schema.
               Required: session_id, worker_id, step_no, tool_used,
                         tool_args_summary, result_summary, timestamp.

    Returns:
        True if written successfully, False otherwise.
    """
    from memory.embedder import get_embedder
    from memory.milvus_client import get_milvus_client

    client = get_milvus_client()
    if not client.is_available:
        return False

    # Build embedding text from tool + result summary
    embed_text = f"Tool: {entry.get('tool_used', '')} | Result: {entry.get('result_summary', '')}"
    embedder = get_embedder()
    vector = await embedder.embed(embed_text)

    data = {
        "embedding":        [vector],
        "session_id":       [_trunc(entry.get("session_id", ""), 128)],
        "worker_id":        [_trunc(entry.get("worker_id", ""), 128)],
        "step_no":          [int(entry.get("step_no", 0))],
        "tool_used":        [_trunc(entry.get("tool_used", ""), 128)],
        "tool_args_summary":[_trunc(entry.get("tool_args_summary", ""), 1024)],
        "result_summary":   [_trunc(entry.get("result_summary", ""), 2048)],
        "game_version":     [_trunc(entry.get("game_version", ""), 64)],
        "module":           [_trunc(entry.get("module", ""), 128)],
        "timestamp":        [float(entry.get("timestamp", time.time()))],
    }

    success = await client.insert(COL_EXECUTION_LOG, data)
    if success:
        logger.debug(
            "Wrote execution log (session=%s, tool=%s)",
            entry.get("session_id"), entry.get("tool_used"),
        )
    return success


async def write_knowledge(entry: Dict[str, Any]) -> bool:
    """Write a compressed context summary to qa_knowledge.

    Called from context_threshold_hook after soft/hard compression.

    Args:
        entry: Dict with fields matching the qa_knowledge schema.

    Returns:
        True if written successfully, False otherwise.
    """
    from memory.embedder import get_embedder
    from memory.milvus_client import get_milvus_client

    client = get_milvus_client()
    if not client.is_available:
        return False

    # Embed the combined knowledge text
    embed_parts = [
        entry.get("completed_steps", ""),
        entry.get("pending_steps", ""),
        entry.get("findings", ""),
    ]
    embed_text = " | ".join(p for p in embed_parts if p)
    embedder = get_embedder()
    vector = await embedder.embed(embed_text)

    data = {
        "embedding":         [vector],
        "session_id":        [_trunc(entry.get("session_id", ""), 128)],
        "worker_id":         [_trunc(entry.get("worker_id", ""), 128)],
        "compression_type":  [_trunc(entry.get("compression_type", "soft"), 16)],
        "compression_count": [int(entry.get("compression_count", 1))],
        "completed_steps":   [_trunc(entry.get("completed_steps", ""), 4096)],
        "pending_steps":     [_trunc(entry.get("pending_steps", ""), 2048)],
        "findings":          [_trunc(entry.get("findings", ""), 4096)],
        "context_coverage":  [_trunc(entry.get("context_coverage", ""), 512)],
        "game_version":      [_trunc(entry.get("game_version", ""), 64)],
        "module":            [_trunc(entry.get("module", ""), 128)],
        "timestamp":         [float(entry.get("timestamp", time.time()))],
    }

    success = await client.insert(COL_KNOWLEDGE, data)
    if success:
        logger.info(
            "Wrote knowledge summary (session=%s, type=%s, compression_count=%d)",
            entry.get("session_id"),
            entry.get("compression_type"),
            entry.get("compression_count", 1),
        )
    return success


def _trunc(value: Any, max_len: int) -> str:
    """Convert value to string and truncate to max_len."""
    s = str(value) if value is not None else ""
    return s[:max_len]
