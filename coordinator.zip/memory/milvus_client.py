"""
QA Agent System — Milvus Client

Wraps pymilvus with:
- Lazy connection with retry
- Graceful degradation (no-op when Milvus is unavailable)
- Simple insert() / search() interface
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class MilvusClient:
    """Thread-safe Milvus client wrapper with degradation support.

    When Milvus is unavailable (disabled or connection failure),
    all operations return empty results and log warnings.
    This allows the Agent system to run without long-term memory.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 19530,
        enabled: bool = True,
    ) -> None:
        self._host = host
        self._port = port
        self._enabled = enabled
        self._client: Optional[Any] = None
        self._connected = False
        self._degraded = False  # True when connection failed

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def connect(self) -> bool:
        """Attempt to connect to Milvus. Returns True if successful."""
        if not self._enabled:
            logger.info("Milvus disabled by config — running in degraded mode (no long-term memory)")
            self._degraded = True
            return False

        try:
            from pymilvus import connections, utility
            connections.connect(
                alias="default",
                host=self._host,
                port=str(self._port),
            )
            # Quick health check
            utility.list_collections()
            self._connected = True
            self._degraded = False
            logger.info("Connected to Milvus at %s:%d", self._host, self._port)
            return True

        except Exception as e:
            logger.warning(
                "Failed to connect to Milvus (%s:%d): %s — running in degraded mode",
                self._host, self._port, e,
            )
            self._degraded = True
            self._connected = False
            return False

    @property
    def is_available(self) -> bool:
        return self._connected and not self._degraded

    # ------------------------------------------------------------------
    # Insert
    # ------------------------------------------------------------------

    async def insert(self, collection_name: str, data: Dict[str, List[Any]]) -> bool:
        """Insert a batch of records into a Milvus collection.

        Args:
            collection_name: Target collection name.
            data: Dict of field_name → list of values. All lists must be same length.

        Returns:
            True if inserted successfully, False on failure or degraded mode.
        """
        if not self.is_available:
            logger.debug("Milvus degraded — skipping insert to '%s'", collection_name)
            return False

        try:
            from pymilvus import Collection
            col = Collection(collection_name)
            col.insert(list(data.values()))
            col.flush()
            return True
        except Exception:
            logger.warning("Milvus insert failed for '%s'", collection_name, exc_info=True)
            return False

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search(
        self,
        collection_name: str,
        vector: List[float],
        vector_field: str = "embedding",
        top_k: int = 5,
        output_fields: Optional[List[str]] = None,
        filter_expr: str = "",
    ) -> List[Dict[str, Any]]:
        """Perform vector similarity search on a collection.

        Args:
            collection_name: Target collection name.
            vector: Query vector.
            vector_field: Name of the vector field to search.
            top_k: Number of results to return.
            output_fields: Fields to include in results. None = all scalar fields.
            filter_expr: Optional Milvus boolean filter expression.

        Returns:
            List of result dicts, or empty list on failure/degraded.
        """
        if not self.is_available:
            logger.debug("Milvus degraded — returning empty search results for '%s'", collection_name)
            return []

        try:
            from pymilvus import Collection
            col = Collection(collection_name)
            col.load()

            search_params = {"metric_type": "COSINE", "params": {"ef": 64}}

            results = col.search(
                data=[vector],
                anns_field=vector_field,
                param=search_params,
                limit=top_k,
                output_fields=output_fields,
                expr=filter_expr or None,
            )

            hits = []
            for hit in results[0]:
                record = {"_distance": hit.distance, "_id": hit.id}
                if output_fields:
                    for field in output_fields:
                        record[field] = hit.entity.get(field)
                hits.append(record)

            return hits

        except Exception:
            logger.warning("Milvus search failed for '%s'", collection_name, exc_info=True)
            return []

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def collection_exists(self, name: str) -> bool:
        """Check if a collection exists."""
        if not self.is_available:
            return False
        try:
            from pymilvus import utility
            return utility.has_collection(name)
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
_milvus_client: Optional[MilvusClient] = None


def get_milvus_client() -> MilvusClient:
    """Return the global MilvusClient singleton."""
    global _milvus_client
    if _milvus_client is None:
        from core.config import settings
        _milvus_client = MilvusClient(
            host=settings.milvus_host,
            port=settings.milvus_port,
            enabled=settings.milvus_enabled,
        )
    return _milvus_client
