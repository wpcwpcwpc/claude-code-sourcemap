"""
QA Agent System — Execution Log Hook (Tool post_hook)

After every tool execution, asynchronously writes an execution record
to Milvus qa_execution_log. Non-blocking via asyncio.create_task.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


async def execution_log_post_hook(
    tool_name: str,
    tool_args: Dict[str, Any],
    tool_result: Any,
    agent: Any,
) -> None:
    """Post-hook: fire-and-forget write to Milvus execution log.

    Args:
        tool_name: Name of the tool that was executed.
        tool_args: Arguments passed to the tool.
        tool_result: Result returned by the tool.
        agent: The Agno Agent instance.
    """
    # Extract session context
    session_id = ""
    worker_id = None
    game_version = ""
    module = ""
    step_no = 0

    if hasattr(agent, "session_state") and agent.session_state is not None:
        state = agent.session_state
        session_id = getattr(state, "session_id", "")
        worker_id = getattr(state, "worker_id", None)
        game_version = getattr(state, "game_version", "")
        module = getattr(state, "module", "")
        step_no = getattr(state, "turn_count", 0)

    # Build result summary (truncate long outputs)
    result_str = str(tool_result) if tool_result is not None else ""
    if len(result_str) > 1000:
        result_str = result_str[:1000] + "...[truncated]"

    log_entry = {
        "session_id": session_id,
        "worker_id": worker_id or session_id,
        "step_no": step_no,
        "tool_used": tool_name,
        "tool_args_summary": _summarize_args(tool_args),
        "result_summary": result_str,
        "game_version": game_version,
        "module": module,
        "timestamp": time.time(),
    }

    # Fire-and-forget: don't block the Agent loop
    asyncio.create_task(_write_log_safe(log_entry))


async def _write_log_safe(log_entry: Dict[str, Any]) -> None:
    """Write execution log to Milvus, swallowing errors gracefully."""
    try:
        from memory.writer import write_execution_log
        await write_execution_log(log_entry)
        logger.debug(
            "[Hook] Execution log written (session=%s, tool=%s, step=%d)",
            log_entry.get("session_id"), log_entry.get("tool_used"), log_entry.get("step_no", 0),
        )
    except Exception:
        # Never let memory write failures propagate to the Agent loop
        logger.warning(
            "[Hook] Failed to write execution log (session=%s, tool=%s) — degraded mode",
            log_entry.get("session_id"), log_entry.get("tool_used"),
            exc_info=True,
        )


def _summarize_args(tool_args: Dict[str, Any]) -> str:
    """Create a short summary of tool arguments for logging."""
    parts = []
    for k, v in tool_args.items():
        v_str = str(v)
        if len(v_str) > 100:
            v_str = v_str[:100] + "..."
        parts.append(f"{k}={v_str!r}")
    return ", ".join(parts[:5])  # max 5 args in summary
