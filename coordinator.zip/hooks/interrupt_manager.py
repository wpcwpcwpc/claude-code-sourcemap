"""
QA Agent System — Interrupt Manager

Central coordinator for all human-in-the-loop interrupt flows.
Uses asyncio.Event to pause Agent execution and resume after human review.

Flow:
  1. Hook calls interrupt_manager.request_interrupt(session_id, payload)
  2. Manager creates asyncio.Event, stores it, sends WebSocket event
  3. Agent's hook awaits event.wait()
  4. Human calls POST /sessions/{id}/review
  5. API calls interrupt_manager.resolve_interrupt(session_id, decision)
  6. Manager sets event, hook reads decision and resumes
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Coroutine, Dict, Optional

logger = logging.getLogger(__name__)


class InterruptType(str, Enum):
    PREVIEW_CONFIRM = "preview_confirm"   # L2: show tool preview, ask confirm
    RESULT_VERIFY = "result_verify"       # L3: show result, ask pass/fail
    PLAN_CONFIRM = "plan_confirm"         # plan mode: confirm execution plan


class InterruptAction(str, Enum):
    CONFIRM = "confirm"
    CANCEL = "cancel"
    MODIFY = "modify"
    PASS = "pass"
    FAIL = "fail"
    RERUN = "rerun"
    INVESTIGATE = "investigate"


@dataclass
class InterruptRecord:
    """State for a single pending interrupt."""
    interrupt_id: str
    session_id: str
    interrupt_type: InterruptType
    payload: Dict[str, Any]
    created_at: float
    event: asyncio.Event = field(default_factory=asyncio.Event)
    action: Optional[str] = None          # set by resolve_interrupt
    modified_content: Optional[str] = None
    notes: Optional[str] = None
    resolved_at: Optional[float] = None

    @property
    def is_resolved(self) -> bool:
        return self.event.is_set()

    @property
    def age_seconds(self) -> float:
        return time.time() - self.created_at


class InterruptManager:
    """Singleton manager for all session interrupt states.

    Usage in Hook::

        record = await interrupt_manager.request_interrupt(
            session_id="abc",
            interrupt_type=InterruptType.PREVIEW_CONFIRM,
            payload={"tool_name": "bash", "preview": "ls -la"},
        )
        # Hook blocks here until human reviews
        if record.action == InterruptAction.CANCEL:
            raise ToolCancelledError()

    Usage in API::

        interrupt_manager.resolve_interrupt(
            session_id="abc",
            action="confirm",
        )
    """

    def __init__(self, timeout_minutes: int = 30) -> None:
        # session_id -> InterruptRecord
        self._pending: Dict[str, InterruptRecord] = {}
        self._timeout_seconds = timeout_minutes * 60
        # Optional WebSocket push callback: set by API layer
        self._ws_push: Optional[Callable[[str, Dict], Coroutine]] = None

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def set_ws_push(self, callback: Callable[[str, Dict], Coroutine]) -> None:
        """Register the WebSocket push callback (injected by API layer)."""
        self._ws_push = callback

    # ------------------------------------------------------------------
    # Hook → Manager
    # ------------------------------------------------------------------

    async def request_interrupt(
        self,
        session_id: str,
        interrupt_type: InterruptType,
        payload: Dict[str, Any],
        timeout_override: Optional[int] = None,
    ) -> InterruptRecord:
        """Create an interrupt, push WS notification, and await human decision.

        This method BLOCKS (via asyncio.Event.wait) until:
        - Human calls resolve_interrupt(), OR
        - Timeout expires (auto-resolves with action="timeout")

        Args:
            session_id: The session to interrupt.
            interrupt_type: Type of interrupt (L2 preview / L3 result / plan).
            payload: Data to show the human (tool preview, result summary, etc.)
            timeout_override: Custom timeout in seconds (overrides global default).

        Returns:
            The resolved InterruptRecord with `action` and `modified_content` set.
        """
        interrupt_id = str(uuid.uuid4())
        record = InterruptRecord(
            interrupt_id=interrupt_id,
            session_id=session_id,
            interrupt_type=interrupt_type,
            payload=payload,
            created_at=time.time(),
        )
        self._pending[session_id] = record

        # Build WebSocket event
        ws_event = {
            "event_type": "interrupt_request",
            "interrupt_id": interrupt_id,
            "session_id": session_id,
            "interrupt_type": interrupt_type.value,
            "payload": payload,
            "timestamp": record.created_at,
            "actions": self._allowed_actions(interrupt_type),
        }

        # Push to WebSocket if callback is registered
        if self._ws_push:
            try:
                await self._ws_push(session_id, ws_event)
            except Exception:
                logger.exception("Failed to push interrupt_request to WebSocket (session=%s)", session_id)

        # Wait for human decision (with timeout)
        timeout = timeout_override or self._timeout_seconds
        logger.info(
            "Interrupt requested (session=%s, type=%s, id=%s, timeout=%ds)",
            session_id, interrupt_type.value, interrupt_id, timeout,
        )

        try:
            await asyncio.wait_for(record.event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning("Interrupt timed out (session=%s, id=%s)", session_id, interrupt_id)
            record.action = "timeout"
            record.resolved_at = time.time()
            record.event.set()

        self._pending.pop(session_id, None)
        return record

    # ------------------------------------------------------------------
    # API → Manager
    # ------------------------------------------------------------------

    def resolve_interrupt(
        self,
        session_id: str,
        action: str,
        modified_content: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> bool:
        """Resolve a pending interrupt and unblock the waiting hook.

        Args:
            session_id: The session to resolve.
            action: One of confirm/cancel/modify/pass/fail/rerun/investigate.
            modified_content: Used when action="modify" to replace tool args.
            notes: Optional human notes attached to the review.

        Returns:
            True if an interrupt was found and resolved, False if no pending interrupt.
        """
        record = self._pending.get(session_id)
        if record is None:
            logger.warning("resolve_interrupt: no pending interrupt for session %s", session_id)
            return False

        record.action = action
        record.modified_content = modified_content
        record.notes = notes
        record.resolved_at = time.time()
        record.event.set()  # unblock the awaiting hook

        logger.info(
            "Interrupt resolved (session=%s, action=%s, notes=%s)",
            session_id, action, notes,
        )
        return True

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_pending(self, session_id: str) -> Optional[InterruptRecord]:
        """Return the current pending interrupt for a session, or None."""
        return self._pending.get(session_id)

    def has_pending(self, session_id: str) -> bool:
        return session_id in self._pending

    def pending_payload(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Return the payload of the pending interrupt for API status responses."""
        record = self._pending.get(session_id)
        if record is None:
            return None
        return {
            "interrupt_id": record.interrupt_id,
            "interrupt_type": record.interrupt_type.value,
            "payload": record.payload,
            "created_at": record.created_at,
            "age_seconds": record.age_seconds,
            "actions": self._allowed_actions(record.interrupt_type),
        }

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _allowed_actions(interrupt_type: InterruptType) -> list[str]:
        if interrupt_type == InterruptType.PREVIEW_CONFIRM:
            return ["confirm", "modify", "cancel"]
        elif interrupt_type == InterruptType.RESULT_VERIFY:
            return ["pass", "fail", "rerun", "investigate"]
        elif interrupt_type == InterruptType.PLAN_CONFIRM:
            return ["confirm", "cancel"]
        return ["confirm", "cancel"]


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
interrupt_manager = InterruptManager()
