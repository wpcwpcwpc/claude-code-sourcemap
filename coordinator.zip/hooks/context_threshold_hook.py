"""
QA Agent System — Context Threshold Hook (Run post_hook)

After each Agent run, checks token usage against soft/hard thresholds.
Triggers memory distillation and writes compressed summary to Milvus.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


async def context_threshold_post_hook(agent: Any, run_output: Any) -> None:
    """Run post_hook: check context usage and trigger compression if needed.

    This hook runs after every Agent turn (not every tool call).
    It uses tiktoken to estimate current context size and compares
    against soft (70%) and hard (85%) thresholds.

    Args:
        agent: The Agno Agent instance.
        run_output: The RunOutput from the current turn (Agno hook convention).
    """
    state = getattr(agent, "session_state", None)
    if state is None:
        return

    # Update token count estimate
    _update_token_count(agent, state, run_output)

    soft = state.is_over_soft_threshold()
    hard = state.is_over_hard_threshold()

    if not soft:
        return  # below threshold, nothing to do

    session_id = getattr(state, "session_id", "")
    usage_pct = state.context_usage_ratio * 100

    logger.info(
        "[Hook] Context threshold triggered (session=%s, usage=%.1f%%, hard=%s)",
        session_id, usage_pct, hard,
    )

    # Fire distillation asynchronously (non-blocking)
    asyncio.create_task(
        _distill_and_write(agent, state, hard=hard)
    )


async def _distill_and_write(agent: Any, state: Any, hard: bool) -> None:
    """Run LLM distillation and write summary to Milvus."""
    session_id = getattr(state, "session_id", "")
    try:
        from memory.distiller import distill_context
        summary = await distill_context(agent, hard=hard)

        if summary:
            from memory.writer import write_knowledge
            await write_knowledge({
                "session_id": session_id,
                "worker_id": getattr(state, "worker_id", None) or session_id,
                "compression_type": "hard" if hard else "soft",
                "compression_count": state.compression_count + 1,
                "completed_steps": summary.get("completed_steps", ""),
                "pending_steps": summary.get("pending_steps", ""),
                "findings": summary.get("findings", ""),
                "context_coverage": summary.get("context_coverage", ""),
                "game_version": getattr(state, "game_version", ""),
                "module": getattr(state, "module", ""),
            })

            # Update state bookkeeping
            state.compression_count += 1
            state.last_compression_turn = state.turn_count

            logger.info(
                "[Hook] Context %s compression complete (session=%s, compression_count=%d)",
                "hard" if hard else "soft", session_id, state.compression_count,
            )

    except Exception:
        logger.warning(
            "[Hook] Context distillation failed (session=%s) — continuing without compression",
            session_id, exc_info=True,
        )


def _update_token_count(agent: Any, state: Any, run_output: Any) -> None:
    """Estimate current context token count and update session_state."""
    try:
        import tiktoken

        # Try to get the encoding for the model
        model_name = "gpt-4o"
        if hasattr(agent, "model") and hasattr(agent.model, "id"):
            model_name = agent.model.id

        try:
            enc = tiktoken.encoding_for_model(model_name)
        except KeyError:
            enc = tiktoken.get_encoding("cl100k_base")

        # Count tokens in message history
        total_tokens = 0
        messages = []

        if hasattr(agent, "memory") and agent.memory is not None:
            mem = agent.memory
            if hasattr(mem, "messages"):
                messages = mem.messages or []

        for msg in messages:
            content = ""
            if hasattr(msg, "content"):
                content = str(msg.content or "")
            elif isinstance(msg, dict):
                content = str(msg.get("content", ""))
            total_tokens += len(enc.encode(content))

        state.current_context_tokens = total_tokens

    except Exception:
        # tiktoken unavailable or encoding failed — skip update
        pass
